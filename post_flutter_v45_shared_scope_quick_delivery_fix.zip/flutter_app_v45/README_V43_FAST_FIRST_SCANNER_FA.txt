POST MANAGEMENT v43 — Fast-first Scanner + v42 Analyze Fix

Build fixes:
1) Shipment.fromJson had duplicated createdBy argument -> removed duplicate.
2) SmsMessage.fromJson missed required createdBy -> added.

Scanner regression fix:
- Restored the fast v39 core: ML Kit Text + ML Kit Barcode + Persian Tesseract run in parallel on ORIGINAL photo.
- Selected gallery image is inserted into UI immediately before OCR starts.
- Batch gallery/camera shows all selected photos immediately, then updates each result progressively.
- Removed eager decode + grayscale + binary generation before first scan.
- Removed automatic image upscaling.
- No fixed binary threshold on every photo.
- ZXing is now a fallback, not part of every first pass.
- Sparse Persian OCR runs only if name/phone remain missing.
- Enhanced image is created only when important fields are still missing.
- Image enhancement runs in a background isolate to avoid blocking Flutter UI.
- Name parser restored closer to v39 behavior while still rejecting one-letter garbage such as «و و کش».
- Persian, Arabic and English digits remain normalized.
- Tracking can still fall back to OCR when the physical barcode cannot be decoded.

Backend:
- Backend v66 is preserved unchanged.
