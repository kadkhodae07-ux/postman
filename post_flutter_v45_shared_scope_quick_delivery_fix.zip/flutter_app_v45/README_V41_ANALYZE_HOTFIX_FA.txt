POST MANAGEMENT v41 — Flutter analyze hotfix

لاگ failure-logs (5):
- flutter pub get: PASS
- Prepare Android: PASS
- flutter analyze: FAILED with 2 errors

خطاها و اصلاح:
1) main.dart: kSoftOrange تعریف نشده بود.
   اصلاح: استفاده از kSoftYellow که در Theme پروژه وجود دارد.
2) smart_scan.dart: result.text در flutter_zxing nullable است.
   اصلاح: (result.text ?? '').trim()

هیچ تغییری در منطق اسکن حرفه‌ای، Backend v65، اشتراک یا پرداخت انجام نشده است.
نسخه: 1.0.41+41
