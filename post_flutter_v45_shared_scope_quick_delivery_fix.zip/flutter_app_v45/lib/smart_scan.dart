import 'dart:async';
import 'dart:io';
import 'dart:isolate';

import 'package:flutter_tesseract_ocr/flutter_tesseract_ocr.dart';
import 'package:flutter_zxing/flutter_zxing.dart' as zxing;
import 'package:google_mlkit_barcode_scanning/google_mlkit_barcode_scanning.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';

class ScannedShipmentDraft {
  ScannedShipmentDraft({
    required this.file,
    required this.rawText,
    required this.barcodes,
    required this.fullname,
    required this.phone,
    required this.paymentType,
    required this.trackingCode,
    required this.confidence,
    this.nameConfidence = 0,
    this.phoneConfidence = 0,
    this.trackingConfidence = 0,
    this.paymentConfidence = 0,
    this.usedHardBarcodeFallback = false,
    this.trackingFromOcrFallback = false,
    this.isProcessing = false,
    List<String>? warnings,
  }) : warnings = warnings ?? <String>[];

  factory ScannedShipmentDraft.processing(XFile file) => ScannedShipmentDraft(
        file: file,
        rawText: '',
        barcodes: const [],
        fullname: '',
        phone: '',
        paymentType: '',
        trackingCode: '',
        confidence: 0,
        isProcessing: true,
        warnings: const [],
      );

  factory ScannedShipmentDraft.failed(XFile file, [String? message]) =>
      ScannedShipmentDraft(
        file: file,
        rawText: '',
        barcodes: const [],
        fullname: '',
        phone: '',
        paymentType: '',
        trackingCode: '',
        confidence: 0,
        warnings: <String>[
          message ?? 'پردازش این تصویر ناموفق بود؛ اطلاعات را دستی بررسی کنید.'
        ],
      );

  final XFile file;
  final String rawText;
  final List<String> barcodes;
  String fullname;
  String phone;
  String paymentType;
  String trackingCode;
  double confidence;
  double nameConfidence;
  double phoneConfidence;
  double trackingConfidence;
  double paymentConfidence;
  final bool usedHardBarcodeFallback;
  final bool trackingFromOcrFallback;
  final bool isProcessing;
  final List<String> warnings;

  bool get readyToMessage =>
      !isProcessing &&
      fullname.trim().length >= 3 &&
      RegExp(r'^09\d{9}$').hasMatch(phone);

  bool get needsReview =>
      !isProcessing &&
      (warnings.isNotEmpty ||
          confidence < .72 ||
          (fullname.isNotEmpty && nameConfidence < .58) ||
          (phone.isNotEmpty && phoneConfidence < .68) ||
          (trackingCode.isNotEmpty && trackingConfidence < .55));
}

class _Candidate {
  _Candidate(this.value, this.score);
  final String value;
  final double score;
}

class _ParsedFields {
  _ParsedFields({
    required this.fullname,
    required this.phone,
    required this.paymentType,
    required this.tracking,
    required this.nameConfidence,
    required this.phoneConfidence,
    required this.paymentConfidence,
    required this.trackingConfidence,
    required this.trackingFromOcr,
  });

  final String fullname;
  final String phone;
  final String paymentType;
  final String tracking;
  final double nameConfidence;
  final double phoneConfidence;
  final double paymentConfidence;
  final double trackingConfidence;
  final bool trackingFromOcr;
}

class SmartShipmentScanner {
  static const _faDigits = '۰۱۲۳۴۵۶۷۸۹';
  static const _arDigits = '٠١٢٣٤٥٦٧٨٩';

  static final RegExp _postalNoise = RegExp(
    r'(?:پست|پستی|مرسوله|بسته|پاکت|فرستنده|آدرس|نشانی|استان|شهر|شهرستان|'
    r'خیابان|کوچه|پلاک|کد\s*پستی|کد\s*رهگیری|رهگیری|بارکد|تلفن|موبایل|همراه|شماره|'
    r'مقصد|مبدأ|مبدا|مبلغ|وزن|کرایه|پرداخت|در\s*محل|تومان|ریال|تاریخ|ساعت|دفتر|'
    r'اداره|شرکت|جمهوری|اسلامی|ایران|ارسال|تحویل|سفارش|شناسه|مشتری|خدمات)',
    caseSensitive: false,
  );

  static String _digits(String value) {
    var s = value;
    for (var i = 0; i < 10; i++) {
      s = s.replaceAll(_faDigits[i], '$i').replaceAll(_arDigits[i], '$i');
    }
    return s;
  }

  static String _normalizeLetters(String value) => value
      .replaceAll('ي', 'ی')
      .replaceAll('ى', 'ی')
      .replaceAll('ك', 'ک')
      .replaceAll('ۀ', 'ه')
      .replaceAll('ة', 'ه')
      .replaceAll(RegExp(r'[\u200c\u200e\u200f]'), ' ')
      .replaceAll(RegExp(r'[ \t]+'), ' ')
      .trim();

  static String _compactText(Iterable<String> texts) {
    final seen = <String>{};
    final out = <String>[];
    for (final text in texts) {
      for (final raw in text.split(RegExp(r'[\r\n]+'))) {
        final line = _normalizeLetters(raw);
        if (line.length < 2) continue;
        final key = line.toLowerCase();
        if (seen.add(key)) out.add(line);
      }
    }
    return out.join('\n');
  }

  static double _clamp01(num value) => value.clamp(0, 1).toDouble();

  // -------------------------------------------------------
  // OCR engines
  // -------------------------------------------------------
  static Future<String> _persianOcr(
    String path, {
    int psm = 6,
    bool digitsOnly = false,
  }) async {
    try {
      final args = <String, dynamic>{
        'psm': '$psm',
        'preserve_interword_spaces': '1',
        'user_defined_dpi': '300',
      };
      if (digitsOnly) {
        args['tessedit_char_whitelist'] =
            '0123456789۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩+-() ';
      }
      return (await FlutterTesseractOcr.extractText(
        path,
        language: 'fas',
        args: args,
      ))
          .trim();
    } catch (_) {
      return '';
    }
  }

  static Future<String> _mlText(TextRecognizer recognizer, String path) async {
    try {
      return (await recognizer.processImage(InputImage.fromFilePath(path)))
          .text
          .trim();
    } catch (_) {
      return '';
    }
  }

  // -------------------------------------------------------
  // Barcode engines
  // -------------------------------------------------------
  static Future<List<String>> _mlBarcodes(
    BarcodeScanner scanner,
    String path,
  ) async {
    try {
      final found =
          await scanner.processImage(InputImage.fromFilePath(path));
      return found
          .map((b) => (b.rawValue ?? '').trim())
          .where((e) => e.isNotEmpty)
          .toSet()
          .toList();
    } catch (_) {
      return const [];
    }
  }

  static Future<String> _zxingBarcode(String path) async {
    try {
      final result = await zxing.zx.readBarcodeImagePathString(
        path,
        zxing.DecodeParams(
          format: zxing.Format.any,
          tryHarder: true,
          tryRotate: true,
          tryInverted: true,
          tryDownscale: true,
          maxSize: 2048,
        ),
      );
      if (!result.isValid) return '';
      return (result.text ?? '').trim();
    } catch (_) {
      return '';
    }
  }

  static String _normalizeTracking(String raw) => _digits(raw)
      .replaceAll(RegExp(r'[\s،٬,._/:\\]+'), '')
      .replaceAll(RegExp(r'[^A-Za-z0-9\-]'), '')
      .trim();

  static void _addBarcode(
    Map<String, double> votes,
    String raw,
    double weight,
  ) {
    final value = _normalizeTracking(raw);
    if (value.length < 6 || value.length > 64) return;
    votes[value] = (votes[value] ?? 0) + weight;
  }

  static List<String> _sortedBarcodes(Map<String, double> votes) {
    final rows = votes.entries.toList()
      ..sort((a, b) {
        final byScore = b.value.compareTo(a.value);
        return byScore != 0
            ? byScore
            : b.key.length.compareTo(a.key.length);
      });
    return rows.map((e) => e.key).toList();
  }

  // -------------------------------------------------------
  // Lightweight image fallback.
  // It runs in a background isolate and NEVER upscales photos.
  // -------------------------------------------------------
  static Future<String?> _makeEnhancedVariant(String sourcePath) async {
    return Isolate.run<String?>(() async {
      try {
        final bytes = await File(sourcePath).readAsBytes();
        var decoded = img.decodeImage(bytes);
        if (decoded == null) return null;
        decoded = img.bakeOrientation(decoded);

        if (decoded.width > 2800) {
          decoded = img.copyResize(
            decoded,
            width: 2200,
            interpolation: img.Interpolation.linear,
          );
        }

        final enhanced = img.Image.from(decoded);
        img.grayscale(enhanced);
        img.contrast(enhanced, contrast: 125);
        img.adjustColor(
          enhanced,
          brightness: 1.03,
          gamma: .96,
          contrast: 1.08,
        );

        final file = File(
          '${Directory.systemTemp.path}/post_scan_v43_${DateTime.now().microsecondsSinceEpoch}.jpg',
        );
        await file.writeAsBytes(
          img.encodeJpg(enhanced, quality: 93),
          flush: true,
        );
        return file.path;
      } catch (_) {
        return null;
      }
    });
  }

  static Future<void> _deleteTemp(String? path) async {
    if (path == null || path.isEmpty) return;
    try {
      final file = File(path);
      if (await file.exists()) await file.delete();
    } catch (_) {}
  }

  // -------------------------------------------------------
  // Field parsing
  // -------------------------------------------------------
  static String _normalizePhone(String raw) {
    var p = _digits(raw).replaceAll(RegExp(r'\D'), '');
    if (p.startsWith('0098') && p.length == 14) {
      p = '0${p.substring(4)}';
    } else if (p.startsWith('98') && p.length == 12) {
      p = '0${p.substring(2)}';
    } else if (p.length == 10 && p.startsWith('9')) {
      p = '0$p';
    }
    return RegExp(r'^09\d{9}$').hasMatch(p) ? p : '';
  }

  static _Candidate _bestPhone(List<String> texts) {
    final scores = <String, double>{};
    final mobilePattern = RegExp(
      r'(?:^|[^\d])((?:\+?98|0098|98|0)?9(?:[\s\-\.\(\)]*\d){9})(?!\d)',
    );

    for (final text in texts) {
      for (final rawLine in text.split(RegExp(r'[\r\n]+'))) {
        final line = _digits(rawLine);
        final labeled = RegExp(
          r'(?:موبایل|همراه|تلفن|شماره\s*(?:گیرنده|تماس)?)',
          caseSensitive: false,
        ).hasMatch(line);

        for (final match in mobilePattern.allMatches(line)) {
          final phone = _normalizePhone(match.group(1) ?? '');
          if (phone.isEmpty) continue;
          scores[phone] =
              (scores[phone] ?? 0) + (labeled ? 4.0 : 2.1);
        }
      }
    }

    if (scores.isEmpty) return _Candidate('', 0);
    final best =
        scores.entries.reduce((a, b) => a.value >= b.value ? a : b);
    return _Candidate(best.key, best.value);
  }

  static String _cleanName(String raw) {
    var value = _normalizeLetters(raw)
        .replaceAll(RegExp(r'[0-9۰-۹٠-٩]'), ' ')
        .replaceAll(RegExp(r'[^\u0600-\u06FF\s]'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();

    value = value
        .replaceFirst(
          RegExp(
            r'^(?:گیرنده|نام\s*گیرنده|تحویل\s*گیرنده|نام\s*و\s*نام\s*خانوادگی)\s*',
            caseSensitive: false,
          ),
          '',
        )
        .trim();

    if (value.isEmpty || _postalNoise.hasMatch(value)) return '';

    final tokens =
        value.split(' ').where((e) => e.trim().isNotEmpty).toList();
    if (tokens.length < 2 || tokens.length > 5) return '';
    if (tokens.any((token) => token.length < 2)) return '';
    if (value.length < 5 || value.length > 60) return '';

    final letters =
        RegExp(r'[\u0600-\u06FF]').allMatches(value).length;
    if (letters < 5) return '';
    return value;
  }

  static _Candidate _bestName(List<String> texts) {
    final scores = <String, double>{};

    void add(String raw, double score) {
      final name = _cleanName(raw);
      if (name.isEmpty) return;
      scores[name] = (scores[name] ?? 0) + score;
    }

    final inline = RegExp(
      r'(?:گیرنده|نام\s*گیرنده|تحویل\s*گیرنده|نام\s*و\s*نام\s*خانوادگی)\s*[:：\-]?\s*(.+)$',
      caseSensitive: false,
    );

    for (final text in texts) {
      final lines = text
          .split(RegExp(r'[\r\n]+'))
          .map(_normalizeLetters)
          .where((e) => e.length >= 3)
          .toList();

      for (var i = 0; i < lines.length; i++) {
        final line = lines[i];
        final direct = inline.firstMatch(line);
        if (direct != null) {
          add(direct.group(1) ?? '', 8.0);
        }

        if (RegExp(
          r'^(?:گیرنده|نام\s*گیرنده|تحویل\s*گیرنده|نام\s*و\s*نام\s*خانوادگی)\s*[:：\-]?$',
          caseSensitive: false,
        ).hasMatch(line)) {
          if (i + 1 < lines.length) add(lines[i + 1], 7.0);
        }
      }

      // Restore the successful v39 behavior: a plausible Persian 2–5 word
      // line can be a name even when there is no printed "گیرنده" label.
      // Obvious postal/noise text and one-letter garbage are still rejected.
      for (final line in lines) {
        if (!RegExp(r'[\u0600-\u06FF]').hasMatch(line)) continue;
        if (_postalNoise.hasMatch(line)) continue;
        final cleaned = _cleanName(line);
        if (cleaned.isNotEmpty) {
          final words = cleaned.split(' ').length;
          add(cleaned, words <= 3 ? 3.0 : 2.6);
        }
      }
    }

    if (scores.isEmpty) return _Candidate('', 0);
    final ordered = scores.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    final best = ordered.first;

    // Much less aggressive than v40/v41. Bad one-letter fragments are
    // rejected by _cleanName, while a normal single-pass name is accepted.
    if (best.value < 2.5) return _Candidate('', best.value);
    return _Candidate(best.key, best.value);
  }

  static _Candidate _bestPaymentType(List<String> texts) {
    var cod = 0.0;
    var destination = 0.0;

    for (final text in texts) {
      final value = _normalizeLetters(text.replaceAll('\n', ' '));
      if (RegExp(
        r'پرداخت\s*در\s*محل|COD',
        caseSensitive: false,
      ).hasMatch(value)) {
        cod += 3;
      }
      if (RegExp(
        r'کرایه\s*در\s*مقصد|پس\s*کرایه|کرایه.*مقصد',
        caseSensitive: false,
      ).hasMatch(value)) {
        destination += 3;
      }
    }

    if (cod == 0 && destination == 0) return _Candidate('', 0);
    return cod >= destination
        ? _Candidate('پرداخت در محل', cod)
        : _Candidate('کرایه در مقصد', destination);
  }

  static _Candidate _bestTracking(
    List<String> texts,
    Map<String, double> barcodeVotes,
    String phone,
  ) {
    final scores = <String, double>{};

    for (final entry in barcodeVotes.entries) {
      final value = _normalizeTracking(entry.key);
      if (value.isEmpty || value == phone) continue;
      var score = entry.value * 2;
      if (RegExp(r'^\d{18,32}$').hasMatch(value)) score += 5;
      if (value.length == 24) score += 2;
      scores[value] = (scores[value] ?? 0) + score;
    }

    for (final text in texts) {
      for (final rawLine in text.split(RegExp(r'[\r\n]+'))) {
        final line = _digits(rawLine);

        final labeled = RegExp(
          r'(?:کد\s*رهگیری|رهگیری|بارکد|کد\s*مرسوله|tracking)\s*[:：\-]?\s*([A-Za-z0-9۰-۹٠-٩\s\-،٬,]{8,48})',
          caseSensitive: false,
        ).firstMatch(line);
        if (labeled != null) {
          final value = _normalizeTracking(labeled.group(1) ?? '');
          if (value.length >= 8 &&
              value.length <= 40 &&
              value != phone) {
            scores[value] = (scores[value] ?? 0) + 6.0;
          }
        }

        for (final match in RegExp(
          r'(?:^|[^\d])((?:\d[\s\-،٬,]?){18,32})(?!\d)',
        ).allMatches(line)) {
          final value = _normalizeTracking(match.group(1) ?? '');
          if (value == phone || value.length < 18 || value.length > 32) {
            continue;
          }
          var score = 2.4;
          if (RegExp(r'بارکد|رهگیری|کد').hasMatch(line)) score += 3.5;
          if (value.length == 24) score += 1.5;
          scores[value] = (scores[value] ?? 0) + score;
        }
      }
    }

    if (scores.isEmpty) return _Candidate('', 0);
    final ordered = scores.entries.toList()
      ..sort((a, b) {
        final byScore = b.value.compareTo(a.value);
        return byScore != 0
            ? byScore
            : b.key.length.compareTo(a.key.length);
      });
    return _Candidate(ordered.first.key, ordered.first.value);
  }

  static int _occurrences(String needle, List<String> texts) {
    if (needle.isEmpty) return 0;
    final n = _normalizeLetters(_digits(needle))
        .replaceAll(RegExp(r'\s+'), '');
    var count = 0;
    for (final text in texts) {
      final hay = _normalizeLetters(_digits(text))
          .replaceAll(RegExp(r'\s+'), '');
      if (hay.contains(n)) count++;
    }
    return count;
  }

  static _ParsedFields _parse(
    List<String> texts,
    Map<String, double> barcodeVotes,
  ) {
    final phone = _bestPhone(texts);
    final name = _bestName(texts);
    final payment = _bestPaymentType(texts);
    final tracking = _bestTracking(texts, barcodeVotes, phone.value);

    final barcodeScore = barcodeVotes[tracking.value] ?? 0;
    final trackingFromOcr =
        tracking.value.isNotEmpty && barcodeScore == 0;

    final phoneAgreement = _occurrences(phone.value, texts);
    final nameAgreement = _occurrences(name.value, texts);
    final trackingAgreement = _occurrences(tracking.value, texts);

    final phoneConfidence = phone.value.isEmpty
        ? 0.0
        : _clamp01(
            .60 +
                phone.score / 14 +
                (phoneAgreement >= 2 ? .12 : 0),
          );

    final nameConfidence = name.value.isEmpty
        ? 0.0
        : _clamp01(
            .48 +
                name.score / 18 +
                (nameAgreement >= 2 ? .12 : 0),
          );

    final trackingConfidence = tracking.value.isEmpty
        ? 0.0
        : _clamp01(
            (barcodeScore > 0 ? .62 : .42) +
                tracking.score / 38 +
                (trackingAgreement >= 2 ? .08 : 0),
          );

    final paymentConfidence = payment.value.isEmpty
        ? 0.0
        : _clamp01(.58 + payment.score / 14);

    return _ParsedFields(
      fullname: name.value,
      phone: phone.value,
      paymentType: payment.value,
      tracking: tracking.value,
      nameConfidence: nameConfidence,
      phoneConfidence: phoneConfidence,
      paymentConfidence: paymentConfidence,
      trackingConfidence: trackingConfidence,
      trackingFromOcr: trackingFromOcr,
    );
  }

  static double _overall(_ParsedFields parsed) {
    var score = 0.0;
    var weight = 0.0;

    if (parsed.phone.isNotEmpty) {
      score += .30 * parsed.phoneConfidence;
      weight += .30;
    }
    if (parsed.fullname.isNotEmpty) {
      score += .28 * parsed.nameConfidence;
      weight += .28;
    }
    if (parsed.tracking.isNotEmpty) {
      score += .32 * parsed.trackingConfidence;
      weight += .32;
    }
    if (parsed.paymentType.isNotEmpty) {
      score += .10 * parsed.paymentConfidence;
      weight += .10;
    }

    return weight == 0 ? 0 : _clamp01(score / weight);
  }

  static List<String> _warnings(
    _ParsedFields parsed,
    bool hardBarcode,
  ) {
    final out = <String>[];

    if (parsed.fullname.isEmpty) {
      out.add('نام گیرنده تشخیص داده نشد؛ دستی بررسی شود.');
    } else if (parsed.nameConfidence < .58) {
      out.add('نام گیرنده نیاز به بازبینی دارد.');
    }

    if (parsed.phone.isEmpty) {
      out.add('شماره موبایل معتبر استخراج نشد.');
    } else if (parsed.phoneConfidence < .68) {
      out.add('شماره موبایل نیاز به بازبینی دارد.');
    }

    if (parsed.tracking.isEmpty) {
      out.add('بارکد/کدرهگیری پیدا نشد.');
    } else if (parsed.trackingFromOcr) {
      out.add(
        'بارکد مستقیم Decode نشد؛ کدرهگیری از نوشته/اعداد روی برچسب خوانده شد.',
      );
    }

    if (hardBarcode) {
      out.add('برای بارکد از حالت سخت‌گیرانه رایگان استفاده شد.');
    }

    return out;
  }

  // -------------------------------------------------------
  // Fast-first pipeline
  // -------------------------------------------------------
  static Future<ScannedShipmentDraft> scan(XFile file) async {
    final textRecognizer =
        TextRecognizer(script: TextRecognitionScript.latin);
    final barcodeScanner =
        BarcodeScanner(formats: [BarcodeFormat.all]);

    final texts = <String>[];
    final barcodeVotes = <String, double>{};
    String? enhancedPath;
    var hardBarcode = false;

    try {
      // Fast core restored from the better v39 scanner:
      // ML text + ML barcode + Persian Tesseract run in parallel on ORIGINAL.
      final fast = await Future.wait<dynamic>([
        _mlText(textRecognizer, file.path),
        _mlBarcodes(barcodeScanner, file.path),
        _persianOcr(file.path, psm: 6),
      ]);

      final latinText = (fast[0] as String).trim();
      final mlCodes = (fast[1] as List<String>);
      final persianText = (fast[2] as String).trim();

      if (persianText.isNotEmpty) texts.add(persianText);
      if (latinText.isNotEmpty) texts.add(latinText);
      for (final code in mlCodes) {
        _addBarcode(barcodeVotes, code, 4.0);
      }

      var parsed = _parse(texts, barcodeVotes);

      // Only missing barcode/tracking gets ZXing on the original photo.
      if (parsed.tracking.isEmpty || barcodeVotes.isEmpty) {
        final zxingCode = await _zxingBarcode(file.path);
        if (zxingCode.isNotEmpty) {
          _addBarcode(barcodeVotes, zxingCode, 5.0);
          parsed = _parse(texts, barcodeVotes);
        }
      }

      // If text fields are still missing, one sparse OCR pass on original.
      // No image decoding or preprocessing is needed for this step.
      if (parsed.fullname.isEmpty || parsed.phone.isEmpty) {
        final sparse = await _persianOcr(file.path, psm: 11);
        if (sparse.isNotEmpty) {
          texts.add(sparse);
          parsed = _parse(texts, barcodeVotes);
        }
      }

      // Deep fallback is truly lazy. It only happens when important fields
      // are still missing after the original-image pipeline.
      final needsTextFallback =
          parsed.fullname.isEmpty || parsed.phone.isEmpty;
      final needsTrackingFallback = parsed.tracking.isEmpty;

      if (needsTextFallback || needsTrackingFallback) {
        enhancedPath = await _makeEnhancedVariant(file.path);

        if (enhancedPath != null) {
          if (needsTrackingFallback) {
            hardBarcode = true;
            final fallbackCodes =
                await _mlBarcodes(barcodeScanner, enhancedPath);
            for (final code in fallbackCodes) {
              _addBarcode(barcodeVotes, code, 3.0);
            }
            final hardCode = await _zxingBarcode(enhancedPath);
            if (hardCode.isNotEmpty) {
              _addBarcode(barcodeVotes, hardCode, 4.5);
            }
          }

          if (needsTextFallback) {
            final fallback = await Future.wait<String>([
              _persianOcr(enhancedPath, psm: 11),
              _mlText(textRecognizer, enhancedPath),
            ]);
            for (final text in fallback) {
              if (text.trim().isNotEmpty) texts.add(text.trim());
            }
          }

          parsed = _parse(texts, barcodeVotes);
        }
      }

      final codes = _sortedBarcodes(barcodeVotes);
      final confidence = _overall(parsed);

      return ScannedShipmentDraft(
        file: file,
        rawText: _compactText(texts),
        barcodes: codes,
        fullname: parsed.fullname,
        phone: parsed.phone,
        paymentType: parsed.paymentType,
        trackingCode: parsed.tracking,
        confidence: confidence,
        nameConfidence: parsed.nameConfidence,
        phoneConfidence: parsed.phoneConfidence,
        trackingConfidence: parsed.trackingConfidence,
        paymentConfidence: parsed.paymentConfidence,
        usedHardBarcodeFallback: hardBarcode,
        trackingFromOcrFallback: parsed.trackingFromOcr,
        warnings: _warnings(parsed, hardBarcode),
      );
    } finally {
      await textRecognizer.close();
      await barcodeScanner.close();
      await _deleteTemp(enhancedPath);
    }
  }

  static Future<List<ScannedShipmentDraft>> scanBatch(
    List<XFile> files,
  ) async {
    final out = <ScannedShipmentDraft>[];
    for (final file in files) {
      try {
        out.add(await scan(file));
      } catch (_) {
        out.add(ScannedShipmentDraft.failed(file));
      }
    }
    return out;
  }
}
