POST MANAGEMENT v44 / BACKEND v67

اصلاح 1 — روستا:
- save_user.php قبل از ذخیره وجود ستون‌های work_scope و village_name را اجباری بررسی می‌کند.
- ذخیره داخل Transaction انجام می‌شود.
- بعد از INSERT/UPDATE همان رکورد دوباره از DB خوانده می‌شود.
- اگر village واقعاً در DB ذخیره نشده باشد، Transaction Rollback می‌شود و موفق اعلام نمی‌شود.
- پاسخ Backend شامل scope_verified=true و stored_work_scope/stored_village_name است.
- Flutter قبل از پاک کردن فرم، پاسخ ذخیره واقعی DB را بررسی می‌کند.
- اگر Backend قدیمی باشد، فرم پاک نمی‌شود و هشدار واضح نمایش داده می‌شود.
- users.php نیز scope_schema_version=2 و scope_storage_verified=true برمی‌گرداند.
- scope_health.php برای بررسی سریع ساختار حوزه کاربران اضافه شد.

اصلاح 2 — برگشت پنل ادمین:
- Back داخل کاربران/پرداخت‌ها/لاگ‌ها/پیام‌ها/مرسولات/کلمات فقط به «مرکز مدیریت» برمی‌گردد.
- فقط Back از خود «مرکز مدیریت» وارد پنل کاربری می‌شود.
- گزینه صریح «بازگشت به پنل کاربری» در Drawer همچنان خروج عمدی است.
- دیگر برای برگشت بین صفحات داخلی نیاز به 7 ضربه مجدد نیست.

Workflow:
- هیچ تغییری نکرده است.
- فایل Workflow داخل پکیج دقیقاً همان Workflow v43 قبلی است.
