POST MANAGEMENT v45 / BACKEND v68

- پیام‌های کارکنان شهرستان اصلی با scope=main مشترک نمایش داده می‌شوند.
- خطاهای SQL در sms_import_local.php و sms_sync_panel_history.php اصلاح شدند.
- scope_key در Import/Sync واقعاً ذخیره می‌شود.
- داده‌های قدیمی پیام و مرسوله بر اساس created_by به scope درست Repair می‌شوند.
- Flutter برای لیست پیام‌ها و مرسولات دیگر mine=1 نمی‌فرستد.
- Cache آفلاین بر اساس حوزه ذخیره می‌شود.
- تحویل سریع اگر مرسوله موجود نداشته باشد، یک رکورد واقعی shipments با status=delivered می‌سازد.
- quick_deliveries به shipment_id واقعی متصل می‌شود.
- Flutter shipment_id واقعی را قبل از اعلام موفقیت کنترل می‌کند.
- Workflow بدون هیچ تغییر حفظ شده است.
