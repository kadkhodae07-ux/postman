POST MANAGEMENT v34 HOTFIX

علت خطای v33:
1) flutter_contacts 1.1.9+2 متد درج مخاطب را روی خود Contact ارائه می‌کند:
   contact.insert()
   و FlutterContacts.insert(contact) در این نسخه وجود ندارد.
2) چون سورس Android داخل ZIP نبود، Workflow دستور flutter create را اجرا می‌کرد.
   flutter create فایل test/widget_test.dart پیش‌فرض می‌ساخت که به MyApp و flutter_test وابسته بود
   و باعث چندین خطای flutter analyze می‌شد.

اصلاح v34:
- FlutterContacts.insert(contact) -> contact.insert()
- حذف import غیرضروری dart:typed_data
- Workflow قبل از flutter create وجود test/ را ثبت می‌کند.
- اگر سورس اصلی test/ نداشته باشد، تست پیش‌فرض تولیدشده توسط flutter create حذف می‌شود.
- تست‌های واقعی پروژه، اگر از قبل وجود داشته باشند، حذف نمی‌شوند.
- version: 1.0.34+34
- نام APK خروجی: post-management-v34.apk

Backend v59 بدون تغییر باقی مانده است.
