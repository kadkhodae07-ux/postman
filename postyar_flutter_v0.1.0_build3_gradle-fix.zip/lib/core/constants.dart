class AppConstants {
  static const appName = 'پست‌یار';
  static const version = '0.1.0';

  static const parcelTypes = <String, String>{
    'package': 'بسته',
    'envelope': 'پاکت',
    'fuel_card': 'کارت سوخت',
    'plate_card': 'کارت پلاک',
    'green_card': 'برگ سبز',
    'bank_card': 'کارت بانکی',
    'sim_card': 'سیم‌کارت',
    'other': 'سایر',
  };

  static const bankNames = <String>[
    'بانک ملی',
    'بانک ملت',
    'بانک صادرات',
    'بانک تجارت',
    'بانک سپه',
    'بانک کشاورزی',
    'بانک مسکن',
    'بانک رفاه',
    'بانک شهر',
    'بانک پاسارگاد',
    'بانک سامان',
    'بانک پارسیان',
    'بانک اقتصاد نوین',
    'بانک آینده',
    'بانک مهر ایران',
    'بانک رسالت',
    'سایر بانک‌ها',
  ];

  static const paymentTypes = <String, String>{
    'none': 'بدون هزینه',
    'destination': 'کرایه در مقصد',
    'cod': 'پرداخت در محل',
  };

  static const statusLabels = <String, String>{
    'received': 'دریافت‌شده',
    'transferred': 'ارسال به واحد',
    'accepted_by_unit': 'تحویل به واحد مقصد',
    'notified': 'اطلاع‌رسانی‌شده',
    'delivered': 'تحویل‌شده',
    'returned': 'برگشتی',
    'review': 'نیازمند بررسی',
  };
}
