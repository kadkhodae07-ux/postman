import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

import '../models/app_user.dart';
import '../models/parcel.dart';
import '../services/api_service.dart';
import '../services/auth_service.dart';
import '../services/local_database.dart';
import '../services/sync_service.dart';

class AppState extends ChangeNotifier {
  Timer? _syncDebounce;
  AppUser? user;
  bool initialized = false;
  bool busy = false;
  String? error;
  List<Parcel> parcels = const [];
  Map<String, int> counts = const {};
  List<Map<String, dynamic>> units = const [];
  List<Map<String, dynamic>> users = const [];

  bool get loggedIn => user != null;

  Future<void> initialize() async {
    user = await AuthService.instance.cachedUser();
    if (user != null) {
      await refreshLocal();
      await loadRemoteMetadata(silent: true);
    }
    initialized = true;
    notifyListeners();
  }

  Future<void> login({
    required String serverUrl,
    required String username,
    required String password,
  }) async {
    busy = true;
    error = null;
    notifyListeners();
    try {
      await ApiService.instance.setBaseUrl(serverUrl);
      user = await AuthService.instance.login(username, password);
      await refreshLocal();
      await loadRemoteMetadata(silent: true);
      try {
        await synchronize();
      } catch (_) {}
    } catch (e) {
      error = e.toString();
      rethrow;
    } finally {
      busy = false;
      notifyListeners();
    }
  }

  Future<void> logout() async {
    await AuthService.instance.logout();
    user = null;
    units = const [];
    users = const [];
    notifyListeners();
  }

  Future<void> refreshLocal({String? status, String? query}) async {
    final current = user;
    final unitId = current != null && !current.isCityAdmin ? current.unitId : null;
    parcels = await LocalDatabase.instance.listParcels(
      status: status,
      query: query,
      unitId: unitId,
    );
    counts = await LocalDatabase.instance.dashboardCounts(unitId: unitId);
    notifyListeners();
  }

  Future<void> saveParcel({
    Parcel? existing,
    required String trackingNumber,
    required String barcode,
    required String recipientName,
    required String phone,
    required String parcelType,
    required String bankName,
    required int sizeCode,
    required String paymentType,
    required int amount,
    required int unitId,
    required String unitName,
    required String storageLocation,
    required String notes,
    String? imagePath,
    double ocrConfidence = 0,
  }) async {
    final current = user;
    if (current == null) throw StateError('کاربر وارد نشده است.');
    final tracking = trackingNumber.trim();
    if (tracking.isNotEmpty &&
        await LocalDatabase.instance.trackingExists(
          tracking,
          exceptLocalId: existing?.localId,
        )) {
      throw StateError('این شماره مرسوله قبلاً ثبت شده است.');
    }
    final parcel = Parcel(
      localId: existing?.localId ?? const Uuid().v4(),
      serverId: existing?.serverId,
      trackingNumber: tracking,
      barcode: barcode.trim(),
      recipientName: recipientName.trim(),
      phone: phone.trim(),
      parcelType: parcelType,
      bankName: bankName,
      sizeCode: sizeCode,
      paymentType: paymentType,
      amount: amount,
      unitId: unitId,
      unitName: unitName,
      storageLocation: storageLocation.trim(),
      status: current.isCityAdmin && unitId != current.unitId && (existing == null || existing.unitId != unitId)
          ? 'transferred'
          : (existing?.status ?? 'received'),
      receivedAt: existing?.receivedAt ?? DateTime.now(),
      createdByName: existing?.createdByName ?? current.fullName,
      labelImagePath: imagePath ?? existing?.labelImagePath,
      notes: notes.trim(),
      notifiedAt: existing?.notifiedAt,
      deliveredAt: existing?.deliveredAt,
      deliveredToName: existing?.deliveredToName,
      deliveredToPhone: existing?.deliveredToPhone,
      deliverySignaturePath: existing?.deliverySignaturePath,
      syncStatus: 'pending',
      ocrConfidence: ocrConfidence,
    );
    await LocalDatabase.instance.upsertParcel(parcel);
    await refreshLocal();
    _scheduleSync();
  }

  Future<void> markNotified(Parcel parcel) async {
    await LocalDatabase.instance.upsertParcel(
      parcel.copyWith(
        status: parcel.status == 'delivered' ? parcel.status : 'notified',
        notifiedAt: DateTime.now(),
        syncStatus: 'pending',
      ),
    );
    await refreshLocal();
    _scheduleSync();
  }

  Future<void> acceptAtUnit(Parcel parcel) async {
    final current = user;
    if (current == null || current.unitId != parcel.unitId) {
      throw StateError('این مرسوله متعلق به واحد شما نیست.');
    }
    if (parcel.status != 'transferred') return;
    await LocalDatabase.instance.upsertParcel(
      parcel.copyWith(status: 'accepted_by_unit', syncStatus: 'pending'),
    );
    await refreshLocal();
    _scheduleSync();
  }

  Future<void> deliverParcel({
    required Parcel parcel,
    required String receiverName,
    required String receiverPhone,
  }) async {
    if (parcel.isDelivered) throw StateError('این مرسوله قبلاً تحویل شده است.');
    await LocalDatabase.instance.upsertParcel(
      parcel.copyWith(
        status: 'delivered',
        deliveredAt: DateTime.now(),
        deliveredToName: receiverName.trim(),
        deliveredToPhone: receiverPhone.trim(),
        syncStatus: 'pending',
      ),
    );
    await refreshLocal();
    _scheduleSync();
  }

  void _scheduleSync() {
    _syncDebounce?.cancel();
    _syncDebounce = Timer(const Duration(seconds: 3), () async {
      try {
        await SyncService.instance.sync();
        await refreshLocal();
      } catch (_) {
        // اطلاعات در صف آفلاین باقی می‌ماند و در همگام‌سازی بعدی ارسال می‌شود.
      }
    });
  }

  @override
  void dispose() {
    _syncDebounce?.cancel();
    super.dispose();
  }

  Future<SyncReport> synchronize() async {
    busy = true;
    error = null;
    notifyListeners();
    try {
      final report = await SyncService.instance.sync();
      await refreshLocal();
      await loadRemoteMetadata(silent: true);
      return report;
    } catch (e) {
      error = e.toString();
      rethrow;
    } finally {
      busy = false;
      notifyListeners();
    }
  }

  Future<void> loadRemoteMetadata({bool silent = false}) async {
    if (!silent) {
      busy = true;
      notifyListeners();
    }
    try {
      units = await ApiService.instance.listUnits();
      if (user?.isCityAdmin == true) {
        users = await ApiService.instance.listUsers();
      }
    } catch (_) {
      if (units.isEmpty && user != null) {
        units = [
          {'id': user!.unitId, 'name': user!.unitName, 'code': ''}
        ];
      }
    } finally {
      if (!silent) {
        busy = false;
        notifyListeners();
      }
    }
  }

  Future<void> createUnit(Map<String, dynamic> data) async {
    await ApiService.instance.createUnit(data);
    units = await ApiService.instance.listUnits();
    notifyListeners();
  }

  Future<void> createUser(Map<String, dynamic> data) async {
    await ApiService.instance.createUser(data);
    users = await ApiService.instance.listUsers();
    notifyListeners();
  }

  Future<String> apiBaseUrl() => ApiService.instance.baseUrl;

  Future<void> setSmsTemplate(String value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('sms_template', value);
  }

  Future<String> smsTemplate() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('sms_template') ??
        'سلام {name}، مرسوله شما با شماره {tracking} به {unit} رسیده است. لطفاً برای تحویل مراجعه کنید.{amount}';
  }
}
