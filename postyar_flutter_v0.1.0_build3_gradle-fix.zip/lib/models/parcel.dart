import 'dart:convert';

class Parcel {
  const Parcel({
    required this.localId,
    this.serverId,
    required this.trackingNumber,
    required this.barcode,
    required this.recipientName,
    required this.phone,
    required this.parcelType,
    this.bankName = '',
    required this.sizeCode,
    required this.paymentType,
    required this.amount,
    required this.unitId,
    required this.unitName,
    required this.storageLocation,
    required this.status,
    required this.receivedAt,
    required this.createdByName,
    this.labelImagePath,
    this.notes = '',
    this.notifiedAt,
    this.deliveredAt,
    this.deliveredToName,
    this.deliveredToPhone,
    this.deliverySignaturePath,
    this.syncStatus = 'pending',
    this.ocrConfidence = 0,
  });

  final String localId;
  final int? serverId;
  final String trackingNumber;
  final String barcode;
  final String recipientName;
  final String phone;
  final String parcelType;
  final String bankName;
  final int sizeCode;
  final String paymentType;
  final int amount;
  final int unitId;
  final String unitName;
  final String storageLocation;
  final String status;
  final DateTime receivedAt;
  final String createdByName;
  final String? labelImagePath;
  final String notes;
  final DateTime? notifiedAt;
  final DateTime? deliveredAt;
  final String? deliveredToName;
  final String? deliveredToPhone;
  final String? deliverySignaturePath;
  final String syncStatus;
  final double ocrConfidence;

  bool get hasPayment => amount > 0 || paymentType != 'none';
  bool get isDelivered => status == 'delivered';
  bool get needsReview => ocrConfidence > 0 && ocrConfidence < 0.72;

  Parcel copyWith({
    int? serverId,
    String? trackingNumber,
    String? barcode,
    String? recipientName,
    String? phone,
    String? parcelType,
    String? bankName,
    int? sizeCode,
    String? paymentType,
    int? amount,
    int? unitId,
    String? unitName,
    String? storageLocation,
    String? status,
    DateTime? receivedAt,
    String? createdByName,
    String? labelImagePath,
    String? notes,
    DateTime? notifiedAt,
    DateTime? deliveredAt,
    String? deliveredToName,
    String? deliveredToPhone,
    String? deliverySignaturePath,
    String? syncStatus,
    double? ocrConfidence,
  }) =>
      Parcel(
        localId: localId,
        serverId: serverId ?? this.serverId,
        trackingNumber: trackingNumber ?? this.trackingNumber,
        barcode: barcode ?? this.barcode,
        recipientName: recipientName ?? this.recipientName,
        phone: phone ?? this.phone,
        parcelType: parcelType ?? this.parcelType,
        bankName: bankName ?? this.bankName,
        sizeCode: sizeCode ?? this.sizeCode,
        paymentType: paymentType ?? this.paymentType,
        amount: amount ?? this.amount,
        unitId: unitId ?? this.unitId,
        unitName: unitName ?? this.unitName,
        storageLocation: storageLocation ?? this.storageLocation,
        status: status ?? this.status,
        receivedAt: receivedAt ?? this.receivedAt,
        createdByName: createdByName ?? this.createdByName,
        labelImagePath: labelImagePath ?? this.labelImagePath,
        notes: notes ?? this.notes,
        notifiedAt: notifiedAt ?? this.notifiedAt,
        deliveredAt: deliveredAt ?? this.deliveredAt,
        deliveredToName: deliveredToName ?? this.deliveredToName,
        deliveredToPhone: deliveredToPhone ?? this.deliveredToPhone,
        deliverySignaturePath:
            deliverySignaturePath ?? this.deliverySignaturePath,
        syncStatus: syncStatus ?? this.syncStatus,
        ocrConfidence: ocrConfidence ?? this.ocrConfidence,
      );

  Map<String, dynamic> toMap() => {
        'local_id': localId,
        'server_id': serverId,
        'tracking_number': trackingNumber,
        'barcode': barcode,
        'recipient_name': recipientName,
        'phone': phone,
        'parcel_type': parcelType,
        'bank_name': bankName,
        'size_code': sizeCode,
        'payment_type': paymentType,
        'amount': amount,
        'unit_id': unitId,
        'unit_name': unitName,
        'storage_location': storageLocation,
        'status': status,
        'received_at': receivedAt.toIso8601String(),
        'created_by_name': createdByName,
        'label_image_path': labelImagePath,
        'notes': notes,
        'notified_at': notifiedAt?.toIso8601String(),
        'delivered_at': deliveredAt?.toIso8601String(),
        'delivered_to_name': deliveredToName,
        'delivered_to_phone': deliveredToPhone,
        'delivery_signature_path': deliverySignaturePath,
        'sync_status': syncStatus,
        'ocr_confidence': ocrConfidence,
      };

  Map<String, dynamic> toApiJson() => {
        'client_id': localId,
        'tracking_number': trackingNumber,
        'barcode': barcode,
        'recipient_name': recipientName,
        'phone': phone,
        'parcel_type': parcelType,
        'bank_name': bankName,
        'size_code': sizeCode,
        'payment_type': paymentType,
        'amount': amount,
        'unit_id': unitId,
        'storage_location': storageLocation,
        'status': status,
        'received_at': receivedAt.toIso8601String(),
        'notes': notes,
        'notified_at': notifiedAt?.toIso8601String(),
        'delivered_at': deliveredAt?.toIso8601String(),
        'delivered_to_name': deliveredToName,
        'delivered_to_phone': deliveredToPhone,
        'ocr_confidence': ocrConfidence,
      };

  factory Parcel.fromMap(Map<String, dynamic> map) => Parcel(
        localId: map['local_id']?.toString() ?? '',
        serverId: (map['server_id'] as num?)?.toInt(),
        trackingNumber: map['tracking_number']?.toString() ?? '',
        barcode: map['barcode']?.toString() ?? '',
        recipientName: map['recipient_name']?.toString() ?? '',
        phone: map['phone']?.toString() ?? '',
        parcelType: map['parcel_type']?.toString() ?? 'package',
        bankName: map['bank_name']?.toString() ?? '',
        sizeCode: (map['size_code'] as num?)?.toInt() ?? 1,
        paymentType: map['payment_type']?.toString() ?? 'none',
        amount: (map['amount'] as num?)?.toInt() ?? 0,
        unitId: (map['unit_id'] as num?)?.toInt() ?? 0,
        unitName: map['unit_name']?.toString() ?? '',
        storageLocation: map['storage_location']?.toString() ?? '',
        status: map['status']?.toString() ?? 'received',
        receivedAt: DateTime.tryParse(map['received_at']?.toString() ?? '') ??
            DateTime.now(),
        createdByName: map['created_by_name']?.toString() ?? '',
        labelImagePath: map['label_image_path']?.toString(),
        notes: map['notes']?.toString() ?? '',
        notifiedAt: DateTime.tryParse(map['notified_at']?.toString() ?? ''),
        deliveredAt: DateTime.tryParse(map['delivered_at']?.toString() ?? ''),
        deliveredToName: map['delivered_to_name']?.toString(),
        deliveredToPhone: map['delivered_to_phone']?.toString(),
        deliverySignaturePath: map['delivery_signature_path']?.toString(),
        syncStatus: map['sync_status']?.toString() ?? 'synced',
        ocrConfidence: (map['ocr_confidence'] as num?)?.toDouble() ?? 0,
      );

  String encode() => jsonEncode(toMap());
}

class ScanResultData {
  const ScanResultData({
    required this.imagePath,
    required this.trackingNumber,
    required this.barcode,
    required this.recipientName,
    required this.phone,
    required this.amount,
    required this.paymentType,
    required this.rawText,
    required this.confidence,
    required this.warnings,
  });

  final String imagePath;
  final String trackingNumber;
  final String barcode;
  final String recipientName;
  final String phone;
  final int amount;
  final String paymentType;
  final String rawText;
  final double confidence;
  final List<String> warnings;
}
