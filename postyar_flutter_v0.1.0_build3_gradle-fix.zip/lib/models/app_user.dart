class AppUser {
  const AppUser({
    required this.id,
    required this.fullName,
    required this.username,
    required this.role,
    required this.unitId,
    required this.unitName,
    required this.isActive,
  });

  final int id;
  final String fullName;
  final String username;
  final String role;
  final int unitId;
  final String unitName;
  final bool isActive;

  bool get isCityAdmin => role == 'city_admin';

  factory AppUser.fromJson(Map<String, dynamic> json) => AppUser(
        id: (json['id'] as num).toInt(),
        fullName: json['full_name']?.toString() ?? '',
        username: json['username']?.toString() ?? '',
        role: json['role']?.toString() ?? 'unit_user',
        unitId: (json['unit_id'] as num?)?.toInt() ?? 0,
        unitName: json['unit_name']?.toString() ?? '',
        isActive: json['is_active'] == true || json['is_active'] == 1,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'full_name': fullName,
        'username': username,
        'role': role,
        'unit_id': unitId,
        'unit_name': unitName,
        'is_active': isActive ? 1 : 0,
      };
}
