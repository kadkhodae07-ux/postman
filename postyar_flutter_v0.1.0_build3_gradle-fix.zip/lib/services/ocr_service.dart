import 'dart:io';

import 'package:flutter_tesseract_ocr/flutter_tesseract_ocr.dart';
import 'package:google_mlkit_barcode_scanning/google_mlkit_barcode_scanning.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../models/parcel.dart';

class OcrService {
  OcrService._();
  static final OcrService instance = OcrService._();

  final ImagePicker _picker = ImagePicker();

  Future<ScanResultData?> captureAndExtract() async {
    final image = await _picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 90,
      maxWidth: 2400,
    );
    if (image == null) return null;
    final savedPath = await _persistImage(image);
    return extractFromPath(savedPath);
  }

  Future<ScanResultData?> pickAndExtract() async {
    final image = await _picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 94,
    );
    if (image == null) return null;
    final savedPath = await _persistImage(image);
    return extractFromPath(savedPath);
  }


  Future<String> _persistImage(XFile image) async {
    final root = await getApplicationDocumentsDirectory();
    final directory = Directory(p.join(root.path, 'parcel_labels'));
    if (!directory.existsSync()) {
      await directory.create(recursive: true);
    }
    final extension = p.extension(image.path).isEmpty ? '.jpg' : p.extension(image.path);
    final target = File(
      p.join(directory.path, 'label_${DateTime.now().microsecondsSinceEpoch}$extension'),
    );
    await File(image.path).copy(target.path);
    return target.path;
  }

  Future<ScanResultData> extractFromPath(String path) async {
    if (!File(path).existsSync()) {
      throw StateError('تصویر پیدا نشد.');
    }

    final input = InputImage.fromFilePath(path);
    final textRecognizer = TextRecognizer(script: TextRecognitionScript.latin);
    final barcodeScanner = BarcodeScanner(formats: [
      BarcodeFormat.code128,
      BarcodeFormat.code39,
      BarcodeFormat.code93,
      BarcodeFormat.codabar,
      BarcodeFormat.ean13,
      BarcodeFormat.ean8,
      BarcodeFormat.itf,
      BarcodeFormat.pdf417,
      BarcodeFormat.qrCode,
      BarcodeFormat.upca,
      BarcodeFormat.upce,
    ]);

    try {
      final futures = await Future.wait<dynamic>([
        textRecognizer.processImage(input),
        barcodeScanner.processImage(input),
        _extractPersianText(path),
      ]);
      final recognized = futures[0] as RecognizedText;
      final barcodes = futures[1] as List<Barcode>;
      final persianText = futures[2] as String;
      final raw = _normalizeDigits('$persianText\n${recognized.text}');

      final barcode = barcodes
          .map((item) => _digitsOnly(item.rawValue ?? item.displayValue ?? ''))
          .where((value) => value.length >= 8)
          .fold<String>(
            '',
            (best, value) => value.length > best.length ? value : best,
          );

      final phone = _extractPhone(raw);
      final compact = raw.replaceAll(RegExp(r'[\s\-]'), '');
      final numberCandidates = RegExp(r'(?<!\d)\d{10,30}(?!\d)')
          .allMatches(compact)
          .map((match) => match.group(0) ?? '')
          .where((value) => value.length >= 10 && value != phone)
          .toList();
      final tracking = barcode.isNotEmpty
          ? barcode
          : numberCandidates.fold<String>(
              '',
              (best, value) => value.length > best.length ? value : best,
            );
      final amount = _extractAmount(raw);
      final paymentType = _detectPaymentType(raw, amount);
      final name = _extractRecipientName(raw);
      final warnings = <String>[];
      if (tracking.isEmpty) {
        warnings.add('شماره مرسوله یا بارکد تشخیص داده نشد.');
      }
      if (phone.isEmpty) warnings.add('شماره تلفن تشخیص داده نشد.');
      if (name.isEmpty) warnings.add('نام گیرنده تشخیص داده نشد.');
      if (paymentType != 'none' && amount == 0) {
        warnings.add('مرسوله هزینه‌دار است اما مبلغ واضح نیست.');
      }

      var confidence = 1.0;
      if (tracking.isEmpty) confidence -= 0.35;
      if (phone.isEmpty) confidence -= 0.25;
      if (name.isEmpty) confidence -= 0.2;
      if (warnings.isNotEmpty) confidence -= 0.05;

      return ScanResultData(
        imagePath: path,
        trackingNumber: tracking,
        barcode: barcode.isNotEmpty ? barcode : tracking,
        recipientName: name,
        phone: phone,
        amount: amount,
        paymentType: paymentType,
        rawText: raw,
        confidence: confidence.clamp(0.05, 1.0).toDouble(),
        warnings: warnings,
      );
    } finally {
      await textRecognizer.close();
      await barcodeScanner.close();
    }
  }

  Future<String> _extractPersianText(String imagePath) async {
    try {
      return await FlutterTesseractOcr.extractText(
        imagePath,
        language: 'fas',
        args: const {
          'psm': '6',
          'oem': '1',
          'preserve_interword_spaces': '1',
        },
      );
    } catch (_) {
      // مدل فارسی در زمان Build داخل assets/tessdata قرار می‌گیرد.
      // اگر فایل مدل در یک Build ناقص باشد، اسکن بارکد و اعداد همچنان فعال می‌ماند.
      return '';
    }
  }

  String _normalizeDigits(String value) {
    const fa = '۰۱۲۳۴۵۶۷۸۹';
    const ar = '٠١٢٣٤٥٦٧٨٩';
    var output = value;
    for (var i = 0; i < 10; i++) {
      output = output.replaceAll(fa[i], '$i').replaceAll(ar[i], '$i');
    }
    return output;
  }

  String _digitsOnly(String value) =>
      _normalizeDigits(value).replaceAll(RegExp(r'\D'), '');

  String _extractPhone(String text) {
    final compact = text.replaceAll(RegExp(r'[\s\-()]'), '');
    final matches = RegExp(r'(?<!\d)(?:\+98|0098|98|0)?9\d{9}(?!\d)')
        .allMatches(compact);
    for (final match in matches) {
      var value = match.group(0) ?? '';
      if (value.startsWith('+98')) value = '0${value.substring(3)}';
      if (value.startsWith('0098')) value = '0${value.substring(4)}';
      if (value.startsWith('98')) value = '0${value.substring(2)}';
      if (value.length == 10 && value.startsWith('9')) value = '0$value';
      if (value.length == 11) return value;
    }
    return '';
  }

  int _extractAmount(String text) {
    final priceWords = RegExp(
      r'(مبلغ|کرایه|پرداخت|پس کرایه|COD|ریال|تومان|هزینه)',
      caseSensitive: false,
    );
    final values = <int>[];
    for (final line in text.split('\n').where(priceWords.hasMatch)) {
      for (final match in RegExp(r'\d[\d,\.]{2,}').allMatches(line)) {
        final value = int.tryParse(
          (match.group(0) ?? '').replaceAll(RegExp(r'[,\.]'), ''),
        );
        if (value != null && value >= 1000 && value <= 9999999999) {
          values.add(value);
        }
      }
    }
    if (values.isEmpty) return 0;
    values.sort();
    return values.last;
  }

  String _detectPaymentType(String text, int amount) {
    final lower = text.toLowerCase();
    if (lower.contains('cod') ||
        lower.contains('پرداخت در محل') ||
        lower.contains('پس کرایه')) {
      return 'cod';
    }
    if (lower.contains('کرایه در مقصد') ||
        lower.contains('هزینه در مقصد')) {
      return 'destination';
    }
    return amount > 0 ? 'destination' : 'none';
  }

  String _extractRecipientName(String text) {
    final lines = text
        .split('\n')
        .map((line) => line.trim().replaceAll(RegExp(r'\s+'), ' '))
        .where((line) => line.isNotEmpty)
        .toList();
    final nameHint = RegExp(
      r'(نام\s*گیرنده|گیرنده|تحویل\s*گیرنده|مخاطب)',
      caseSensitive: false,
    );
    for (var i = 0; i < lines.length; i++) {
      if (!nameHint.hasMatch(lines[i])) continue;
      var candidate = lines[i]
          .replaceFirst(nameHint, '')
          .replaceAll(RegExp(r'[:：]'), '')
          .trim();
      if (!_looksLikeName(candidate) && i + 1 < lines.length) {
        candidate = lines[i + 1];
      }
      if (_looksLikeName(candidate)) return candidate;
    }
    for (final line in lines) {
      if (_looksLikeName(line)) return line;
    }
    return '';
  }

  bool _looksLikeName(String value) {
    if (value.length < 5 || value.length > 50) return false;
    if (RegExp(r'\d').hasMatch(value)) return false;
    if (!RegExp(r'[آ-ی]').hasMatch(value)) return false;
    final excluded = RegExp(
      r'(فرستنده|گیرنده|آدرس|استان|شهرستان|روستا|کدپستی|پست|مرسوله|تلفن|موبایل|ریال|تومان|بارکد)',
      caseSensitive: false,
    );
    if (excluded.hasMatch(value)) return false;
    final words = value.split(RegExp(r'\s+')).where((word) => word.length > 1).length;
    return words >= 2;
  }
}
