import 'package:url_launcher/url_launcher.dart';

class SmsService {
  static Future<bool> openComposer({
    required String phone,
    required String message,
  }) async {
    final normalized = phone.replaceAll(RegExp(r'\D'), '');
    final uri = Uri(
      scheme: 'sms',
      path: normalized,
      queryParameters: {'body': message},
    );
    return launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  static String arrivalMessage({
    required String recipient,
    required String tracking,
    required int amount,
    required String unitName,
  }) {
    final amountText = amount > 0 ? '\nمبلغ قابل پرداخت: $amount تومان' : '';
    return 'سلام $recipient، مرسوله شما با شماره $tracking به $unitName رسیده است. '
        'لطفاً برای تحویل مراجعه کنید.$amountText';
  }
}
