import 'dart:io';

import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/parcel.dart';

class ApiException implements Exception {
  ApiException(this.message);
  final String message;
  @override
  String toString() => message;
}

class ApiService {
  ApiService._();
  static final ApiService instance = ApiService._();

  final Dio _dio = Dio(
    BaseOptions(
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 20),
      sendTimeout: const Duration(seconds: 30),
      headers: {'Accept': 'application/json'},
    ),
  );

  Future<String> get baseUrl async {
    final prefs = await SharedPreferences.getInstance();
    var value = prefs.getString('api_base_url') ?? '';
    value = value.trim().replaceAll(RegExp(r'/+$'), '');
    return value;
  }

  Future<void> setBaseUrl(String value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'api_base_url',
      value.trim().replaceAll(RegExp(r'/+$'), ''),
    );
  }

  Future<String?> get token async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  Future<void> setToken(String? value) async {
    final prefs = await SharedPreferences.getInstance();
    if (value == null || value.isEmpty) {
      await prefs.remove('auth_token');
    } else {
      await prefs.setString('auth_token', value);
    }
  }

  Future<Options> _options({bool multipart = false}) async {
    final authToken = await token;
    return Options(headers: {
      if (authToken != null) 'Authorization': 'Bearer $authToken',
      if (!multipart) 'Content-Type': 'application/json',
    });
  }

  Future<dynamic> _request(
    String method,
    String path, {
    Object? data,
    Map<String, dynamic>? query,
  }) async {
    final url = await baseUrl;
    if (url.isEmpty) {
      throw ApiException('آدرس سرور تنظیم نشده است.');
    }
    try {
      final response = await _dio.request<dynamic>(
        '$url$path',
        data: data,
        queryParameters: query,
        options: (await _options()).copyWith(method: method),
      );
      final body = response.data;
      if (body is Map && body['ok'] == false) {
        throw ApiException(body['message']?.toString() ?? 'خطای سرور');
      }
      return body;
    } on DioException catch (error) {
      final body = error.response?.data;
      final message = body is Map
          ? body['message']?.toString()
          : error.message?.toString();
      throw ApiException(message ?? 'ارتباط با سرور برقرار نشد.');
    }
  }

  Future<Map<String, dynamic>> login(String username, String password) async {
    final body = await _request(
      'POST',
      '/auth/login',
      data: {'username': username, 'password': password},
    );
    return Map<String, dynamic>.from(body as Map);
  }

  Future<Map<String, dynamic>> me() async {
    final body = await _request('GET', '/auth/me');
    return Map<String, dynamic>.from(body as Map);
  }

  Future<List<Map<String, dynamic>>> fetchParcels({String? updatedAfter}) async {
    final body = await _request(
      'GET',
      '/parcels',
      query: {if (updatedAfter != null) 'updated_after': updatedAfter},
    );
    final items = (body as Map)['data'] as List? ?? const [];
    return items.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<Map<String, dynamic>> upsertParcel(Parcel parcel) async {
    final body = await _request(
      'POST',
      '/parcels/sync',
      data: parcel.toApiJson(),
    );
    return Map<String, dynamic>.from((body as Map)['data'] as Map);
  }

  Future<String?> uploadLabel(String localId, String filePath) async {
    if (!File(filePath).existsSync()) return null;
    final url = await baseUrl;
    if (url.isEmpty) return null;
    final form = FormData.fromMap({
      'client_id': localId,
      'image': await MultipartFile.fromFile(filePath),
    });
    try {
      final response = await _dio.post<dynamic>(
        '$url/parcels/upload-label',
        data: form,
        options: await _options(multipart: true),
      );
      final body = response.data;
      return body is Map ? body['path']?.toString() : null;
    } on DioException {
      return null;
    }
  }

  Future<bool> downloadLabel(String clientId, String destinationPath) async {
    final url = await baseUrl;
    if (url.isEmpty) return false;
    try {
      final response = await _dio.get<List<int>>(
        '$url/parcels/label',
        queryParameters: {'client_id': clientId},
        options: (await _options()).copyWith(responseType: ResponseType.bytes),
      );
      final bytes = response.data;
      if (bytes == null || bytes.isEmpty) return false;
      final file = File(destinationPath);
      await file.parent.create(recursive: true);
      await file.writeAsBytes(bytes, flush: true);
      return true;
    } on DioException {
      return false;
    }
  }

  Future<List<Map<String, dynamic>>> listUnits() async {
    final body = await _request('GET', '/units');
    final items = (body as Map)['data'] as List? ?? const [];
    return items.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<void> createUnit(Map<String, dynamic> data) async {
    await _request('POST', '/units', data: data);
  }

  Future<List<Map<String, dynamic>>> listUsers() async {
    final body = await _request('GET', '/users');
    final items = (body as Map)['data'] as List? ?? const [];
    return items.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<void> createUser(Map<String, dynamic> data) async {
    await _request('POST', '/users', data: data);
  }
}
