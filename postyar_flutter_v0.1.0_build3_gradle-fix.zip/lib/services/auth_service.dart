import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/app_user.dart';
import 'api_service.dart';

class AuthService {
  AuthService._();
  static final AuthService instance = AuthService._();

  Future<AppUser?> cachedUser() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('cached_user');
    if (raw == null || raw.isEmpty) return null;
    try {
      return AppUser.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return null;
    }
  }

  Future<AppUser> login(String username, String password) async {
    final response = await ApiService.instance.login(username, password);
    final token = response['token']?.toString() ?? '';
    if (token.isEmpty) throw ApiException('توکن ورود دریافت نشد.');
    final user = AppUser.fromJson(
      Map<String, dynamic>.from(response['user'] as Map),
    );
    await ApiService.instance.setToken(token);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('cached_user', jsonEncode(user.toJson()));
    return user;
  }

  Future<void> logout() async {
    await ApiService.instance.setToken(null);
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('cached_user');
  }
}
