import 'dart:io';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'api_service.dart';
import 'local_database.dart';

class SyncReport {
  const SyncReport({required this.uploaded, required this.downloaded});
  final int uploaded;
  final int downloaded;
}

class SyncService {
  SyncService._();
  static final SyncService instance = SyncService._();

  Future<SyncReport> sync() async {
    final connection = await Connectivity().checkConnectivity();
    if (connection.contains(ConnectivityResult.none)) {
      throw ApiException('اینترنت در دسترس نیست؛ اطلاعات روی گوشی محفوظ است.');
    }
    var uploaded = 0;
    final pending = await LocalDatabase.instance.pendingSync();
    for (final parcel in pending) {
      final saved = await ApiService.instance.upsertParcel(parcel);
      final serverId = (saved['id'] as num).toInt();
      if (parcel.labelImagePath != null &&
          File(parcel.labelImagePath!).existsSync()) {
        final remotePath = await ApiService.instance.uploadLabel(
          parcel.localId,
          parcel.labelImagePath!,
        );
        if (remotePath == null) {
          throw ApiException(
            'اطلاعات مرسوله ذخیره شد اما ارسال تصویر ناموفق بود؛ دوباره همگام‌سازی کنید.',
          );
        }
      }
      await LocalDatabase.instance.markSynced(parcel.localId, serverId);
      uploaded++;
    }

    final prefs = await SharedPreferences.getInstance();
    final lastSync = prefs.getString('last_sync_at');
    final remote = await ApiService.instance.fetchParcels(updatedAfter: lastSync);
    await _attachRemoteLabelFiles(remote);
    await LocalDatabase.instance.replaceFromServer(remote);
    await prefs.setString(
      'last_sync_at',
      DateTime.now().toUtc().toIso8601String(),
    );
    return SyncReport(uploaded: uploaded, downloaded: remote.length);
  }

  Future<void> _attachRemoteLabelFiles(
    List<Map<String, dynamic>> items,
  ) async {
    final root = await getApplicationDocumentsDirectory();
    final folder = Directory(p.join(root.path, 'parcel_labels'));
    await folder.create(recursive: true);
    for (final item in items) {
      final remotePath = item['label_image_path']?.toString() ?? '';
      final clientId = item['client_id']?.toString() ?? '';
      if (remotePath.isEmpty || clientId.isEmpty) continue;
      final extension =
          p.extension(remotePath).isEmpty ? '.jpg' : p.extension(remotePath);
      final updated = DateTime.tryParse(
                item['updated_at']?.toString() ?? '',
              )?.millisecondsSinceEpoch ??
          0;
      final safeId = clientId.replaceAll(
        RegExp(r'[^a-zA-Z0-9_-]'),
        '_',
      );
      final target = p.join(
        folder.path,
        'remote_${safeId}_$updated$extension',
      );
      final file = File(target);
      if (!file.existsSync() || await file.length() == 0) {
        final downloaded = await ApiService.instance.downloadLabel(
          clientId,
          target,
        );
        if (!downloaded) continue;
      }
      item['local_label_image_path'] = target;
    }
  }
}
