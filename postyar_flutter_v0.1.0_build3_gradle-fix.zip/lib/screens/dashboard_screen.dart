import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/app_state.dart';
import '../widgets/parcel_tile.dart';
import '../widgets/stat_card.dart';
import 'parcel_detail_screen.dart';
import 'parcel_form_screen.dart';
import 'parcel_list_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  Future<void> _sync(BuildContext context) async {
    try {
      final report = await context.read<AppState>().synchronize();
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${report.uploaded} مورد ارسال و ${report.downloaded} مورد دریافت شد.')),
      );
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final counts = state.counts;
    final recent = state.parcels.take(5).toList();
    return RefreshIndicator(
      onRefresh: () => state.refreshLocal(),
      child: CustomScrollView(
        slivers: [
          SliverAppBar(
            pinned: true,
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('داشبورد'),
                Text(state.user?.unitName ?? '', style: Theme.of(context).textTheme.labelMedium),
              ],
            ),
            actions: [
              IconButton(
                tooltip: 'همگام‌سازی',
                onPressed: state.busy ? null : () => _sync(context),
                icon: state.busy
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.sync),
              ),
            ],
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 100),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                Card(
                  color: Theme.of(context).colorScheme.primary,
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('ثبت سریع مرسوله', style: Theme.of(context).textTheme.titleLarge?.copyWith(color: Theme.of(context).colorScheme.onPrimary, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 6),
                        Text('از برچسب عکس بگیر؛ بارکد، نام، موبایل و مبلغ خودکار استخراج می‌شود.', style: TextStyle(color: Theme.of(context).colorScheme.onPrimary.withValues(alpha: .86))),
                        const SizedBox(height: 16),
                        FilledButton.icon(
                          style: FilledButton.styleFrom(backgroundColor: Theme.of(context).colorScheme.onPrimary, foregroundColor: Theme.of(context).colorScheme.primary),
                          onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ParcelFormScreen(startWithCamera: true))),
                          icon: const Icon(Icons.document_scanner_outlined),
                          label: const Text('عکس بگیر و ثبت کن'),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                GridView.count(
                  crossAxisCount: MediaQuery.sizeOf(context).width > 650 ? 3 : 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  childAspectRatio: 1.75,
                  children: [
                    StatCard(title: 'در انتظار تحویل', value: counts['waiting'] ?? 0, icon: Icons.inventory_2_outlined, onTap: () => _openList(context, 'waiting')),
                    StatCard(title: 'تحویل‌شده', value: counts['delivered'] ?? 0, icon: Icons.task_alt, onTap: () => _openList(context, 'delivered')),
                    StatCard(title: 'هزینه‌دار', value: counts['payment'] ?? 0, icon: Icons.payments_outlined, onTap: () => _openList(context, 'payment')),
                    StatCard(title: 'نیازمند بررسی', value: counts['review'] ?? 0, icon: Icons.error_outline, onTap: () => _openList(context, 'review')),
                    StatCard(title: 'ثبت کل', value: counts['all'] ?? 0, icon: Icons.all_inbox_outlined, onTap: () => _openList(context, null)),
                    StatCard(title: 'در انتظار همگام‌سازی', value: counts['pending_sync'] ?? 0, icon: Icons.cloud_upload_outlined, onTap: () => _openList(context, 'pending_sync')),
                  ],
                ),
                const SizedBox(height: 22),
                Row(
                  children: [
                    Text('آخرین مرسوله‌ها', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
                    const Spacer(),
                    TextButton(onPressed: () => _openList(context, null), child: const Text('مشاهده همه')),
                  ],
                ),
                const SizedBox(height: 10),
                if (recent.isEmpty)
                  const Card(child: Padding(padding: EdgeInsets.all(28), child: Center(child: Text('هنوز مرسوله‌ای ثبت نشده است.'))))
                else
                  ...recent.map((parcel) => Padding(
                        padding: const EdgeInsets.only(bottom: 9),
                        child: ParcelTile(
                          parcel: parcel,
                          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ParcelDetailScreen(parcelId: parcel.localId))),
                        ),
                      )),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  void _openList(BuildContext context, String? status) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => ParcelListScreen(initialStatus: status)));
  }
}
