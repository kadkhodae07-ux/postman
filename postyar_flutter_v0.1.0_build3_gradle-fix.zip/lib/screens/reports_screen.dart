import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../core/constants.dart';
import '../state/app_state.dart';

class ReportsScreen extends StatelessWidget {
  const ReportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final parcels = context.watch<AppState>().parcels;
    final today = DateTime.now();
    bool isToday(DateTime value) =>
        value.year == today.year && value.month == today.month && value.day == today.day;
    final todays = parcels.where((p) => isToday(p.receivedAt)).toList();
    final deliveredToday = parcels.where((p) => p.deliveredAt != null && isToday(p.deliveredAt!)).toList();
    final delivered = deliveredToday.length;
    final waiting = parcels.where((p) => !p.isDelivered && p.status != 'returned').length;
    final amount = deliveredToday.fold<int>(0, (sum, p) => sum + p.amount);
    final byType = <String, int>{};
    for (final parcel in todays) {
      byType[parcel.parcelType] = (byType[parcel.parcelType] ?? 0) + 1;
    }

    return Scaffold(
      appBar: AppBar(title: const Text('گزارش روزانه')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
        children: [
          Text(DateFormat('yyyy/MM/dd').format(today), style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 12),
          _ReportCard(title: 'مرسوله‌های ورودی امروز', value: '${todays.length}', icon: Icons.move_to_inbox_outlined),
          const SizedBox(height: 10),
          _ReportCard(title: 'تحویل‌شده امروز', value: '$delivered', icon: Icons.task_alt),
          const SizedBox(height: 10),
          _ReportCard(title: 'کل مرسوله‌های در انتظار تحویل', value: '$waiting', icon: Icons.pending_actions_outlined),
          const SizedBox(height: 10),
          _ReportCard(title: 'مبلغ ثبت‌شده تحویل‌ها', value: '${NumberFormat.decimalPattern('fa').format(amount)} تومان', icon: Icons.payments_outlined),
          const SizedBox(height: 22),
          Text('تفکیک نوع مرسوله', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          Card(
            color: Colors.white,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: byType.isEmpty
                  ? const Text('امروز مرسوله‌ای ثبت نشده است.')
                  : Column(
                      children: byType.entries.map((entry) => Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8),
                            child: Row(children: [Expanded(child: Text(AppConstants.parcelTypes[entry.key] ?? entry.key)), Text('${entry.value}', style: const TextStyle(fontWeight: FontWeight.w900))]),
                          )).toList(),
                    ),
            ),
          ),
          const SizedBox(height: 14),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('بایگانی و مدرک', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900)),
                  const SizedBox(height: 8),
                  const Text('تمام ثبت‌ها، تصویر برچسب، کاربر ثبت‌کننده، زمان اطلاع‌رسانی و اطلاعات تحویل در پایگاه داده نگهداری می‌شوند.'),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ReportCard extends StatelessWidget {
  const _ReportCard({required this.title, required this.value, required this.icon});
  final String title;
  final String value;
  final IconData icon;
  @override
  Widget build(BuildContext context) => Card(
        color: Colors.white,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [CircleAvatar(child: Icon(icon)), const SizedBox(width: 12), Expanded(child: Text(title)), Text(value, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900))]),
        ),
      );
}
