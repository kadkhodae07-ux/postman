import 'dart:io';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart' hide TextDirection;
import 'package:provider/provider.dart';

import '../core/constants.dart';
import '../models/parcel.dart';
import '../services/local_database.dart';
import '../services/sms_service.dart';
import '../state/app_state.dart';
import 'parcel_form_screen.dart';

class ParcelDetailScreen extends StatefulWidget {
  const ParcelDetailScreen({super.key, required this.parcelId});
  final String parcelId;

  @override
  State<ParcelDetailScreen> createState() => _ParcelDetailScreenState();
}

class _ParcelDetailScreenState extends State<ParcelDetailScreen> {
  Parcel? _parcel;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    _parcel = await LocalDatabase.instance.getParcel(widget.parcelId);
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _notify(Parcel parcel) async {
    if (parcel.phone.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('شماره موبایل گیرنده ثبت نشده است.')));
      return;
    }
    final template = await context.read<AppState>().smsTemplate();
    final amountText = parcel.amount > 0 ? '\nمبلغ قابل پرداخت: ${NumberFormat.decimalPattern('fa').format(parcel.amount)} تومان' : '';
    final message = template
        .replaceAll('{name}', parcel.recipientName)
        .replaceAll('{tracking}', parcel.trackingNumber)
        .replaceAll('{unit}', parcel.unitName)
        .replaceAll('{amount}', amountText);
    final opened = await SmsService.openComposer(phone: parcel.phone, message: message);
    if (!mounted) return;
    if (opened) {
      await context.read<AppState>().markNotified(parcel);
      await _load();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('برنامه پیامک روی گوشی باز نشد.')));
    }
  }

  Future<void> _deliver(Parcel parcel) async {
    final name = TextEditingController(text: parcel.recipientName);
    final phone = TextEditingController(text: parcel.phone);
    final form = GlobalKey<FormState>();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('ثبت تحویل مرسوله'),
        content: Form(
          key: form,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: name,
                decoration: const InputDecoration(labelText: 'نام تحویل‌گیرنده'),
                validator: (value) => value == null || value.trim().length < 3 ? 'نام را وارد کنید.' : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: phone,
                textDirection: TextDirection.ltr,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'شماره تحویل‌گیرنده'),
                validator: (value) => value == null || value.replaceAll(RegExp(r'\D'), '').length < 10 ? 'شماره معتبر وارد کنید.' : null,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
          FilledButton(
            onPressed: () {
              if (form.currentState!.validate()) Navigator.pop(context, true);
            },
            child: const Text('تأیید تحویل'),
          ),
        ],
      ),
    );
    if (confirmed == true && mounted) {
      await context.read<AppState>().deliverParcel(parcel: parcel, receiverName: name.text, receiverPhone: phone.text);
      await _load();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تحویل با تاریخ و نام تحویل‌گیرنده ثبت شد.')));
    }
    name.dispose();
    phone.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final parcel = _parcel;
    if (parcel == null) return const Scaffold(body: Center(child: Text('مرسوله پیدا نشد.')));
    final image = parcel.labelImagePath == null ? null : File(parcel.labelImagePath!);
    final amount = NumberFormat.decimalPattern('fa').format(parcel.amount);
    final awaitingUnitAcceptance = parcel.status == 'transferred';
    return Scaffold(
      appBar: AppBar(
        title: const Text('جزئیات مرسوله'),
        actions: [
          IconButton(
            tooltip: 'ویرایش',
            onPressed: parcel.isDelivered
                ? null
                : () async {
                    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => ParcelFormScreen(existing: parcel)));
                    await _load();
                  },
            icon: const Icon(Icons.edit_outlined),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
        children: [
          if (image != null && image.existsSync())
            Card(clipBehavior: Clip.antiAlias, child: Image.file(image, height: 220, width: double.infinity, fit: BoxFit.cover)),
          if (parcel.status == 'transferred' && context.read<AppState>().user?.unitId == parcel.unitId) ...[
            FilledButton.icon(
              onPressed: () async {
                try {
                  await context.read<AppState>().acceptAtUnit(parcel);
                  await _load();
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('دریافت فیزیکی مرسوله در واحد ثبت شد.')),
                  );
                } catch (e) {
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
                }
              },
              icon: const Icon(Icons.inventory_2_outlined),
              label: const Text('تأیید دریافت مرسوله در واحد'),
            ),
            const SizedBox(height: 12),
          ],
          Card(
            color: Colors.white,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  _DetailRow('وضعیت', AppConstants.statusLabels[parcel.status] ?? parcel.status),
                  _DetailRow('شماره مرسوله', parcel.trackingNumber, ltr: true),
                  _DetailRow('بارکد', parcel.barcode, ltr: true),
                  _DetailRow('گیرنده', parcel.recipientName),
                  _DetailRow('موبایل', parcel.phone, ltr: true),
                  _DetailRow('نوع', AppConstants.parcelTypes[parcel.parcelType] ?? parcel.parcelType),
                  if (parcel.bankName.isNotEmpty) _DetailRow('بانک', parcel.bankName),
                  _DetailRow('اندازه', parcel.sizeCode >= 4 ? 'بزرگ / سایز ۴ به بالا' : parcel.sizeCode == 3 ? 'متوسط / سایز ۳' : 'کوچک / سایز ۱'),
                  _DetailRow('هزینه', parcel.amount > 0 ? '$amount تومان' : 'بدون هزینه'),
                  _DetailRow('واحد مقصد', parcel.unitName),
                  _DetailRow('محل نگهداری', parcel.storageLocation),
                  _DetailRow('ثبت‌کننده', parcel.createdByName),
                  _DetailRow('زمان ورود', DateFormat('yyyy/MM/dd - HH:mm').format(parcel.receivedAt)),
                  if (parcel.notifiedAt != null) _DetailRow('زمان اطلاع‌رسانی', DateFormat('yyyy/MM/dd - HH:mm').format(parcel.notifiedAt!)),
                  if (parcel.deliveredAt != null) _DetailRow('زمان تحویل', DateFormat('yyyy/MM/dd - HH:mm').format(parcel.deliveredAt!)),
                  if (parcel.deliveredToName != null) _DetailRow('تحویل‌گیرنده', parcel.deliveredToName!),
                  if (parcel.notes.isNotEmpty) _DetailRow('توضیحات', parcel.notes),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: Row(
            children: [
              Expanded(child: OutlinedButton.icon(onPressed: parcel.isDelivered || awaitingUnitAcceptance ? null : () => _notify(parcel), icon: const Icon(Icons.sms_outlined), label: const Text('اطلاع‌رسانی'))),
              const SizedBox(width: 10),
              Expanded(child: FilledButton.icon(onPressed: parcel.isDelivered || awaitingUnitAcceptance ? null : () => _deliver(parcel), icon: const Icon(Icons.how_to_reg_outlined), label: Text(parcel.isDelivered ? 'تحویل شده' : awaitingUnitAcceptance ? 'در انتظار تأیید واحد' : 'ثبت تحویل'))),
            ],
          ),
        ),
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  const _DetailRow(this.label, this.value, {this.ltr = false});
  final String label;
  final String value;
  final bool ltr;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 7),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(width: 112, child: Text(label, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant))),
            Expanded(child: Text(value.isEmpty ? '—' : value, textDirection: ltr ? TextDirection.ltr : TextDirection.rtl, style: const TextStyle(fontWeight: FontWeight.w700))),
          ],
        ),
      );
}
