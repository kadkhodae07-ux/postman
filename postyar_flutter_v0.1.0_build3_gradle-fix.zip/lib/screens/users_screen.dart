import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/app_state.dart';

class UsersScreen extends StatelessWidget {
  const UsersScreen({super.key});

  Future<void> _createUnit(BuildContext context) async {
    final state = context.read<AppState>();
    final form = GlobalKey<FormState>();
    final name = TextEditingController();
    final code = TextEditingController();
    String type = 'village';
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('افزودن روستا یا واحد'),
          content: Form(
            key: form,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: name,
                  decoration: const InputDecoration(labelText: 'نام روستا یا واحد'),
                  validator: (value) => value == null || value.trim().length < 2 ? 'نام را وارد کنید.' : null,
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: code,
                  textDirection: TextDirection.ltr,
                  decoration: const InputDecoration(labelText: 'کد یکتا، مثل VIL-02'),
                  validator: (value) => value == null || value.trim().length < 2 ? 'کد واحد را وارد کنید.' : null,
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  initialValue: type,
                  decoration: const InputDecoration(labelText: 'نوع واحد'),
                  items: const [
                    DropdownMenuItem(value: 'village', child: Text('روستا')),
                    DropdownMenuItem(value: 'branch', child: Text('واحد یا نمایندگی')),
                    DropdownMenuItem(value: 'city', child: Text('مرکز شهر')),
                  ],
                  onChanged: (value) => setDialogState(() => type = value ?? 'village'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
            FilledButton(
              onPressed: () {
                if (form.currentState!.validate()) Navigator.pop(context, true);
              },
              child: const Text('ساخت واحد'),
            ),
          ],
        ),
      ),
    );
    if (confirmed == true && context.mounted) {
      try {
        await state.createUnit({'name': name.text.trim(), 'code': code.text.trim(), 'unit_type': type});
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('روستا یا واحد ساخته شد.')));
        }
      } catch (e) {
        if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
      }
    }
    name.dispose();
    code.dispose();
  }

  Future<void> _createUser(BuildContext context) async {
    final state = context.read<AppState>();
    final form = GlobalKey<FormState>();
    final fullName = TextEditingController();
    final username = TextEditingController();
    final password = TextEditingController();
    final phone = TextEditingController();
    int? unitId = state.units.isEmpty ? null : (state.units.first['id'] as num).toInt();
    String role = 'unit_user';

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('افزودن همکار'),
          content: SizedBox(
            width: 480,
            child: SingleChildScrollView(
              child: Form(
                key: form,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextFormField(controller: fullName, decoration: const InputDecoration(labelText: 'نام و نام خانوادگی'), validator: (v) => v == null || v.trim().length < 3 ? 'نام را وارد کنید.' : null),
                    const SizedBox(height: 10),
                    TextFormField(controller: phone, textDirection: TextDirection.ltr, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'شماره موبایل')),
                    const SizedBox(height: 10),
                    TextFormField(controller: username, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'نام کاربری'), validator: (v) => v == null || v.trim().length < 3 ? 'حداقل ۳ نویسه' : null),
                    const SizedBox(height: 10),
                    TextFormField(controller: password, obscureText: true, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'رمز عبور اولیه'), validator: (v) => v == null || v.length < 8 ? 'حداقل ۸ نویسه' : null),
                    const SizedBox(height: 10),
                    DropdownButtonFormField<int>(
                      initialValue: unitId,
                      decoration: const InputDecoration(labelText: 'روستا یا واحد'),
                      items: state.units.map((u) => DropdownMenuItem(value: (u['id'] as num).toInt(), child: Text(u['name']?.toString() ?? ''))).toList(),
                      onChanged: (v) => setDialogState(() => unitId = v),
                      validator: (v) => v == null ? 'واحد را انتخاب کنید.' : null,
                    ),
                    const SizedBox(height: 10),
                    DropdownButtonFormField<String>(
                      initialValue: role,
                      decoration: const InputDecoration(labelText: 'سطح دسترسی'),
                      items: const [
                        DropdownMenuItem(value: 'unit_user', child: Text('مسئول روستا / همکار')),
                        DropdownMenuItem(value: 'city_admin', child: Text('مدیر شهر')),
                      ],
                      onChanged: (v) => setDialogState(() => role = v ?? 'unit_user'),
                    ),
                  ],
                ),
              ),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
            FilledButton(onPressed: () {
              if (form.currentState!.validate()) Navigator.pop(context, true);
            }, child: const Text('ساخت حساب')),
          ],
        ),
      ),
    );

    if (confirmed == true && context.mounted) {
      try {
        await state.createUser({
          'full_name': fullName.text.trim(),
          'phone': phone.text.trim(),
          'username': username.text.trim(),
          'password': password.text,
          'unit_id': unitId,
          'role': role,
        });
        if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('حساب همکار ساخته شد.')));
      } catch (e) {
        if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
      }
    }
    fullName.dispose();
    phone.dispose();
    username.dispose();
    password.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('همکاران و روستاها'),
        actions: [
          IconButton(tooltip: 'افزودن روستا یا واحد', onPressed: () => _createUnit(context), icon: const Icon(Icons.add_location_alt_outlined)),
          IconButton(onPressed: state.busy ? null : () => state.loadRemoteMetadata(), icon: const Icon(Icons.refresh)),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(onPressed: () => _createUser(context), icon: const Icon(Icons.person_add_alt_1), label: const Text('افزودن همکار')),
      body: state.users.isEmpty
          ? const Center(child: Text('همکاری ثبت نشده یا ارتباط با سرور برقرار نیست.'))
          : ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
              itemCount: state.users.length,
              separatorBuilder: (_, __) => const SizedBox(height: 9),
              itemBuilder: (context, index) {
                final user = state.users[index];
                final active = user['is_active'] == true || user['is_active'] == 1;
                return Card(
                  color: Colors.white,
                  child: ListTile(
                    leading: CircleAvatar(child: Text((user['full_name']?.toString() ?? '').isEmpty ? '?' : (user['full_name']?.toString() ?? '').substring(0, 1))),
                    title: Text(user['full_name']?.toString() ?? '', style: const TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: Text('${user['unit_name'] ?? ''} • ${user['username'] ?? ''}'),
                    trailing: Chip(label: Text(active ? 'فعال' : 'غیرفعال')),
                  ),
                );
              },
            ),
    );
  }
}
