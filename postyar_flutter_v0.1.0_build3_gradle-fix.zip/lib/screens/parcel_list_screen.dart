import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/constants.dart';
import '../models/parcel.dart';
import '../state/app_state.dart';
import '../widgets/parcel_tile.dart';
import 'parcel_detail_screen.dart';

class ParcelListScreen extends StatefulWidget {
  const ParcelListScreen({super.key, this.initialStatus, this.embedded = false});
  final String? initialStatus;
  final bool embedded;

  @override
  State<ParcelListScreen> createState() => _ParcelListScreenState();
}

class _ParcelListScreenState extends State<ParcelListScreen> {
  final _search = TextEditingController();
  String? _status;

  @override
  void initState() {
    super.initState();
    _status = widget.initialStatus;
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  List<Parcel> _filtered(List<Parcel> all) {
    final query = _search.text.trim().toLowerCase();
    return all.where((parcel) {
      final statusOk = switch (_status) {
        null => true,
        'waiting' => !parcel.isDelivered && parcel.status != 'returned',
        'payment' => parcel.hasPayment,
        'pending_sync' => parcel.syncStatus != 'synced',
        'review' => parcel.needsReview || parcel.status == 'review',
        final value => parcel.status == value,
      };
      final queryOk = query.isEmpty ||
          parcel.trackingNumber.toLowerCase().contains(query) ||
          parcel.barcode.toLowerCase().contains(query) ||
          parcel.recipientName.toLowerCase().contains(query) ||
          parcel.phone.contains(query) ||
          parcel.storageLocation.toLowerCase().contains(query);
      return statusOk && queryOk;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final parcels = _filtered(context.watch<AppState>().parcels);
    final body = Column(
      children: [
        if (widget.embedded)
          AppBar(title: const Text('مرسوله‌ها')),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
          child: Column(
            children: [
              TextField(
                controller: _search,
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'نام، موبایل، بارکد یا محل نگهداری'),
              ),
              const SizedBox(height: 10),
              SizedBox(
                height: 42,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    ChoiceChip(label: const Text('همه'), selected: _status == null, onSelected: (_) => setState(() => _status = null)),
                    const SizedBox(width: 8),
                    ChoiceChip(label: const Text('در انتظار'), selected: _status == 'waiting', onSelected: (_) => setState(() => _status = 'waiting')),
                    const SizedBox(width: 8),
                    ChoiceChip(label: const Text('هزینه‌دار'), selected: _status == 'payment', onSelected: (_) => setState(() => _status = 'payment')),
                    const SizedBox(width: 8),
                    ChoiceChip(label: const Text('همگام‌نشده'), selected: _status == 'pending_sync', onSelected: (_) => setState(() => _status = 'pending_sync')),
                    const SizedBox(width: 8),
                    ...AppConstants.statusLabels.entries.map((entry) => Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: ChoiceChip(label: Text(entry.value), selected: _status == entry.key, onSelected: (_) => setState(() => _status = entry.key)),
                        )),
                  ],
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: parcels.isEmpty
              ? const Center(child: Text('موردی با این فیلتر پیدا نشد.'))
              : RefreshIndicator(
                  onRefresh: () => context.read<AppState>().refreshLocal(),
                  child: ListView.separated(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 110),
                    itemCount: parcels.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 9),
                    itemBuilder: (context, index) {
                      final parcel = parcels[index];
                      return ParcelTile(
                        parcel: parcel,
                        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ParcelDetailScreen(parcelId: parcel.localId))),
                      );
                    },
                  ),
                ),
        ),
      ],
    );
    if (widget.embedded) return body;
    return Scaffold(appBar: AppBar(title: const Text('فهرست مرسوله‌ها')), body: body);
  }
}
