import 'dart:io';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart' hide TextDirection;
import 'package:provider/provider.dart';

import '../core/constants.dart';
import '../models/parcel.dart';
import '../services/ocr_service.dart';
import '../state/app_state.dart';

class ParcelFormScreen extends StatefulWidget {
  const ParcelFormScreen({
    super.key,
    this.existing,
    this.startWithCamera = false,
  });

  final Parcel? existing;
  final bool startWithCamera;

  @override
  State<ParcelFormScreen> createState() => _ParcelFormScreenState();
}

class _ParcelFormScreenState extends State<ParcelFormScreen> {
  final _form = GlobalKey<FormState>();
  final _tracking = TextEditingController();
  final _barcode = TextEditingController();
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _amount = TextEditingController();
  final _storage = TextEditingController();
  final _notes = TextEditingController();

  String _parcelType = 'package';
  String _bankName = '';
  int _sizeCode = 1;
  String _paymentType = 'none';
  int? _unitId;
  String _unitName = '';
  String? _imagePath;
  double _ocrConfidence = 0;
  List<String> _warnings = const [];
  bool _scanning = false;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final parcel = widget.existing;
    if (parcel != null) {
      _tracking.text = parcel.trackingNumber;
      _barcode.text = parcel.barcode;
      _name.text = parcel.recipientName;
      _phone.text = parcel.phone;
      _amount.text = parcel.amount == 0 ? '' : parcel.amount.toString();
      _storage.text = parcel.storageLocation;
      _notes.text = parcel.notes;
      _parcelType = parcel.parcelType;
      _bankName = parcel.bankName;
      _sizeCode = parcel.sizeCode;
      _paymentType = parcel.paymentType;
      _unitId = parcel.unitId;
      _unitName = parcel.unitName;
      _imagePath = parcel.labelImagePath;
      _ocrConfidence = parcel.ocrConfidence;
    }
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _prepareDefaultUnit();
      if (widget.startWithCamera && parcel == null) _scan(camera: true);
    });
  }

  void _prepareDefaultUnit() {
    final state = context.read<AppState>();
    if (_unitId != null) return;
    final user = state.user;
    if (user == null) return;
    if (!user.isCityAdmin || state.units.isEmpty) {
      setState(() {
        _unitId = user.unitId;
        _unitName = user.unitName;
      });
    } else {
      final first = state.units.first;
      setState(() {
        _unitId = (first['id'] as num).toInt();
        _unitName = first['name']?.toString() ?? '';
      });
    }
  }

  @override
  void dispose() {
    _tracking.dispose();
    _barcode.dispose();
    _name.dispose();
    _phone.dispose();
    _amount.dispose();
    _storage.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _scan({required bool camera}) async {
    setState(() => _scanning = true);
    try {
      final result = camera
          ? await OcrService.instance.captureAndExtract()
          : await OcrService.instance.pickAndExtract();
      if (result == null || !mounted) return;
      setState(() {
        _tracking.text = result.trackingNumber;
        _barcode.text = result.barcode;
        _name.text = result.recipientName;
        _phone.text = result.phone;
        _amount.text = result.amount == 0 ? '' : result.amount.toString();
        _paymentType = result.paymentType;
        _imagePath = result.imagePath;
        _ocrConfidence = result.confidence;
        _warnings = result.warnings;
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('خواندن تصویر ناموفق بود: $e')));
    } finally {
      if (mounted) setState(() => _scanning = false);
    }
  }

  String _normalizePhone(String value) {
    const fa = '۰۱۲۳۴۵۶۷۸۹';
    var output = value;
    for (var i = 0; i < 10; i++) {
      output = output.replaceAll(fa[i], '$i');
    }
    return output.replaceAll(RegExp(r'\D'), '');
  }

  Future<bool> _save({required bool scanNext}) async {
    if (!_form.currentState!.validate()) return false;
    if (_unitId == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('واحد یا روستای مقصد را انتخاب کنید.')));
      return false;
    }
    setState(() => _saving = true);
    try {
      await context.read<AppState>().saveParcel(
            existing: widget.existing,
            trackingNumber: _tracking.text,
            barcode: _barcode.text,
            recipientName: _name.text,
            phone: _normalizePhone(_phone.text),
            parcelType: _parcelType,
            bankName: _parcelType == 'bank_card' ? _bankName : '',
            sizeCode: _sizeCode,
            paymentType: _paymentType,
            amount: int.tryParse(_amount.text.replaceAll(RegExp(r'\D'), '')) ?? 0,
            unitId: _unitId!,
            unitName: _unitName,
            storageLocation: _storage.text,
            notes: _notes.text,
            imagePath: _imagePath,
            ocrConfidence: _ocrConfidence,
          );
      if (!mounted) return false;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('مرسوله ثبت شد.')));
      if (scanNext) {
        _resetForNext();
        await _scan(camera: true);
      } else {
        Navigator.of(context).pop(true);
      }
      return true;
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
      return false;
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  void _resetForNext() {
    _tracking.clear();
    _barcode.clear();
    _name.clear();
    _phone.clear();
    _amount.clear();
    _storage.clear();
    _notes.clear();
    setState(() {
      _parcelType = 'package';
      _bankName = '';
      _sizeCode = 1;
      _paymentType = 'none';
      _imagePath = null;
      _ocrConfidence = 0;
      _warnings = const [];
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: Text(widget.existing == null ? 'ثبت مرسوله' : 'ویرایش مرسوله')),
      body: SafeArea(
        child: Form(
          key: _form,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 130),
            children: [
              _CameraPanel(
                imagePath: _imagePath,
                scanning: _scanning,
                confidence: _ocrConfidence,
                onCamera: () => _scan(camera: true),
                onGallery: () => _scan(camera: false),
              ),
              if (_warnings.isNotEmpty) ...[
                const SizedBox(height: 12),
                Card(
                  color: Theme.of(context).colorScheme.errorContainer,
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('موارد نیازمند بررسی', style: TextStyle(fontWeight: FontWeight.w900, color: Theme.of(context).colorScheme.onErrorContainer)),
                        const SizedBox(height: 6),
                        ..._warnings.map((warning) => Text('• $warning')),
                      ],
                    ),
                  ),
                ),
              ],
              const SizedBox(height: 18),
              const _SectionTitle('اطلاعات استخراج‌شده'),
              const SizedBox(height: 10),
              TextFormField(
                controller: _tracking,
                textDirection: TextDirection.ltr,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'شماره مرسوله', prefixIcon: Icon(Icons.numbers)),
                validator: (value) => value == null || value.trim().length < 8 ? 'شماره مرسوله را بررسی کنید.' : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: _barcode,
                textDirection: TextDirection.ltr,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'بارکد', prefixIcon: Icon(Icons.qr_code_2)),
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: _name,
                decoration: const InputDecoration(labelText: 'نام و نام خانوادگی گیرنده', prefixIcon: Icon(Icons.person_outline)),
                validator: (value) => value == null || value.trim().length < 3 ? 'نام گیرنده را وارد یا اصلاح کنید.' : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: _phone,
                textDirection: TextDirection.ltr,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'شماره موبایل', prefixIcon: Icon(Icons.phone_android)),
                validator: (value) {
                  final phone = _normalizePhone(value ?? '');
                  return phone.length == 11 && phone.startsWith('09') ? null : 'شماره موبایل ۱۱ رقمی معتبر وارد کنید.';
                },
              ),
              const SizedBox(height: 18),
              const _SectionTitle('نوع و اندازه'),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: AppConstants.parcelTypes.entries.map((entry) {
                  return ChoiceChip(
                    label: Text(entry.value),
                    selected: _parcelType == entry.key,
                    onSelected: (_) => setState(() {
                      _parcelType = entry.key;
                      if (_parcelType != 'bank_card') _bankName = '';
                    }),
                  );
                }).toList(),
              ),
              if (_parcelType == 'bank_card') ...[
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  initialValue: AppConstants.bankNames.contains(_bankName) ? _bankName : null,
                  decoration: const InputDecoration(
                    labelText: 'نام بانک کارت',
                    prefixIcon: Icon(Icons.account_balance_outlined),
                  ),
                  items: AppConstants.bankNames
                      .map((bank) => DropdownMenuItem(value: bank, child: Text(bank)))
                      .toList(),
                  onChanged: (value) => setState(() => _bankName = value ?? ''),
                  validator: (value) => _parcelType == 'bank_card' && (value == null || value.isEmpty)
                      ? 'نام بانک را انتخاب کنید.'
                      : null,
                ),
              ],
              const SizedBox(height: 10),
              SegmentedButton<int>(
                segments: const [
                  ButtonSegment(value: 1, label: Text('کوچک / سایز ۱')),
                  ButtonSegment(value: 3, label: Text('متوسط / سایز ۳')),
                  ButtonSegment(value: 4, label: Text('بزرگ / ۴+')),
                ],
                selected: {_sizeCode},
                onSelectionChanged: (value) => setState(() => _sizeCode = value.first),
              ),
              const SizedBox(height: 18),
              const _SectionTitle('هزینه'),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                initialValue: _paymentType,
                decoration: const InputDecoration(labelText: 'وضعیت هزینه', prefixIcon: Icon(Icons.payments_outlined)),
                items: AppConstants.paymentTypes.entries.map((entry) => DropdownMenuItem(value: entry.key, child: Text(entry.value))).toList(),
                onChanged: (value) => setState(() => _paymentType = value ?? 'none'),
              ),
              if (_paymentType != 'none') ...[
                const SizedBox(height: 10),
                TextFormField(
                  controller: _amount,
                  textDirection: TextDirection.ltr,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: 'مبلغ قابل دریافت (تومان)',
                    prefixIcon: const Icon(Icons.price_change_outlined),
                    helperText: _amount.text.isEmpty ? null : NumberFormat.decimalPattern('fa').format(int.tryParse(_amount.text) ?? 0),
                  ),
                  validator: (value) => _paymentType != 'none' && (int.tryParse((value ?? '').replaceAll(RegExp(r'\D'), '')) ?? 0) <= 0 ? 'مبلغ را وارد کنید.' : null,
                  onChanged: (_) => setState(() {}),
                ),
              ],
              const SizedBox(height: 18),
              const _SectionTitle('واحد و محل نگهداری'),
              const SizedBox(height: 10),
              DropdownButtonFormField<int>(
                initialValue: state.units.any((u) => (u['id'] as num).toInt() == _unitId) ? _unitId : null,
                decoration: const InputDecoration(labelText: 'شهر، روستا یا واحد مقصد', prefixIcon: Icon(Icons.location_city_outlined)),
                items: state.units.map((unit) {
                  final id = (unit['id'] as num).toInt();
                  final name = unit['name']?.toString() ?? '';
                  return DropdownMenuItem<int>(value: id, child: Text(name));
                }).toList(),
                onChanged: state.user?.isCityAdmin == true
                    ? (value) {
                        final unit = state.units.firstWhere((u) => (u['id'] as num).toInt() == value);
                        setState(() {
                          _unitId = value;
                          _unitName = unit['name']?.toString() ?? '';
                        });
                      }
                    : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: _storage,
                decoration: const InputDecoration(labelText: 'محل نگهداری', hintText: 'مثلاً قفسه ۲، سبد بسته‌های بزرگ', prefixIcon: Icon(Icons.shelves)),
                validator: (value) => value == null || value.trim().isEmpty ? 'برای جلوگیری از گم‌شدن، محل نگهداری را وارد کنید.' : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: _notes,
                minLines: 2,
                maxLines: 4,
                decoration: const InputDecoration(labelText: 'توضیحات اختیاری', prefixIcon: Icon(Icons.notes)),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Container(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
          decoration: const BoxDecoration(color: Colors.white, boxShadow: [BoxShadow(blurRadius: 18, color: Color(0x16000000))]),
          child: Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _saving || widget.existing != null ? null : () => _save(scanNext: true),
                  icon: const Icon(Icons.add_a_photo_outlined),
                  label: const Text('ثبت و عکس بعدی'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton.icon(
                  onPressed: _saving ? null : () => _save(scanNext: false),
                  icon: _saving
                      ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.save_outlined),
                  label: const Text('تأیید و ثبت'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CameraPanel extends StatelessWidget {
  const _CameraPanel({
    required this.imagePath,
    required this.scanning,
    required this.confidence,
    required this.onCamera,
    required this.onGallery,
  });

  final String? imagePath;
  final bool scanning;
  final double confidence;
  final VoidCallback onCamera;
  final VoidCallback onGallery;

  @override
  Widget build(BuildContext context) {
    final file = imagePath == null ? null : File(imagePath!);
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          SizedBox(
            height: 190,
            width: double.infinity,
            child: scanning
                ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [CircularProgressIndicator(), SizedBox(height: 12), Text('در حال خواندن برچسب...')]))
                : file != null && file.existsSync()
                    ? Image.file(file, fit: BoxFit.cover)
                    : Container(
                        color: Theme.of(context).colorScheme.surfaceContainerHighest,
                        child: const Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.document_scanner_outlined, size: 52), SizedBox(height: 10), Text('برچسب مرسوله را کامل و صاف داخل کادر بگیر')]),
                      ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(child: FilledButton.icon(onPressed: scanning ? null : onCamera, icon: const Icon(Icons.camera_alt_outlined), label: const Text('گرفتن عکس'))),
                const SizedBox(width: 8),
                IconButton.filledTonal(onPressed: scanning ? null : onGallery, icon: const Icon(Icons.photo_library_outlined), tooltip: 'انتخاب از گالری'),
                if (confidence > 0) ...[
                  const SizedBox(width: 8),
                  Chip(label: Text('دقت ${(confidence * 100).round()}٪')),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Text(text, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900));
}
