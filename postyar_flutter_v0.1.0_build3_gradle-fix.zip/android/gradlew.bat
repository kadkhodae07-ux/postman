@echo off
where gradle >nul 2>nul
if %errorlevel% neq 0 (
  echo Gradle not found. Run flutter create --platforms=android . once.
  exit /b 1
)
gradle %*
