package ir.postyar.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
