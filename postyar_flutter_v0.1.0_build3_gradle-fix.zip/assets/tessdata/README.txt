The GitHub workflow and tool/fetch_ocr_model.sh download fas.traineddata from the official tesseract-ocr/tessdata_fast repository before release builds.
