#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DIR="$ROOT/assets/tessdata"
mkdir -p "$DIR"
curl -L --fail --retry 3 \
  "https://github.com/tesseract-ocr/tessdata_fast/raw/refs/heads/main/fas.traineddata" \
  -o "$DIR/fas.traineddata"
printf '{"files":["fas.traineddata"]}\n' > "$ROOT/assets/tessdata_config.json"
echo "Persian OCR model downloaded: $DIR/fas.traineddata"
