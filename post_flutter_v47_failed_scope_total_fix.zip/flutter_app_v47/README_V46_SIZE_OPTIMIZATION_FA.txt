POST MANAGEMENT v46 — APK SIZE OPTIMIZATION

App logic:
- No feature was removed.
- Scanner engines remain: ML Kit Text, ML Kit Barcode, Tesseract OCR, ZXing.

Real Workflow changes:
- Removed --no-tree-shake-icons.
- Enabled icon tree shaking.
- Release APK targets android-arm64 only.
- Added Gradle ndk abiFilters arm64-v8a to prevent plugin native libraries from other ABIs entering the APK.
- Enabled R8 minify for release.
- Enabled shrinkResources for release.
- Added --split-debug-info=build/symbols so Dart debug symbols stay outside the APK.
- Added SIZE_REPORT.txt showing APK size, 30 largest files, and packaged native ABIs.
- Build fails above 120 MiB so a 190 MiB universal APK cannot silently be published again.

Compatibility:
- This APK is ARM64-only. It supports modern 64-bit Android devices.
- Very old 32-bit-only ARM devices will not be able to install this APK.
- No OCR/barcode capability was removed.
