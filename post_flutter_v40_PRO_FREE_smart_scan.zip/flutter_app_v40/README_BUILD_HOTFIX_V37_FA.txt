POST MANAGEMENT v37 — Runner / Android SDK Workflow Hotfix

لاگ failure-logs (4):
- فقط flutter-doctor.txt و project-files.txt تولید شده بود.
- project-files.txt فقط pubspec.yaml داشت.
- هیچ android/app/build.gradle و هیچ flutter-build.log وجود نداشت.
نتیجه: Workflow قبل از مرحله Prepare Android شکست خورده است.

ریشه:
مرحله v36 برای اجرای sdkmanager و پذیرش License اضافه شده بود، در حالی که GitHub Ubuntu 24.04
Android SDK Platform 35 را از قبل نصب دارد. این مرحله اضافی حذف شد.

اصلاح v37:
- runs-on روی ubuntu-24.04 ثابت شد.
- هیچ sdkmanager install / --licenses اجرا نمی‌شود.
- فقط وجود platforms/android-35/android.jar Verify می‌شود.
- compileSdk 35 و R8 Rules نسخه v36 حفظ شدند.
- failure artifact اکنون workflow-stages.txt، android-sdk.txt، Gradle و proguard/missing_rules را نیز ذخیره می‌کند.
- نسخه برنامه: 1.0.37+37
- Backend: همان v60، بدون تغییر منطقی.
