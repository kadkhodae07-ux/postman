POST MANAGEMENT v36 — Build Release Hotfix

ریشه خطای گزارش‌شده:
1) flutter_plugin_android_lifecycle به compileSdk 35 یا بالاتر نیاز دارد، اما پروژه تولیدشده با compileSdk 34 ساخته می‌شد.
2) google_mlkit_text_recognition برای اسکریپت‌های اختیاری Chinese/Japanese/Korean/Devanagari ارجاع دارد.
   این برنامه فقط TextRecognitionScript.latin را استفاده می‌کند؛ R8 نبودن کلاس‌های اختیاری را خطای Missing classes تشخیص می‌داد.

اصلاحات:
- compileSdk به 35 Pin شد.
- Android SDK platform 35 قبل از Build تضمین می‌شود.
- proguard-rules.pro برای کلاس‌های اختیاری و استفاده‌نشده ML Kit ایجاد می‌شود.
- Rule فایل به release build متصل می‌شود.
- قبل از Build Release، flutter clean و pub get اجرا می‌شود.
- Gradle VFS watch برای Build غیرفعال شده تا هشدار file watcher کاهش یابد.
- نسخه Flutter به 1.0.36+36 ارتقا یافت.
- Backend اصلی همان v60 است و منطق سرور تغییر نکرده است.

لاگ قبلی:
flutter analyze پاس شده بود؛ خطا فقط در assembleRelease/minifyReleaseWithR8 رخ داده است.
