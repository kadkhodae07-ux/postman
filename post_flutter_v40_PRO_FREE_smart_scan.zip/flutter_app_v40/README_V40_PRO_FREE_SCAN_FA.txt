POST MANAGEMENT v40 — Professional Free Smart Scan

نسخه: 1.0.40+40
Backend target: v65 (بدون تغییر)

اسکن حرفه‌ای رایگان:
- Google ML Kit Barcode Scanner
- ZXing C++ via flutter_zxing 2.2.1 as hard fallback
- tryHarder + rotate + inverted + downscale for difficult barcodes
- Tesseract Persian OCR in multiple modes (PSM 6 + sparse PSM 11)
- ML Kit Latin/digit OCR
- grayscale / contrast enhancement / binary threshold variants
- Persian, Arabic and English digit normalization
- strict Iranian mobile validation
- tracking-code OCR fallback when damaged barcode cannot be decoded
- name parser with postal-noise filtering; weak garbage guesses are not auto-filled
- field-level confidence and review warnings
- batch scan retains the same professional pipeline

واقعیت فنی:
هیچ موتور رایگان یا تجاری نمی‌تواند 100٪ روی بارکد نابودشده یا دست‌خط ناخوانا تضمین بدهد.
این نسخه به‌جای ثبت اشتباه، نتیجه کم‌اطمینان را برای بررسی دستی علامت می‌زند.
