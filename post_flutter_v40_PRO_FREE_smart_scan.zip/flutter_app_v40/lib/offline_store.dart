import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class OfflineBinaryPhoto {
  const OfflineBinaryPhoto({required this.filename, required this.bytes});
  final String filename;
  final Uint8List bytes;
}

class OfflineQueuedPhoto {
  const OfflineQueuedPhoto({required this.path, required this.filename});
  final String path;
  final String filename;

  Map<String, dynamic> toJson() => {'path': path, 'filename': filename};

  factory OfflineQueuedPhoto.fromJson(Map<String, dynamic> json) => OfflineQueuedPhoto(
        path: (json['path'] ?? '').toString(),
        filename: (json['filename'] ?? '').toString(),
      );
}

class OfflineOperation {
  OfflineOperation({
    required this.id,
    required this.owner,
    required this.type,
    required this.operationId,
    required this.payload,
    required this.photos,
    required this.attempts,
    required this.createdAt,
  });

  final int id;
  final String owner;
  final String type;
  final String operationId;
  final Map<String, dynamic> payload;
  final List<OfflineQueuedPhoto> photos;
  final int attempts;
  final int createdAt;

  factory OfflineOperation.fromRow(Map<String, dynamic> row) {
    dynamic payloadValue;
    dynamic photoValue;
    try {
      payloadValue = jsonDecode((row['payload_json'] ?? '{}').toString());
    } catch (_) {
      payloadValue = <String, dynamic>{};
    }
    try {
      photoValue = jsonDecode((row['media_json'] ?? '[]').toString());
    } catch (_) {
      photoValue = <dynamic>[];
    }
    final payload = payloadValue is Map ? Map<String, dynamic>.from(payloadValue) : <String, dynamic>{};
    final photos = photoValue is List
        ? photoValue.whereType<Map>().map((e) => OfflineQueuedPhoto.fromJson(Map<String, dynamic>.from(e))).toList()
        : <OfflineQueuedPhoto>[];
    return OfflineOperation(
      id: (row['id'] as num?)?.toInt() ?? 0,
      owner: (row['owner'] ?? '').toString(),
      type: (row['type'] ?? '').toString(),
      operationId: (row['operation_id'] ?? '').toString(),
      payload: payload,
      photos: photos,
      attempts: (row['attempts'] as num?)?.toInt() ?? 0,
      createdAt: (row['created_at'] as num?)?.toInt() ?? 0,
    );
  }
}

class OfflineSyncReport {
  const OfflineSyncReport({required this.completed, required this.retried, required this.remaining});
  final int completed;
  final int retried;
  final int remaining;
}

/// SQLite-backed queue. Network work is intentionally processed one request at a time.
class OfflineStore {
  Database? _database;
  final FlutterSecureStorage _secureStorage = const FlutterSecureStorage();
  final AesGcm _cipher = AesGcm.with256bits();
  SecretKey? _secretKeyCache;

  Future<SecretKey> _secretKey() async {
    final cached = _secretKeyCache;
    if (cached != null) return cached;
    final stored = await _secureStorage.read(key: 'post_offline_aes_key_v2');
    if (stored != null && stored.isNotEmpty) {
      try {
        final bytes = base64Decode(stored);
        if (bytes.length == 32) {
          final key = SecretKey(bytes);
          _secretKeyCache = key;
          return key;
        }
      } catch (_) {}
    }
    final key = await _cipher.newSecretKey();
    final bytes = await key.extractBytes();
    await _secureStorage.write(key: 'post_offline_aes_key_v2', value: base64Encode(bytes));
    _secretKeyCache = key;
    return key;
  }

  Future<String> _encryptText(String plain) async {
    final key = await _secretKey();
    final nonce = _cipher.newNonce();
    final box = await _cipher.encrypt(utf8.encode(plain), secretKey: key, nonce: nonce);
    final packed = <int>[...box.nonce, ...box.mac.bytes, ...box.cipherText];
    return 'enc2:${base64Encode(packed)}';
  }

  Future<String> _decryptText(String stored) async {
    if (!stored.startsWith('enc2:')) return stored; // سازگاری و مهاجرت تدریجی نسخه قدیمی
    final packed = base64Decode(stored.substring(5));
    if (packed.length < 29) throw StateError('offline_cipher_invalid');
    final nonce = packed.sublist(0, 12);
    final mac = Mac(packed.sublist(12, 28));
    final cipherText = packed.sublist(28);
    final clear = await _cipher.decrypt(SecretBox(cipherText, nonce: nonce, mac: mac), secretKey: await _secretKey());
    return utf8.decode(clear);
  }

  Future<Uint8List> _encryptBytes(Uint8List plain) async {
    final nonce = _cipher.newNonce();
    final box = await _cipher.encrypt(plain, secretKey: await _secretKey(), nonce: nonce);
    return Uint8List.fromList(<int>[0x50, 0x53, 0x4d, 0x32, ...box.nonce, ...box.mac.bytes, ...box.cipherText]);
  }

  Future<Uint8List> _decryptBytes(Uint8List stored) async {
    if (stored.length < 32 || stored[0] != 0x50 || stored[1] != 0x53 || stored[2] != 0x4d || stored[3] != 0x32) return stored;
    final nonce = stored.sublist(4, 16);
    final mac = Mac(stored.sublist(16, 32));
    final cipherText = stored.sublist(32);
    final clear = await _cipher.decrypt(SecretBox(cipherText, nonce: nonce, mac: mac), secretKey: await _secretKey());
    return Uint8List.fromList(clear);
  }

  Future<OfflineOperation> _operationFromRow(Map<String, dynamic> row) async {
    dynamic payloadValue;
    dynamic photoValue;
    try { payloadValue = jsonDecode(await _decryptText((row['payload_json'] ?? '{}').toString())); } catch (_) { payloadValue = <String, dynamic>{}; }
    try { photoValue = jsonDecode(await _decryptText((row['media_json'] ?? '[]').toString())); } catch (_) { photoValue = <dynamic>[]; }
    final payload = payloadValue is Map ? Map<String, dynamic>.from(payloadValue) : <String, dynamic>{};
    final photos = photoValue is List ? photoValue.whereType<Map>().map((e) => OfflineQueuedPhoto.fromJson(Map<String, dynamic>.from(e))).toList() : <OfflineQueuedPhoto>[];
    return OfflineOperation(
      id: (row['id'] as num?)?.toInt() ?? 0,
      owner: (row['owner'] ?? '').toString(),
      type: (row['type'] ?? '').toString(),
      operationId: (row['operation_id'] ?? '').toString(),
      payload: payload,
      photos: photos,
      attempts: (row['attempts'] as num?)?.toInt() ?? 0,
      createdAt: (row['created_at'] as num?)?.toInt() ?? 0,
    );
  }


  Future<void> init() async {
    await _db;
    await _migrateLegacyPlaintext();
  }

  Future<void> _migrateLegacyPlaintext() async {
    final db = await _db;
    final cacheRows = await db.query('local_cache', columns: ['cache_key', 'payload_json']);
    for (final row in cacheRows) {
      final raw = (row['payload_json'] ?? '').toString();
      if (raw.isEmpty || raw.startsWith('enc2:')) continue;
      await db.update('local_cache', {'payload_json': await _encryptText(raw)}, where: 'cache_key=?', whereArgs: [row['cache_key']]);
    }
    final queueRows = await db.query('sync_queue', columns: ['id', 'payload_json', 'media_json']);
    for (final row in queueRows) {
      final id = (row['id'] as num?)?.toInt() ?? 0;
      if (id <= 0) continue;
      final payloadRaw = (row['payload_json'] ?? '{}').toString();
      final mediaRaw = (row['media_json'] ?? '[]').toString();
      final updates = <String, Object?>{};
      if (!payloadRaw.startsWith('enc2:')) updates['payload_json'] = await _encryptText(payloadRaw);
      if (!mediaRaw.startsWith('enc2:')) {
        try {
          final decoded = jsonDecode(mediaRaw);
          if (decoded is List) {
            for (final item in decoded.whereType<Map>()) {
              final photo = OfflineQueuedPhoto.fromJson(Map<String, dynamic>.from(item));
              if (photo.path.isEmpty) continue;
              final file = File(photo.path);
              if (!await file.exists()) continue;
              final bytes = await file.readAsBytes();
              if (bytes.length >= 4 && bytes[0] == 0x50 && bytes[1] == 0x53 && bytes[2] == 0x4d && bytes[3] == 0x32) continue;
              await file.writeAsBytes(await _encryptBytes(bytes), flush: true);
            }
          }
        } catch (_) {}
        updates['media_json'] = await _encryptText(mediaRaw);
      }
      if (updates.isNotEmpty) await db.update('sync_queue', updates, where: 'id=?', whereArgs: [id]);
    }
  }

  Future<Database> get _db async {
    final current = _database;
    if (current != null) return current;
    final docs = await getApplicationDocumentsDirectory();
    final dbPath = path.join(docs.path, 'post_sms_offline_v1.db');
    final opened = await openDatabase(
      dbPath,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE sync_queue (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            owner TEXT NOT NULL,
            type TEXT NOT NULL,
            operation_id TEXT NOT NULL UNIQUE,
            payload_json TEXT NOT NULL,
            media_json TEXT NOT NULL DEFAULT '[]',
            attempts INTEGER NOT NULL DEFAULT 0,
            next_retry_at INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL,
            updated_at INTEGER NOT NULL,
            last_error TEXT
          )
        ''');
        await db.execute('CREATE INDEX idx_sync_queue_owner_due ON sync_queue(owner, next_retry_at, id)');
        await db.execute('''
          CREATE TABLE local_cache (
            cache_key TEXT PRIMARY KEY,
            payload_json TEXT NOT NULL,
            updated_at INTEGER NOT NULL
          )
        ''');
      },
    );
    _database = opened;
    return opened;
  }

  Future<void> writeCache(String key, dynamic value) async {
    final db = await _db;
    await db.insert(
      'local_cache',
      {
        'cache_key': key,
        'payload_json': await _encryptText(jsonEncode(value)),
        'updated_at': DateTime.now().millisecondsSinceEpoch,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<dynamic> readCache(String key) async {
    final db = await _db;
    final rows = await db.query('local_cache', where: 'cache_key=?', whereArgs: [key], limit: 1);
    if (rows.isEmpty) return null;
    try {
      return jsonDecode(await _decryptText((rows.first['payload_json'] ?? '').toString()));
    } catch (_) {
      return null;
    }
  }

  Future<void> enqueue({
    required String owner,
    required String type,
    required String operationId,
    required Map<String, dynamic> payload,
    List<OfflineQueuedPhoto> photos = const [],
  }) async {
    final db = await _db;
    final now = DateTime.now().millisecondsSinceEpoch;
    await db.insert(
      'sync_queue',
      {
        'owner': owner,
        'type': type,
        'operation_id': operationId,
        'payload_json': await _encryptText(jsonEncode(payload)),
        'media_json': await _encryptText(jsonEncode(photos.map((e) => e.toJson()).toList())),
        'attempts': 0,
        'next_retry_at': 0,
        'created_at': now,
        'updated_at': now,
      },
      conflictAlgorithm: ConflictAlgorithm.ignore,
    );
  }

  Future<void> enqueueShipment({
    required String owner,
    required String operationId,
    required Map<String, dynamic> fields,
    required List<OfflineBinaryPhoto> photos,
  }) async {
    final docs = await getApplicationDocumentsDirectory();
    final mediaDir = Directory(path.join(docs.path, 'post_sms_sync_media'));
    if (!await mediaDir.exists()) await mediaDir.create(recursive: true);
    final queued = <OfflineQueuedPhoto>[];
    for (var i = 0; i < photos.length; i++) {
      final item = photos[i];
      final cleanName = item.filename.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');
      final file = File(path.join(mediaDir.path, '${operationId}_$i-$cleanName'));
      await file.writeAsBytes(await _encryptBytes(item.bytes), flush: true);
      queued.add(OfflineQueuedPhoto(path: file.path, filename: cleanName.isEmpty ? 'photo_${i + 1}.jpg' : cleanName));
    }
    await enqueue(owner: owner, type: 'shipment_save', operationId: operationId, payload: fields, photos: queued);
  }

  Future<int> pendingCount(String owner) async {
    if (owner.trim().isEmpty) return 0;
    final db = await _db;
    return Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM sync_queue WHERE owner=?', [owner])) ?? 0;
  }

  Future<OfflineOperation?> nextDue(String owner) async {
    final db = await _db;
    final rows = await db.query(
      'sync_queue',
      where: 'owner=? AND next_retry_at<=?',
      whereArgs: [owner, DateTime.now().millisecondsSinceEpoch],
      orderBy: 'id ASC',
      limit: 1,
    );
    return rows.isEmpty ? null : await _operationFromRow(rows.first);
  }

  Future<Uint8List> readQueuedPhotoBytes(OfflineQueuedPhoto photo) async {
    final file = File(photo.path);
    if (!await file.exists()) return Uint8List(0);
    return _decryptBytes(await file.readAsBytes());
  }

  Future<void> complete(OfflineOperation operation) async {
    final db = await _db;
    await db.delete('sync_queue', where: 'id=?', whereArgs: [operation.id]);
    for (final photo in operation.photos) {
      try {
        final file = File(photo.path);
        if (await file.exists()) await file.delete();
      } catch (_) {}
    }
  }

  Future<void> retry(OfflineOperation operation, Object error) async {
    final db = await _db;
    final attempts = operation.attempts + 1;
    const retrySeconds = [20, 45, 90, 180, 300, 600, 900, 1800];
    final seconds = retrySeconds[attempts.clamp(0, retrySeconds.length - 1)];
    final now = DateTime.now().millisecondsSinceEpoch;
    final errorText = error.toString();
    final shortError = errorText.length > 500 ? errorText.substring(0, 500) : errorText;
    await db.update(
      'sync_queue',
      {
        'attempts': attempts,
        'next_retry_at': now + seconds * 1000,
        'updated_at': now,
        'last_error': shortError,
      },
      where: 'id=?',
      whereArgs: [operation.id],
    );
  }

  Future<OfflineSyncReport> process({
    required String owner,
    required Future<void> Function(OfflineOperation operation) execute,
    int maxItems = 2,
    Duration gap = const Duration(seconds: 2),
  }) async {
    var completed = 0;
    var retried = 0;
    for (var i = 0; i < maxItems; i++) {
      final operation = await nextDue(owner);
      if (operation == null) break;
      try {
        await execute(operation);
        await complete(operation);
        completed++;
      } catch (error) {
        await retry(operation, error);
        retried++;
        break;
      }
      if (i + 1 < maxItems) await Future<void>.delayed(gap);
    }
    return OfflineSyncReport(completed: completed, retried: retried, remaining: await pendingCount(owner));
  }
}
