import 'dart:async';
import 'dart:io';

import 'package:flutter_tesseract_ocr/flutter_tesseract_ocr.dart';
import 'package:flutter_zxing/flutter_zxing.dart' as zxing;
import 'package:google_mlkit_barcode_scanning/google_mlkit_barcode_scanning.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

class ScannedShipmentDraft {
  ScannedShipmentDraft({
    required this.file,
    required this.rawText,
    required this.barcodes,
    required this.fullname,
    required this.phone,
    required this.paymentType,
    required this.trackingCode,
    required this.confidence,
    this.nameConfidence = 0,
    this.phoneConfidence = 0,
    this.trackingConfidence = 0,
    this.paymentConfidence = 0,
    this.usedHardBarcodeFallback = false,
    this.trackingFromOcrFallback = false,
    List<String>? warnings,
  }) : warnings = warnings ?? <String>[];

  final XFile file;
  final String rawText;
  final List<String> barcodes;
  String fullname;
  String phone;
  String paymentType;
  String trackingCode;
  double confidence;
  double nameConfidence;
  double phoneConfidence;
  double trackingConfidence;
  double paymentConfidence;
  final bool usedHardBarcodeFallback;
  final bool trackingFromOcrFallback;
  final List<String> warnings;

  bool get readyToMessage =>
      fullname.trim().length >= 3 && RegExp(r'^09\d{9}$').hasMatch(phone);

  bool get needsReview =>
      warnings.isNotEmpty ||
      confidence < .80 ||
      (fullname.isNotEmpty && nameConfidence < .62) ||
      (phone.isNotEmpty && phoneConfidence < .75) ||
      (trackingCode.isNotEmpty && trackingConfidence < .60);
}

class _ScanVariant {
  const _ScanVariant(this.path, this.kind, {this.generated = false});
  final String path;
  final String kind;
  final bool generated;
}

class _Candidate {
  _Candidate(this.value, this.score);
  final String value;
  double score;
}

class _ParsedFields {
  _ParsedFields({
    required this.fullname,
    required this.phone,
    required this.paymentType,
    required this.tracking,
    required this.nameConfidence,
    required this.phoneConfidence,
    required this.paymentConfidence,
    required this.trackingConfidence,
    required this.trackingFromOcr,
  });

  final String fullname;
  final String phone;
  final String paymentType;
  final String tracking;
  final double nameConfidence;
  final double phoneConfidence;
  final double paymentConfidence;
  final double trackingConfidence;
  final bool trackingFromOcr;
}

class SmartShipmentScanner {
  static const _faDigits = '۰۱۲۳۴۵۶۷۸۹';
  static const _arDigits = '٠١٢٣٤٥٦٧٨٩';

  static final RegExp _postalNoise = RegExp(
    r'(?:پست|پستی|مرسوله|بسته|پاکت|گیرنده|فرستنده|آدرس|نشانی|استان|شهر|شهرستان|'
    r'خیابان|کوچه|پلاک|کد\s*پستی|کد\s*رهگیری|رهگیری|بارکد|تلفن|موبایل|همراه|شماره|'
    r'مقصد|مبدأ|مبدا|مبلغ|وزن|کرایه|پرداخت|در\s*محل|تومان|ریال|تاریخ|ساعت|دفتر|'
    r'اداره|شرکت|جمهوری|اسلامی|ایران|ارسال|تحویل|سفارش|شناسه|مشتری|خدمات)',
    caseSensitive: false,
  );

  static String _digits(String value) {
    var s = value;
    for (var i = 0; i < 10; i++) {
      s = s.replaceAll(_faDigits[i], '$i').replaceAll(_arDigits[i], '$i');
    }
    return s;
  }

  static String _normalizeLetters(String value) => value
      .replaceAll('ي', 'ی')
      .replaceAll('ى', 'ی')
      .replaceAll('ك', 'ک')
      .replaceAll('ۀ', 'ه')
      .replaceAll('ة', 'ه')
      .replaceAll(RegExp(r'[\u200c\u200e\u200f]'), ' ')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();

  static String _compactText(String value) {
    final seen = <String>{};
    final out = <String>[];
    for (final raw in value.split(RegExp(r'[\r\n]+'))) {
      final line = _normalizeLetters(raw);
      if (line.length < 2) continue;
      final key = line.toLowerCase();
      if (seen.add(key)) out.add(line);
    }
    return out.join('\n');
  }

  static bool _validMobile(String value) => RegExp(r'^09\d{9}$').hasMatch(value);

  static String _normalizePhone(String raw) {
    var p = _digits(raw).replaceAll(RegExp(r'\D'), '');
    if (p.startsWith('0098') && p.length >= 14) {
      p = '0${p.substring(4)}';
    } else if (p.startsWith('98') && p.length == 12) {
      p = '0${p.substring(2)}';
    } else if (p.length == 10 && p.startsWith('9')) {
      p = '0$p';
    }
    return _validMobile(p) ? p : '';
  }

  static String _normalizeTracking(String raw) {
    final s = _digits(raw)
        .replaceAll(RegExp(r'[\s،,._/:\\]+'), '')
        .replaceAll(RegExp(r'[^A-Za-z0-9\-]'), '')
        .trim();
    return s;
  }

  static double _clamp01(num v) => v.clamp(0, 1).toDouble();

  // ---------- Image preprocessing ----------
  static Future<List<_ScanVariant>> _buildVariants(XFile file) async {
    final variants = <_ScanVariant>[_ScanVariant(file.path, 'original')];
    try {
      final bytes = await file.readAsBytes();
      var decoded = img.decodeImage(bytes);
      if (decoded == null) return variants;
      decoded = img.bakeOrientation(decoded);

      // Keep enough detail for small printed digits, while limiting memory on large camera photos.
      if (decoded.width > 2600) {
        decoded = img.copyResize(
          decoded,
          width: 2400,
          interpolation: img.Interpolation.linear,
        );
      } else if (decoded.width < 1500 && decoded.width > 500) {
        decoded = img.copyResize(
          decoded,
          width: 1800,
          interpolation: img.Interpolation.cubic,
        );
      }

      final temp = await getTemporaryDirectory();
      final dir = Directory('${temp.path}/post_scan_v40');
      if (!await dir.exists()) await dir.create(recursive: true);
      final stamp = '${DateTime.now().microsecondsSinceEpoch}_${file.name.hashCode.abs()}';

      final enhanced = img.Image.from(decoded);
      img.grayscale(enhanced);
      img.contrast(enhanced, contrast: 155);
      img.adjustColor(enhanced, brightness: 1.06, gamma: .92, contrast: 1.18);

      final enhancedPath = '${dir.path}/${stamp}_enhanced.jpg';
      await File(enhancedPath).writeAsBytes(img.encodeJpg(enhanced, quality: 96), flush: true);
      variants.add(_ScanVariant(enhancedPath, 'enhanced', generated: true));

      final binary = img.Image.from(decoded);
      img.grayscale(binary);
      img.contrast(binary, contrast: 175);
      for (final px in binary) {
        final lum = px.r.toInt();
        final v = lum < 158 ? 0 : 255;
        px
          ..r = v
          ..g = v
          ..b = v;
      }
      final binaryPath = '${dir.path}/${stamp}_binary.png';
      await File(binaryPath).writeAsBytes(img.encodePng(binary), flush: true);
      variants.add(_ScanVariant(binaryPath, 'binary', generated: true));
    } catch (_) {
      // Original image remains available if preprocessing fails.
    }
    return variants;
  }

  static Future<void> _cleanupVariants(List<_ScanVariant> variants) async {
    for (final v in variants.where((e) => e.generated)) {
      try {
        final f = File(v.path);
        if (await f.exists()) await f.delete();
      } catch (_) {}
    }
  }

  // ---------- OCR engines ----------
  static Future<String> _tesseract(
    String path, {
    int psm = 6,
    bool digitsOnly = false,
  }) async {
    try {
      final args = <String, dynamic>{
        'psm': psm,
        'preserve_interword_spaces': '1',
        'user_defined_dpi': '300',
      };
      if (digitsOnly) {
        args['tessedit_char_whitelist'] = '0123456789۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩+-() ';
      }
      return (await FlutterTesseractOcr.extractText(
        path,
        language: 'fas',
        args: args,
      ))
          .trim();
    } catch (_) {
      return '';
    }
  }

  static Future<String> _mlText(TextRecognizer recognizer, String path) async {
    try {
      return (await recognizer.processImage(InputImage.fromFilePath(path))).text.trim();
    } catch (_) {
      return '';
    }
  }

  // ---------- Barcode engines ----------
  static void _voteCode(Map<String, double> votes, String raw, double weight) {
    final v = _normalizeTracking(raw);
    if (v.length < 6 || v.length > 64) return;
    votes[v] = (votes[v] ?? 0) + weight;
  }

  static Future<void> _scanMlKitBarcode(
    BarcodeScanner scanner,
    String path,
    Map<String, double> votes, {
    double weight = 3,
  }) async {
    try {
      final found = await scanner.processImage(InputImage.fromFilePath(path));
      for (final b in found) {
        final raw = (b.rawValue ?? '').trim();
        if (raw.isNotEmpty) _voteCode(votes, raw, weight);
      }
    } catch (_) {}
  }

  static Future<bool> _scanZxing(
    String path,
    Map<String, double> votes, {
    double weight = 4,
  }) async {
    try {
      final result = await zxing.zx.readBarcodeImagePathString(
        path,
        zxing.DecodeParams(
          format: zxing.Format.any,
          tryHarder: true,
          tryRotate: true,
          tryInverted: true,
          tryDownscale: true,
          maxSize: 2048,
        ),
      );
      if (result.isValid) {
        final raw = result.text.trim();
        if (raw.isNotEmpty) {
          _voteCode(votes, raw, weight);
          return true;
        }
      }
    } catch (_) {}
    return false;
  }

  static bool _hasStrongBarcode(Map<String, double> votes) =>
      votes.values.any((score) => score >= 6);

  static List<String> _sortedBarcodes(Map<String, double> votes) {
    final items = votes.entries.toList()
      ..sort((a, b) {
        final byScore = b.value.compareTo(a.value);
        if (byScore != 0) return byScore;
        return b.key.length.compareTo(a.key.length);
      });
    return items.map((e) => e.key).toList();
  }

  // ---------- Phone extraction ----------
  static _Candidate _bestPhone(List<String> texts) {
    final scores = <String, double>{};
    for (final text in texts) {
      for (final line in text.split(RegExp(r'[\r\n]+'))) {
        final normalized = _digits(line);
        final explicit = RegExp(
          r'(?:موبایل|همراه|تلفن|شماره\s*(?:گیرنده|تماس)?)',
          caseSensitive: false,
        ).hasMatch(normalized);
        final re = RegExp(
          r'(?:^|[^\d])((?:\+?98|0098|98|0)?9(?:[\s\-\.\(\)]*\d){9})(?!\d)',
        );
        for (final m in re.allMatches(normalized)) {
          final phone = _normalizePhone(m.group(1) ?? '');
          if (phone.isEmpty) continue;
          scores[phone] = (scores[phone] ?? 0) + (explicit ? 4.0 : 1.6);
        }
      }
    }
    if (scores.isEmpty) return _Candidate('', 0);
    final best = scores.entries.reduce((a, b) => a.value >= b.value ? a : b);
    return _Candidate(best.key, best.value);
  }

  // ---------- Name extraction ----------
  static String _cleanName(String raw) {
    var s = _normalizeLetters(raw)
        .replaceAll(RegExp(r'[0-9۰-۹٠-٩]'), ' ')
        .replaceAll(RegExp(r'[^\u0600-\u06FF\s]'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();

    s = s
        .replaceFirst(
          RegExp(
            r'^(?:نام\s*(?:و\s*نام\s*خانوادگی)?|گیرنده|نام\s*گیرنده|تحویل\s*گیرنده)\s+',
            caseSensitive: false,
          ),
          '',
        )
        .trim();

    final tokens = s.split(' ').where((e) => e.isNotEmpty).toList();
    if (tokens.length < 2 || tokens.length > 5) return '';
    if (tokens.any((t) => t.length < 2)) return '';
    if (_postalNoise.hasMatch(s)) return '';

    final letters = RegExp(r'[\u0600-\u06FF]').allMatches(s).length;
    if (letters < 5 || s.length < 5 || s.length > 48) return '';

    // Reject highly implausible OCR fragments.
    final compact = s.replaceAll(' ', '');
    if (compact.length < 5) return '';
    if (RegExp(r'^(.)\1{3,}$').hasMatch(compact)) return '';
    return s;
  }

  static _Candidate _bestName(List<String> texts) {
    final scores = <String, double>{};

    void add(String raw, double score) {
      final name = _cleanName(raw);
      if (name.isEmpty) return;
      scores[name] = (scores[name] ?? 0) + score;
    }

    final inline = RegExp(
      r'(?:نام\s*(?:و\s*نام\s*خانوادگی)?\s*(?:گیرنده)?|نام\s*گیرنده|تحویل\s*گیرنده|گیرنده)\s*[:：\-]?\s*(.+)$',
      caseSensitive: false,
    );

    for (final text in texts) {
      final lines = text
          .split(RegExp(r'[\r\n]+'))
          .map(_normalizeLetters)
          .where((e) => e.length >= 3)
          .toList();

      for (var i = 0; i < lines.length; i++) {
        final line = lines[i];
        final m = inline.firstMatch(line);
        if (m != null) add(m.group(1) ?? '', 7.0);

        if (RegExp(r'^(?:گیرنده|نام\s*گیرنده|نام\s*و\s*نام\s*خانوادگی)\s*[:：\-]?$')
            .hasMatch(line)) {
          if (i + 1 < lines.length) add(lines[i + 1], 6.0);
          if (i + 2 < lines.length) add(lines[i + 2], 3.0);
        }
      }

      // Weak generic candidates are accepted only when repeated by multiple OCR passes.
      for (final line in lines) {
        if (!RegExp(r'[\u0600-\u06FF]').hasMatch(line)) continue;
        if (_postalNoise.hasMatch(line)) continue;
        final name = _cleanName(line);
        if (name.isNotEmpty) add(name, 1.15);
      }
    }

    if (scores.isEmpty) return _Candidate('', 0);
    final ordered = scores.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final best = ordered.first;

    // Do not auto-fill weak guesses. This is what prevents garbage such as "و و کش".
    if (best.value < 3.2) return _Candidate('', best.value);
    return _Candidate(best.key, best.value);
  }

  // ---------- Financial type ----------
  static _Candidate _bestPaymentType(List<String> texts) {
    var cod = 0.0;
    var destination = 0.0;
    for (final text in texts) {
      final t = _normalizeLetters(text.replaceAll('\n', ' '));
      if (RegExp(r'پرداخت\s*در\s*محل|COD', caseSensitive: false).hasMatch(t)) {
        cod += 3;
      }
      if (RegExp(r'کرایه\s*در\s*مقصد|پس\s*کرایه|کرایه.*مقصد', caseSensitive: false)
          .hasMatch(t)) {
        destination += 3;
      }
    }
    if (cod == 0 && destination == 0) return _Candidate('', 0);
    return cod > destination
        ? _Candidate('پرداخت در محل', cod)
        : _Candidate('کرایه در مقصد', destination);
  }

  // ---------- Tracking / damaged barcode fallback ----------
  static _Candidate _bestTracking(
    List<String> texts,
    Map<String, double> barcodeVotes,
    String phone,
  ) {
    final scores = <String, double>{};

    for (final e in barcodeVotes.entries) {
      final v = _normalizeTracking(e.key);
      if (v.isEmpty || v == phone) continue;
      var score = e.value * 2;
      if (RegExp(r'^\d{18,32}$').hasMatch(v)) score += 8;
      if (v.length == 24) score += 3;
      scores[v] = (scores[v] ?? 0) + score;
    }

    for (final text in texts) {
      for (final line in text.split(RegExp(r'[\r\n]+'))) {
        final normalized = _digits(line);
        final labeled = RegExp(
          r'(?:کد\s*رهگیری|رهگیری|بارکد|کد\s*مرسوله|tracking)\s*[:：\-]?\s*([A-Za-z0-9۰-۹٠-٩\s\-]{8,45})',
          caseSensitive: false,
        ).firstMatch(normalized);
        if (labeled != null) {
          final v = _normalizeTracking(labeled.group(1) ?? '');
          if (v.length >= 8 && v.length <= 40 && v != phone) {
            scores[v] = (scores[v] ?? 0) + 6;
          }
        }

        final longNumber = RegExp(
          r'(?:^|[^\d])((?:\d[\s\-،,]?){18,32})(?!\d)',
        );
        for (final m in longNumber.allMatches(normalized)) {
          final v = _normalizeTracking(m.group(1) ?? '');
          if (v == phone || v.length < 18 || v.length > 32) continue;
          var score = 2.2;
          if (RegExp(r'بارکد|رهگیری|کد').hasMatch(line)) score += 4;
          if (v.length == 24) score += 1.5;
          scores[v] = (scores[v] ?? 0) + score;
        }
      }
    }

    if (scores.isEmpty) return _Candidate('', 0);
    final ordered = scores.entries.toList()
      ..sort((a, b) {
        final byScore = b.value.compareTo(a.value);
        if (byScore != 0) return byScore;
        return b.key.length.compareTo(a.key.length);
      });
    return _Candidate(ordered.first.key, ordered.first.value);
  }

  static int _occurrencesNormalized(String needle, List<String> texts) {
    if (needle.isEmpty) return 0;
    final n = _normalizeLetters(_digits(needle)).replaceAll(RegExp(r'\s+'), '');
    var count = 0;
    for (final text in texts) {
      final hay = _normalizeLetters(_digits(text)).replaceAll(RegExp(r'\s+'), '');
      if (hay.contains(n)) count++;
    }
    return count;
  }

  static _ParsedFields _parseFields(
    List<String> generalTexts,
    List<String> numericTexts,
    Map<String, double> barcodeVotes,
  ) {
    final allTexts = [...generalTexts, ...numericTexts];
    final phone = _bestPhone(allTexts);
    final name = _bestName(generalTexts);
    final payment = _bestPaymentType(generalTexts);
    final tracking = _bestTracking(allTexts, barcodeVotes, phone.value);

    final barcodeScore = barcodeVotes[tracking.value] ?? 0;
    final trackingFromOcr = tracking.value.isNotEmpty && barcodeScore == 0;

    final phoneAgreement = _occurrencesNormalized(phone.value, allTexts);
    final nameAgreement = _occurrencesNormalized(name.value, generalTexts);
    final trackingAgreement = _occurrencesNormalized(tracking.value, allTexts);

    final phoneConfidence = phone.value.isEmpty
        ? 0.0
        : _clamp01(.55 + phone.score / 12 + (phoneAgreement >= 2 ? .18 : 0));
    final nameConfidence = name.value.isEmpty
        ? 0.0
        : _clamp01(.40 + name.score / 16 + (nameAgreement >= 2 ? .18 : 0));
    final trackingConfidence = tracking.value.isEmpty
        ? 0.0
        : _clamp01(
            (barcodeScore > 0 ? .58 : .34) +
                tracking.score / 35 +
                (barcodeScore >= 6 ? .18 : 0) +
                (trackingAgreement >= 2 ? .10 : 0),
          );
    final paymentConfidence = payment.value.isEmpty ? 0.0 : _clamp01(.58 + payment.score / 15);

    return _ParsedFields(
      fullname: name.value,
      phone: phone.value,
      paymentType: payment.value,
      tracking: tracking.value,
      nameConfidence: nameConfidence,
      phoneConfidence: phoneConfidence,
      paymentConfidence: paymentConfidence,
      trackingConfidence: trackingConfidence,
      trackingFromOcr: trackingFromOcr,
    );
  }

  static double _overallConfidence(_ParsedFields p) {
    var score = 0.0;
    if (p.phone.isNotEmpty) score += .28 * p.phoneConfidence;
    if (p.fullname.isNotEmpty) score += .26 * p.nameConfidence;
    if (p.tracking.isNotEmpty) score += .34 * p.trackingConfidence;
    if (p.paymentType.isNotEmpty) score += .12 * p.paymentConfidence;

    // Normalize against fields actually present so a missing financial type
    // does not unfairly destroy an otherwise strong scan.
    var weight = 0.0;
    if (p.phone.isNotEmpty) weight += .28;
    if (p.fullname.isNotEmpty) weight += .26;
    if (p.tracking.isNotEmpty) weight += .34;
    if (p.paymentType.isNotEmpty) weight += .12;
    if (weight <= 0) return 0;
    return _clamp01(score / weight);
  }

  static List<String> _warnings(_ParsedFields p, bool usedHardFallback) {
    final out = <String>[];
    if (p.fullname.isEmpty) {
      out.add('نام گیرنده با اطمینان کافی تشخیص نشد؛ دستی بررسی شود.');
    } else if (p.nameConfidence < .62) {
      out.add('نام گیرنده نیاز به بازبینی دارد.');
    }

    if (p.phone.isEmpty) {
      out.add('شماره موبایل معتبر استخراج نشد.');
    } else if (p.phoneConfidence < .75) {
      out.add('شماره موبایل از چند OCR تأیید نشده؛ بررسی شود.');
    }

    if (p.tracking.isEmpty) {
      out.add('بارکد/کدرهگیری قابل اعتماد پیدا نشد.');
    } else if (p.trackingFromOcr) {
      out.add('بارکد مستقیم Decode نشد؛ کدرهگیری از متن چاپی/اعداد استخراج شده است.');
    } else if (p.trackingConfidence < .60) {
      out.add('کدرهگیری نیاز به بازبینی دارد.');
    }

    if (usedHardFallback) {
      out.add('برای بارکد از حالت سخت‌گیرانه ZXing/پردازش تقویت‌شده استفاده شد.');
    }
    return out;
  }

  static Future<ScannedShipmentDraft> scan(XFile file) async {
    final variants = await _buildVariants(file);
    final textRecognizer = TextRecognizer(script: TextRecognitionScript.latin);
    final barcodeScanner = BarcodeScanner(formats: [BarcodeFormat.all]);
    final barcodeVotes = <String, double>{};
    final generalTexts = <String>[];
    final numericTexts = <String>[];
    var usedHardBarcodeFallback = false;

    try {
      final original = variants.first;

      // Fast path: two independent free barcode engines on the original photo.
      await _scanMlKitBarcode(barcodeScanner, original.path, barcodeVotes, weight: 3.5);
      final zxingOriginal = await _scanZxing(original.path, barcodeVotes, weight: 4.0);

      // Initial OCR: Persian Tesseract + ML Kit Latin/digits.
      final initial = await Future.wait<String>([
        _tesseract(original.path, psm: 6),
        _mlText(textRecognizer, original.path),
      ]);
      generalTexts.addAll(initial.where((e) => e.trim().isNotEmpty));

      var parsed = _parseFields(generalTexts, numericTexts, barcodeVotes);

      final needsHardOcr = parsed.fullname.isEmpty ||
          parsed.phone.isEmpty ||
          parsed.tracking.isEmpty ||
          parsed.nameConfidence < .60 ||
          parsed.trackingConfidence < .58;

      // Hard barcode fallback only when the original engines did not agree strongly.
      if (!_hasStrongBarcode(barcodeVotes)) {
        usedHardBarcodeFallback = true;
        for (final variant in variants.skip(1)) {
          await _scanMlKitBarcode(barcodeScanner, variant.path, barcodeVotes, weight: 2.4);
          await _scanZxing(variant.path, barcodeVotes, weight: 3.2);
        }
      } else if (!zxingOriginal && barcodeVotes.isNotEmpty) {
        // ML Kit succeeded but ZXing did not; keep result without forcing all hard passes.
        usedHardBarcodeFallback = false;
      }

      if (needsHardOcr && variants.length > 1) {
        final enhanced = variants.firstWhere(
          (e) => e.kind == 'enhanced',
          orElse: () => variants.last,
        );

        // psm 11 is sparse-text mode and often performs better on handwriting,
        // tilted labels, and separated printed fields.
        final enhancedMl = await _mlText(textRecognizer, enhanced.path);
        if (enhancedMl.isNotEmpty) generalTexts.add(enhancedMl);

        final enhancedPsm6 = await _tesseract(enhanced.path, psm: 6);
        if (enhancedPsm6.isNotEmpty) generalTexts.add(enhancedPsm6);

        final sparse = await _tesseract(enhanced.path, psm: 11);
        if (sparse.isNotEmpty) generalTexts.add(sparse);

        final binary = variants.firstWhere(
          (e) => e.kind == 'binary',
          orElse: () => enhanced,
        );
        final digits = await _tesseract(binary.path, psm: 11, digitsOnly: true);
        if (digits.isNotEmpty) numericTexts.add(digits);
      }

      parsed = _parseFields(generalTexts, numericTexts, barcodeVotes);
      final codes = _sortedBarcodes(barcodeVotes);
      final mergedRaw = _compactText([...generalTexts, ...numericTexts].join('\n'));
      final confidence = _overallConfidence(parsed);
      final warnings = _warnings(parsed, usedHardBarcodeFallback);

      return ScannedShipmentDraft(
        file: file,
        rawText: mergedRaw,
        barcodes: codes,
        fullname: parsed.fullname,
        phone: parsed.phone,
        paymentType: parsed.paymentType,
        trackingCode: parsed.tracking,
        confidence: confidence,
        nameConfidence: parsed.nameConfidence,
        phoneConfidence: parsed.phoneConfidence,
        trackingConfidence: parsed.trackingConfidence,
        paymentConfidence: parsed.paymentConfidence,
        usedHardBarcodeFallback: usedHardBarcodeFallback,
        trackingFromOcrFallback: parsed.trackingFromOcr,
        warnings: warnings,
      );
    } finally {
      await textRecognizer.close();
      await barcodeScanner.close();
      await _cleanupVariants(variants);
    }
  }

  static Future<List<ScannedShipmentDraft>> scanBatch(List<XFile> files) async {
    final out = <ScannedShipmentDraft>[];
    for (final file in files) {
      try {
        out.add(await scan(file));
      } catch (_) {
        out.add(
          ScannedShipmentDraft(
            file: file,
            rawText: '',
            barcodes: const [],
            fullname: '',
            phone: '',
            paymentType: '',
            trackingCode: '',
            confidence: 0,
            warnings: const ['پردازش این تصویر ناموفق بود؛ تصویر یا اطلاعات را دستی بررسی کنید.'],
          ),
        );
      }
    }
    return out;
  }
}
