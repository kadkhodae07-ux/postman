import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:another_telephony/telephony.dart' as tel;
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'offline_store.dart';
import 'smart_scan.dart';

const FlutterSecureStorage secureStore = FlutterSecureStorage();

@pragma('vm:entry-point')
Future<void> bankSmsBackgroundHandler(tel.SmsMessage message) async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    final enabled = await secureStore.read(key: 'bank_listener_enabled');
    if (enabled != '1') return;
    final base = (await secureStore.read(key: 'post_api_base_secure') ?? '').replaceAll(RegExp(r'/+$'), '');
    final deviceId = await secureStore.read(key: 'bank_listener_device_id') ?? '';
    final key = await secureStore.read(key: 'bank_listener_device_key') ?? '';
    if (base.isEmpty || deviceId.isEmpty || key.isEmpty) return;
    await http.post(
      Uri.parse('$base/payment_match.php'),
      headers: {'Content-Type': 'application/json; charset=utf-8', 'X-Device-Key': key},
      body: jsonEncode({'device_id': deviceId, 'sender': message.address ?? '', 'body': message.body ?? '', 'received_at': DateTime.now().toIso8601String()}),
    ).timeout(const Duration(seconds: 18));
  } catch (_) {}
}

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const PostSmsApp());
}

const persianMonths = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
];

const shipmentTypes = ['بسته', 'پاکت', 'امانت', 'گواهینامه', 'کارت سوخت', 'کارت بانکی', 'کارت پلاک', 'برگ سبز'];


const legacySmsPreferenceKeys = <String>[
  'sms_pending_local',
  'sms_local_messages',
  'pending_sms_messages',
  'local_sms_outbox',
  'sms_panel_sent_history',
  'sms_sent_history',
  'smsir_sent_history',
  'sms_history',
  'sent_messages',
  'sms_panel_cache',
];

const String kDefaultApiBase = 'https://podtman.anony.ir/post/api';
const int kAppVersionCode = 42;
const String kAppVersionName = '1.0.42';


const kNavy = Color(0xff1d9bf0);
const kNavy2 = Color(0xff27c4a6);
const kOrange = Color(0xff16a34a);
const kSoftBg = Color(0xffedf9f8);
const kBorder = Color(0xffb9e7df);
const kSurface = Color(0xfff6fffd);
const kText = Color(0xff166b80);
const kMuted = Color(0xff5d8d98);
const kSoftBlue = Color(0xffdff4ff);
const kSoftGreen = Color(0xffdcfce7);
const kSoftMint = Color(0xffe7fff7);
const kSoftYellow = Color(0xfffff7df);
const kDanger = Color(0xffef6f6c);

const appPermissionLabels = {
  'sms.send': 'ارسال پیامک',
  'sms.view': 'مشاهده پیام‌ها',
  'shipment.create': 'ثبت مرسوله',
  'shipment.view': 'مشاهده مرسولات',
  'user.view': 'مشاهده کاربران',
  'user.manage': 'مدیریت کاربران',
  'dashboard.view': 'داشبورد',
  'report.view': 'گزارش‌ها',
  'log.view': 'لاگ‌ها',
};

const statusText = {
  'registered': 'ثبت شد',
  'processing': 'در حال پردازش',
  'in_transit': 'در مسیر',
  'delivered': 'تحویل شد',
  'returned': 'برگشتی',
  'cancelled': 'لغو شده',
};

String toFa(Object? value) => '$value'.replaceAllMapped(RegExp(r'\d'), (m) => '۰۱۲۳۴۵۶۷۸۹'[int.parse(m.group(0)!)]);


String moneyGrouped(Object? value) {
  final n = int.tryParse('${value ?? 0}') ?? 0;
  final negative = n < 0;
  final s = n.abs().toString();
  final parts = <String>[];
  for (var i = s.length; i > 0; i -= 3) {
    final start = i - 3 < 0 ? 0 : i - 3;
    parts.insert(0, s.substring(start, i));
  }
  return '${negative ? '-' : ''}${parts.join(',')}';
}

String moneyFa(Object? value) => toFa(moneyGrouped(value));


String normalizeDigits(Object? value) {
  var s = '$value';
  const fa = '۰۱۲۳۴۵۶۷۸۹';
  const ar = '٠١٢٣٤٥٦٧٨٩';
  for (var i = 0; i < 10; i++) {
    s = s.replaceAll(fa[i], '$i').replaceAll(ar[i], '$i');
  }
  return s;
}

final numberInputFormatters = <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp(r'[0-9۰-۹٠-٩+]'))];

String dateVal(int y, int m, int d) => '$y/${persianMonths[m - 1]}/$d';

String todayShamsiDate() {
  final now = DateTime.now();
  final j = gregorianToJalali(now.year, now.month, now.day);
  return dateVal(j[0], j[1], j[2]);
}


String two(int value) => value.toString().padLeft(2, '0');

DateTime? parseServerDateTime(String raw) {
  final value = raw.trim();
  if (value.isEmpty) return null;

  final isoCandidate = value.replaceFirst(' ', 'T');
  final iso = DateTime.tryParse(isoCandidate);
  if (iso != null) return iso;

  final compact = RegExp(r'^(\d{2}):(\d{2})(?::(\d{2}))?\s+(\d{1,2})-(\d{1,2})-(\d{4})$').firstMatch(value);
  if (compact != null) {
    return DateTime(
      int.parse(compact.group(6)!),
      int.parse(compact.group(5)!),
      int.parse(compact.group(4)!),
      int.parse(compact.group(1)!),
      int.parse(compact.group(2)!),
      int.tryParse(compact.group(3) ?? '0') ?? 0,
    );
  }

  final dayFirst = RegExp(r'^(\d{1,2})-(\d{1,2})-(\d{4})(?:\s+(\d{2}):(\d{2})(?::(\d{2}))?)?$').firstMatch(value);
  if (dayFirst != null) {
    return DateTime(
      int.parse(dayFirst.group(3)!),
      int.parse(dayFirst.group(2)!),
      int.parse(dayFirst.group(1)!),
      int.tryParse(dayFirst.group(4) ?? '0') ?? 0,
      int.tryParse(dayFirst.group(5) ?? '0') ?? 0,
      int.tryParse(dayFirst.group(6) ?? '0') ?? 0,
    );
  }

  final slash = RegExp(r'^(\d{4})/(\d{1,2})/(\d{1,2})(?:\s+(\d{2}):(\d{2})(?::(\d{2}))?)?$').firstMatch(value);
  if (slash != null) {
    return DateTime(
      int.parse(slash.group(1)!),
      int.parse(slash.group(2)!),
      int.parse(slash.group(3)!),
      int.tryParse(slash.group(4) ?? '0') ?? 0,
      int.tryParse(slash.group(5) ?? '0') ?? 0,
      int.tryParse(slash.group(6) ?? '0') ?? 0,
    );
  }

  return null;
}

String formatServerDateTimeShamsi(String raw, {bool includeTime = true}) {
  final dt = parseServerDateTime(raw);
  if (dt == null) return toFa(raw);
  final j = gregorianToJalali(dt.year, dt.month, dt.day);
  final date = '${j[0]}/${persianMonths[j[1] - 1]}/${j[2]}';
  if (!includeTime) return toFa(date);
  final time = '${two(dt.hour)}:${two(dt.minute)}';
  return toFa('$date - $time');
}

String asText(dynamic value, [String fallback = '']) {
  if (value == null) return fallback;
  if (value is String) return value;
  if (value is List) return value.map((e) => e?.toString() ?? '').where((e) => e.isNotEmpty).join('، ');
  if (value is Map) return jsonEncode(value);
  return value.toString();
}

List<String> asStringList(dynamic value) {
  if (value == null) return <String>[];
  if (value is List<String>) return value;
  if (value is List) return value.map((e) => e?.toString() ?? '').where((e) => e.isNotEmpty).toList();
  if (value is String && value.trim().isNotEmpty) return <String>[value];
  return <String>[];
}

List<int> gregorianToJalali(int gy, int gm, int gd) {
  final gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  var jy = gy <= 1600 ? 0 : 979;
  gy -= gy <= 1600 ? 621 : 1600;
  final gy2 = gm > 2 ? gy + 1 : gy;
  var days = 365 * gy + ((gy2 + 3) ~/ 4) - ((gy2 + 99) ~/ 100) + ((gy2 + 399) ~/ 400) - 80 + gd + gdm[gm - 1];
  jy += 33 * (days ~/ 12053);
  days %= 12053;
  jy += 4 * (days ~/ 1461);
  days %= 1461;
  if (days > 365) {
    jy += (days - 1) ~/ 365;
    days = (days - 1) % 365;
  }
  final jm = days < 186 ? 1 + (days ~/ 31) : 7 + ((days - 186) ~/ 30);
  final jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
  return [jy, jm, jd];
}

class PostSmsApp extends StatelessWidget {
  const PostSmsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'سامانه مرسولات و پیامک',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: kNavy,
          primary: kNavy,
          secondary: kNavy2,
          surface: kSurface,
          onSurface: kText,
          onPrimary: kSurface,
        ),
        scaffoldBackgroundColor: kSoftBg,
        useMaterial3: true,
        fontFamily: null,
        textTheme: ThemeData.light().textTheme.apply(bodyColor: kText, displayColor: kText),
        iconTheme: const IconThemeData(color: kNavy),
        appBarTheme: const AppBarTheme(
          centerTitle: false,
          backgroundColor: kSoftBg,
          foregroundColor: kText,
          surfaceTintColor: kSoftBg,
          elevation: 0,
        ),
        drawerTheme: const DrawerThemeData(backgroundColor: kSoftBg, surfaceTintColor: kSoftBg),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(backgroundColor: kNavy2, foregroundColor: kSurface),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            backgroundColor: kNavy,
            foregroundColor: kSurface,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          ),
        ),
        cardTheme: CardTheme(
          color: kSurface,
          elevation: 0,
          margin: const EdgeInsets.symmetric(vertical: 7),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: kBorder),
          ),
        ),
        chipTheme: ChipThemeData(
          backgroundColor: kSoftGreen,
          selectedColor: kSoftBlue,
          labelStyle: const TextStyle(color: kText, fontWeight: FontWeight.w700),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: const BorderSide(color: kBorder)),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: kSurface,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: kBorder),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: kNavy2, width: 1.8),
          ),
        ),
      ),
      builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child!),
      home: const HomePage(),
    );
  }
}

class ApiException implements Exception {
  ApiException(this.message, {this.statusCode, this.code});
  final String message;
  final int? statusCode;
  final String? code;

  bool get isAuthFailure => statusCode == 401 || code == 'auth_required' || code == 'session_invalid' || code == 'session_expired';

  @override
  String toString() => message;
}

class ApiService {
  String baseUrl = '';
  String token = '';
  final Map<String, Uint8List> _imageCache = {};
  Future<void> Function(String freshToken)? onTokenRefreshed;

  Uri uri(String path, [Map<String, String>? query]) {
    final normalized = baseUrl.trim().replaceAll(RegExp(r'/+$'), '');
    final fullPath = path.startsWith('/') ? path : '/$path';
    final parsed = Uri.parse('$normalized$fullPath');
    return query == null || query.isEmpty ? parsed : parsed.replace(queryParameters: query);
  }

  String imageUrl(String src) {
    var cleanSrc = src.trim();
    if (cleanSrc.startsWith('http://') || cleanSrc.startsWith('https://')) return cleanSrc;
    final root = baseUrl.trim().replaceAll(RegExp(r'/api/?$'), '').replaceAll(RegExp(r'/+$'), '');
    cleanSrc = cleanSrc.replaceAll('\\', '/').replaceAll('../', '').replaceAll('./', '');
    cleanSrc = cleanSrc.startsWith('/') ? cleanSrc.substring(1) : cleanSrc;
    if (cleanSrc.startsWith('post/')) cleanSrc = cleanSrc.substring(5);
    return '$root/$cleanSrc';
  }

  Future<Uint8List> imageBytes(String src) async {
    final cacheKey = src.trim();
    if (_imageCache.containsKey(cacheKey)) return _imageCache[cacheKey]!;
    var cleanSrc = cacheKey;
    final headers = authHeaders;
    late http.Response response;
    if (cleanSrc.startsWith('secure:') || cleanSrc.endsWith('.pimg') || cleanSrc.contains('private_uploads/')) {
      cleanSrc = cleanSrc.replaceFirst('secure:', '').replaceAll('private_uploads/', '');
      response = await http.get(uri('/secure_image.php', {'f': cleanSrc}), headers: headers);
    } else if (cleanSrc.startsWith('http://') || cleanSrc.startsWith('https://')) {
      response = await http.get(Uri.parse(cleanSrc), headers: headers);
    } else {
      response = await http.get(Uri.parse(imageUrl(cleanSrc)), headers: headers);
    }
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw ApiException('تصویر قابل دریافت نیست');
    }
    _imageCache[cacheKey] = response.bodyBytes;
    if (_imageCache.length > 120) _imageCache.remove(_imageCache.keys.first);
    return response.bodyBytes;
  }

  Map<String, String> get authHeaders => token.isEmpty ? {} : {'Authorization': 'Bearer $token'};

  Future<Map<String, dynamic>> login(String username, String password) async {
    final response = await http.post(
      uri('/login.php'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'username': username, 'password': password}),
    );
    return _decode(response);
  }

  Future<Map<String, dynamic>> getJson(String path, {Map<String, String>? query}) async {
    final response = await http.get(uri(path, query), headers: authHeaders);
    return _decode(response);
  }

  Future<Map<String, dynamic>> postJson(String path, Map<String, dynamic> data) async {
    final response = await http.post(
      uri(path),
      headers: {'Content-Type': 'application/json; charset=utf-8', ...authHeaders},
      body: jsonEncode(data),
    );
    return _decode(response);
  }

  Future<Map<String, dynamic>> deleteJson(String path, {Map<String, String>? query}) async {
    final response = await http.delete(uri(path, query), headers: authHeaders);
    return _decode(response);
  }

  Future<Map<String, dynamic>> saveShipment({required Map<String, String> fields, required List<PendingPhoto> photos}) async {
    // اگر عکس وجود ندارد، درخواست معمولی بفرست تا هاست‌های ضعیف روی multipart خالی قطع نشوند.
    if (photos.isEmpty) {
      final response = await http.post(
        uri('/save.php'),
        headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8', ...authHeaders},
        body: fields,
      ).timeout(const Duration(seconds: 45));
      return _decode(response);
    }

    final request = http.MultipartRequest('POST', uri('/save.php'));
    request.headers.addAll(authHeaders);
    request.fields.addAll(fields);
    for (var i = 0; i < photos.length; i++) {
      final name = photos[i].file.name.isEmpty ? 'photo_${i + 1}.jpg' : photos[i].file.name;
      request.files.add(http.MultipartFile.fromBytes('images[]', photos[i].bytes, filename: name));
    }
    final streamed = await request.send().timeout(const Duration(seconds: 75));
    final response = await http.Response.fromStream(streamed).timeout(const Duration(seconds: 75));
    return _decode(response);
  }

  void _captureRefreshedToken(http.Response response) {
    final freshToken = (response.headers['x-post-token'] ?? '').trim();
    if (freshToken.isEmpty || freshToken == token) return;
    token = freshToken;
    final callback = onTokenRefreshed;
    if (callback != null) unawaited(callback(freshToken));
  }

  Map<String, dynamic> _decode(http.Response response) {
    late Map<String, dynamic> decoded;
    try {
      decoded = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
    } catch (_) {
      final status = response.statusCode;
      if (status == 404) {
        throw ApiException('سرویس موردنظر روی سرور پیدا نشد (HTTP 404)', statusCode: status, code: 'endpoint_not_found');
      }
      if (status >= 500) {
        throw ApiException('سرور موقتاً با خطا روبه‌رو شده است (HTTP $status)', statusCode: status, code: 'server_error');
      }
      throw ApiException('پاسخ سرور معتبر نیست (HTTP $status)', statusCode: status, code: 'invalid_response');
    }
    if (decoded['ok'] != true) {
      throw ApiException(
        (decoded['error'] ?? decoded['message'] ?? 'خطای سرور').toString(),
        statusCode: response.statusCode,
        code: (decoded['code'] ?? '').toString(),
      );
    }
    _captureRefreshedToken(response);
    return decoded;
  }
}


class AppUpdateInfo {
  AppUpdateInfo({
    required this.versionCode,
    required this.versionName,
    required this.downloadUrl,
    required this.notes,
    required this.forceUpdate,
    required this.enabled,
  });

  final int versionCode;
  final String versionName;
  final String downloadUrl;
  final String notes;
  final bool forceUpdate;
  final bool enabled;

  bool get isNewer => enabled && versionCode > kAppVersionCode && downloadUrl.trim().isNotEmpty;

  factory AppUpdateInfo.fromJson(Map<String, dynamic> json) => AppUpdateInfo(
        versionCode: int.tryParse('${json['version_code'] ?? json['latest_version_code'] ?? 0}') ?? 0,
        versionName: asText(json['version_name'] ?? json['latest_version_name'], 'نسخه جدید'),
        downloadUrl: asText(json['download_url'] ?? json['apk_url'] ?? json['url']),
        notes: asText(json['notes'] ?? json['message'], 'نسخه جدید آماده نصب است.'),
        forceUpdate: '${json['force_update'] ?? json['force'] ?? '0'}' == '1' || json['force_update'] == true,
        enabled: '${json['enabled'] ?? '1'}' != '0',
      );
}

class PendingPhoto {
  PendingPhoto(this.file, this.bytes);
  final XFile file;
  final Uint8List bytes;
}

class Shipment {
  Shipment({
    required this.id,
    required this.trackingCode,
    required this.fullname,
    required this.phone,
    required this.receiverInfo,
    required this.shipmentType,
    required this.status,
    required this.shamsiDate,
    required this.description,
    required this.images,
    required this.createdBy,
    required this.updatedBy,
    required this.createdAt,
  });

  final int id;
  final String trackingCode;
  final String fullname;
  final String phone;
  final String receiverInfo;
  final String shipmentType;
  final String status;
  final String shamsiDate;
  final String description;
  final List<String> images;
  final String createdBy;
  final String updatedBy;
  final String createdAt;

  factory Shipment.fromJson(Map<String, dynamic> json) {
    final imgs = <String>[];
    final raw = json['images'];
    if (raw is List) imgs.addAll(raw.map((e) => '$e').where((e) => e.isNotEmpty));
    if (raw is String && raw.trim().isNotEmpty) {
      try {
        final dec = jsonDecode(raw);
        if (dec is List) imgs.addAll(dec.map((e) => '$e').where((e) => e.isNotEmpty));
      } catch (_) {}
    }
    final single = (json['image'] ?? '').toString();
    if (imgs.isEmpty && single.isNotEmpty) imgs.add(single);
    return Shipment(
      id: int.tryParse('${json['id']}') ?? 0,
      trackingCode: asText(json['tracking_code']),
      fullname: asText(json['fullname']),
      phone: asText(json['phone']),
      receiverInfo: asText(json['receiver_info']),
      shipmentType: asText(json['shipment_type'], 'بسته'),
      status: asText(json['status'], 'registered'),
      shamsiDate: asText(json['shamsi_date']),
      description: asText(json['description']),
      images: imgs,
      createdBy: asText(json['created_by']),
      updatedBy: asText(json['updated_by']),
      createdAt: asText(json['created_at']),
      createdBy: asText(json['created_by']),
    );
  }
}

class DashboardData {
  DashboardData({required this.total, required this.today, required this.month, required this.latest});
  final int total;
  final int today;
  final int month;
  final List<Shipment> latest;

  factory DashboardData.fromJson(Map<String, dynamic> json) {
    final latest = <Shipment>[];
    final raw = json['latest'];
    if (raw is List) {
      for (final item in raw) {
        if (item is Map) latest.add(Shipment.fromJson(Map<String, dynamic>.from(item)));
      }
    }
    return DashboardData(
      total: int.tryParse('${json['total']}') ?? 0,
      today: int.tryParse('${json['today']}') ?? 0,
      month: int.tryParse('${json['month']}') ?? 0,
      latest: latest,
    );
  }
}

class AppUser {
  AppUser({
    required this.id,
    required this.username,
    required this.role,
    required this.roleLabel,
    required this.isActive,
    required this.lastLoginAt,
    required this.permissions,
    required this.shipmentCount,
    required this.deliveredCount,
    required this.smsCount,
    required this.uniquePhoneCount,
    required this.scanCount,
    required this.subscriptionUntil,
    required this.workScope,
    required this.villageName,
    required this.scopeLabel,
    required this.failedSmsCount,
  });
  final int id;
  final String username;
  final String role;
  final String roleLabel;
  final bool isActive;
  final String lastLoginAt;
  final List<String> permissions;
  final int shipmentCount;
  final int deliveredCount;
  final int smsCount;
  final int uniquePhoneCount;
  final int scanCount;
  final String subscriptionUntil;
  final String workScope;
  final String villageName;
  final String scopeLabel;
  final int failedSmsCount;

  bool can(String permission) => role == 'admin' || permissions.contains(permission);

  factory AppUser.fromJson(Map<String, dynamic> json) => AppUser(
        id: int.tryParse('${json['id']}') ?? 0,
        username: asText(json['username']),
        role: asText(json['role'], 'user'),
        roleLabel: asText(json['role_label'] ?? json['role'], 'کاربر'),
        isActive: '${json['is_active']}' == '1' || json['is_active'] == true,
        lastLoginAt: asText(json['last_login_at'], '-'),
        permissions: asStringList(json['permissions']),
        shipmentCount: int.tryParse('${json['shipment_count'] ?? 0}') ?? 0,
        deliveredCount: int.tryParse('${json['delivered_count'] ?? 0}') ?? 0,
        smsCount: int.tryParse('${json['sms_count'] ?? 0}') ?? 0,
        uniquePhoneCount: int.tryParse('${json['unique_phone_count'] ?? 0}') ?? 0,
        scanCount: int.tryParse('${json['scan_count'] ?? 0}') ?? 0,
        subscriptionUntil: asText(json['subscription_until']),
        workScope: asText(json['work_scope'], 'main'),
        villageName: asText(json['village_name']),
        scopeLabel: asText(json['scope_label'], asText(json['work_scope']) == 'village' ? 'روستا' : 'شهرستان اصلی'),
        failedSmsCount: int.tryParse('${json['failed_sms_count'] ?? 0}') ?? 0,
      );
}


bool smsMessageIsFailed(SmsMessage m) {
  final level = m.deliveryLevel.trim().toLowerCase();
  if (level == 'device_sent' || level == 'panel_resent' || level == 'delivered' || level == 'manual_success') return false;
  return !m.sendOk || level == 'failed';
}

String normalizedSmsDeliveryLevel({required String service, required String recId, required bool sendOk, required String deliveryLevel, required String deliveryText}) {
  return deliveryLevel.trim().isEmpty ? 'unknown' : deliveryLevel.trim();
}

String normalizedSmsDeliveryText({required String service, required String recId, required bool sendOk, required String deliveryText}) {
  return deliveryText;
}

class SmsGroup {
  SmsGroup({required this.id, required this.title, required this.messages});
  final String id;
  final String title;
  final List<SmsMessage> messages;
  String get text => messages.isEmpty ? '' : messages.first.text;
  String get service => messages.isEmpty ? '' : messages.first.service;
  String get createdAt => messages.isEmpty ? '' : messages.first.createdAt;
  int get successCount => messages.where((m) => m.sendOk).length;
  int get failedCount => messages.where((m) => smsMessageIsFailed(m)).length;
  int get deliveredCount => messages.where((m) => m.deliveryLevel == 'delivered').length;
  int get deviceSentCount => messages.where((m) => m.deliveryLevel == 'device_sent').length;
  int get pendingCount => messages.length - deliveredCount - failedCount - deviceSentCount;
}

class AppLog {
  AppLog({required this.createdAt, required this.username, required this.action, required this.entity, required this.ip, required this.details});
  final String createdAt;
  final String username;
  final String action;
  final String entity;
  final String ip;
  final String details;

  factory AppLog.fromJson(Map<String, dynamic> json) => AppLog(
        createdAt: asText(json['created_at']),
        username: (json['username'] ?? '-').toString(),
        action: (json['action'] ?? '-').toString(),
        entity: '${json['entity'] ?? '-'} #${json['entity_id'] ?? ''}',
        ip: (json['ip_address'] ?? '-').toString(),
        details: (json['details'] ?? '-').toString(),
      );
}

class SmsStats {
  SmsStats({required this.total, required this.today, required this.month, required this.delivered, required this.failed, required this.waiting, required this.ownFailed});
  final int total;
  final int today;
  final int month;
  final int delivered;
  final int failed;
  final int waiting;
  final int ownFailed;
  factory SmsStats.fromJson(Map<String, dynamic> json) => SmsStats(
        total: int.tryParse('${json['total']}') ?? 0,
        today: int.tryParse('${json['today']}') ?? 0,
        month: int.tryParse('${json['month']}') ?? 0,
        delivered: int.tryParse('${json['delivered']}') ?? 0,
        failed: int.tryParse('${json['failed']}') ?? 0,
        waiting: int.tryParse('${json['waiting']}') ?? 0,
        ownFailed: int.tryParse('${json['own_failed'] ?? 0}') ?? 0,
      );
}

class SmsMessage {
  SmsMessage({
    required this.id,
    required this.groupId,
    required this.groupTitle,
    required this.receiver,
    required this.fullName,
    required this.sender,
    required this.text,
    required this.service,
    required this.recId,
    required this.sendOk,
    required this.sendStatus,
    required this.deliveryText,
    required this.deliveryLevel,
    required this.createdAt,
    required this.createdBy,
  });
  final int id;
  final String groupId;
  final String groupTitle;
  final String receiver;
  final String fullName;
  final String sender;
  final String text;
  final String service;
  final String recId;
  final bool sendOk;
  final String sendStatus;
  final String deliveryText;
  final String deliveryLevel;
  final String createdAt;
  final String createdBy;

  factory SmsMessage.fromJson(Map<String, dynamic> json) {
    final service = asText(json['service'], 'smsir');
    final recId = asText(json['rec_id']);
    final sendOk = '${json['send_ok']}' == '1' || json['send_ok'] == true;
    final rawDeliveryText = asText(json['delivery_text']);
    final rawDeliveryLevel = asText(json['delivery_level'], 'unknown');
    final fixedDeliveryLevel = normalizedSmsDeliveryLevel(
      service: service,
      recId: recId,
      sendOk: sendOk,
      deliveryLevel: rawDeliveryLevel,
      deliveryText: rawDeliveryText,
    );
    final fixedDeliveryText = normalizedSmsDeliveryText(
      service: service,
      recId: recId,
      sendOk: sendOk,
      deliveryText: rawDeliveryText,
    );
    return SmsMessage(
      id: int.tryParse('${json['id']}') ?? 0,
      groupId: asText(json['group_id']),
      groupTitle: asText(json['group_title']),
      receiver: asText(json['receiver']),
      fullName: asText(json['full_name']),
      sender: asText(json['sender']),
      text: asText(json['text']),
      service: service,
      recId: recId,
      sendOk: sendOk,
      sendStatus: asText(json['send_status']),
      deliveryText: fixedDeliveryText,
      deliveryLevel: fixedDeliveryLevel,
      createdAt: asText(json['created_at']),
    );
  }
}

class SmsContact {
  SmsContact({required this.number, required this.name, required this.count});
  final String number;
  final String name;
  final int count;
  factory SmsContact.fromJson(Map<String, dynamic> json) => SmsContact(
        number: asText(json['number']),
        name: asText(json['name']),
        count: int.tryParse('${json['count']}') ?? 0,
      );
}


class SmsTemplate {
  SmsTemplate({required this.id, required this.keyword, required this.text, required this.createdBy});
  final int id;
  final String keyword;
  final String text;
  final String createdBy;

  factory SmsTemplate.fromJson(Map<String, dynamic> json) => SmsTemplate(
        id: int.tryParse('${json['id']}') ?? 0,
        keyword: asText(json['keyword']),
        text: asText(json['text']),
        createdBy: asText(json['created_by']),
      );
}



class SmsInboxMessage {
  SmsInboxMessage({
    required this.id,
    required this.service,
    required this.sender,
    required this.receiver,
    required this.text,
    required this.providerMessageId,
    required this.receivedAt,
    required this.createdAt,
  });

  final int id;
  final String service;
  final String sender;
  final String receiver;
  final String text;
  final String providerMessageId;
  final String receivedAt;
  final String createdAt;

  factory SmsInboxMessage.fromJson(Map<String, dynamic> json) => SmsInboxMessage(
        id: int.tryParse('${json['id']}') ?? 0,
        service: asText(json['service'], 'unknown'),
        sender: asText(json['sender']),
        receiver: asText(json['receiver']),
        text: asText(json['text']),
        providerMessageId: asText(json['provider_message_id']),
        receivedAt: asText(json['received_at']),
        createdAt: asText(json['created_at']),
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final api = ApiService();
  final picker = ImagePicker();
  final offlineStore = OfflineStore();
  StreamSubscription<List<ConnectivityResult>>? connectivitySubscription;

  final apiController = TextEditingController(text: kDefaultApiBase);
  final loginUserController = TextEditingController(text: 'admin');
  final loginPassController = TextEditingController();
  final searchController = TextEditingController();
  final fullnameController = TextEditingController();
  final phoneController = TextEditingController();
  final receiverController = TextEditingController();
  final newUserController = TextEditingController();
  final newPassController = TextEditingController();
  final userIdController = TextEditingController();
  final villageNameController = TextEditingController();
  final smsSenderController = TextEditingController(text: '50002710080704');
  final smsNumbersController = TextEditingController();
  final smsTextController = TextEditingController();
  final smsGroupController = TextEditingController();
  final smsKeywordController = TextEditingController();
  final smsNumberLineController = TextEditingController();
  final smsNameLineController = TextEditingController();
  final smsTemplateIdController = TextEditingController();
  final smsTemplateKeywordController = TextEditingController();
  final smsTemplateTextController = TextEditingController();
  final smsSearchController = TextEditingController();
  final smsInboxSearchController = TextEditingController();
  final logUserController = TextEditingController();
  final smsNumberLineFocus = FocusNode();
  final smsNameLineFocus = FocusNode();

  TextEditingController? activeNumberPadController;
  String activeNumberPadTitle = 'شماره';
  String activeNumberPadDoneLabel = 'بعدی';
  VoidCallback? activeNumberPadOnDone;

  bool loggedIn = false;
  bool loading = false;
  bool saving = false;
  bool sendingSms = false;
  bool bulkSendingSms = false;
  bool savingSmsTemplate = false;
  bool loadingSmsMessages = false;
  bool loadingSmsInbox = false;
  bool rememberMe = true;
  String username = '';
  String role = '';
  String roleLabel = '';
  String workScope = 'main';
  String villageName = '';
  List<String> permissions = [];

  int pageIndex = 0;
  String shipmentType = shipmentTypes.first;
  int jy = 1405, jm = 1, jd = 1;
  int ry = 1405, rm = 1, rd = 1;
  int reportTypeIndex = 0;
  int? editingShipmentId;
  bool newUserActive = true;
  String newUserWorkScope = 'main';
  bool permSmsSend = false;
  bool permSmsView = false;
  bool permShipmentCreate = true;
  bool permShipmentView = true;
  bool permShipmentDeliver = true;
  bool permShipmentScan = true;
  String smsService = 'melli';
  String smsirSender = '30002108020400';
  String melliSender = '50002710080704';
  bool shipmentTodayOnly = true;
  bool smsTodayOnly = true;
  bool smsFailedOnly = false;
  bool sessionResetting = false;
  String logAction = '';
  String logEntity = '';

  DashboardData? dashboard;
  SmsStats? smsStats;
  List<Shipment> shipments = [];
  List<PendingPhoto> selectedPhotos = [];
  List<AppUser> users = [];
  List<AppLog> logs = [];
  List<SmsMessage> smsMessages = [];
  List<SmsMessage> dashboardFailedMessages = [];
  List<SmsContact> smsContacts = [];
  List<SmsTemplate> smsTemplates = [];
  List<SmsInboxMessage> smsInboxMessages = [];
  final Set<int> smsLocallyResolvedIds = <int>{};
  final Map<String, String> smsKnownNamesByPhone = <String, String>{};
  final Set<String> smsNameLookupTried = <String>{};
  Timer? searchDebounce;
  Timer? smsNameLookupDebounce;
  int _smsSearchSerial = 0;
  bool autoCheckingDelivery = false;
  DateTime? lastAutoDeliveryCheck;
  AppUpdateInfo? availableUpdate;
  bool updateDialogOpen = false;
  bool offlineReady = false;
  bool networkAvailable = true;
  bool syncingOffline = false;
  int pendingSyncCount = 0;
  bool adminMode = false;
  int adminPageIndex = 0;
  int versionTapCount = 0;
  bool bankListenerStarted = false;
  bool subscriptionLoading = false;
  Map<String, dynamic> subscriptionData = {};
  Map<String, dynamic> adminStats = {};
  Map<String, dynamic> paymentSettings = {};
  List<Map<String, dynamic>> adminPayments = [];
  List<Map<String, dynamic>> bankSmsEvents = [];
  List<ScannedShipmentDraft> scanDrafts = [];
  Timer? subscriptionPollTimer;

  bool has(String permission) => role == 'admin' || permissions.contains(permission);
  bool get canAdmin => role == 'admin';
  bool get hasActiveSubscription => canAdmin || subscriptionData['active'] == true;

  bool requireActiveSubscriptionUi() {
    if (hasActiveSubscription) return true;
    showSnack('برای این عملیات اشتراک فعال لازم است');
    if (mounted) setState(() => pageIndex = 11);
    return false;
  }

  String senderForSmsService(String service) => service == 'smsir' ? smsirSender : melliSender;

  void applySmsService(String service) {
    smsService = service == 'smsir' ? 'smsir' : 'melli';
    smsSenderController.text = senderForSmsService(smsService);
  }

  bool _networkFromResults(List<ConnectivityResult> values) => values.any((value) => value != ConnectivityResult.none);

  Future<bool> _hasNetworkConnection() async {
    try {
      final values = await Connectivity().checkConnectivity();
      return _networkFromResults(values);
    } catch (_) {
      return networkAvailable;
    }
  }

  String _operationId(String type) => '$type-${DateTime.now().microsecondsSinceEpoch}-${Random.secure().nextInt(1 << 31)}';

  bool _shouldQueueError(Object error) {
    if (error is ApiException) {
      final code = error.statusCode;
      return code == null || code == 408 || code == 429 || code >= 500;
    }
    return error is SocketException || error is TimeoutException || error.toString().contains('ClientException');
  }

  Future<void> _initializeOfflineStore() async {
    try {
      await offlineStore.init();
      final values = await Connectivity().checkConnectivity();
      if (!mounted) return;
      setState(() {
        offlineReady = true;
        networkAvailable = _networkFromResults(values);
      });
      connectivitySubscription = Connectivity().onConnectivityChanged.listen((values) {
        final connected = _networkFromResults(values);
        if (mounted) setState(() => networkAvailable = connected);
        if (connected) unawaited(_syncOfflineQueue());
      });
      if (loggedIn) {
        await _refreshPendingSyncCount();
        if (networkAvailable) unawaited(_syncOfflineQueue());
      }
    } catch (_) {
      // نبود فضای محلی یا سرویس اتصال نباید ورود به برنامه را متوقف کند.
    }
  }

  Future<void> _refreshPendingSyncCount() async {
    if (!offlineReady || username.trim().isEmpty) return;
    final count = await offlineStore.pendingCount(username);
    if (mounted) setState(() => pendingSyncCount = count);
  }

  Future<void> _runOfflineOperation(OfflineOperation operation) async {
    if (operation.type == 'shipment_save') {
      final fields = operation.payload.map((key, value) => MapEntry(key, value?.toString() ?? ''));
      final photos = <PendingPhoto>[];
      for (final queued in operation.photos) {
        final file = File(queued.path);
        if (!await file.exists()) continue;
        final bytes = await offlineStore.readQueuedPhotoBytes(queued);
        if (bytes.isEmpty) continue;
        photos.add(PendingPhoto(XFile(queued.filename), bytes));
      }
      await api.saveShipment(fields: fields, photos: photos);
      return;
    }
    if (operation.type == 'sms_send') {
      await api.postJson('/sms_send.php', Map<String, dynamic>.from(operation.payload));
      return;
    }
    if (operation.type == 'shipment_status') {
      await api.postJson('/change_status.php', Map<String, dynamic>.from(operation.payload));
      return;
    }
    if (operation.type == 'sms_device_sent') {
      await api.postJson('/sms_mark_device_sent.php', Map<String, dynamic>.from(operation.payload));
      return;
    }
    throw StateError('نوع عملیات آفلاین ناشناخته است');
  }

  Future<void> _syncOfflineQueue({bool manual = false}) async {
    if (!offlineReady || !loggedIn || username.trim().isEmpty || syncingOffline) return;
    if (!await _hasNetworkConnection()) {
      if (manual) showSnack('اینترنت برای همگام‌سازی در دسترس نیست');
      return;
    }
    if (mounted) setState(() => syncingOffline = true);
    try {
      final report = await offlineStore.process(owner: username, execute: _runOfflineOperation, maxItems: 2, gap: const Duration(seconds: 2));
      if (!mounted) return;
      setState(() => pendingSyncCount = report.remaining);
      if (report.completed > 0) {
        if (has('shipment.view')) unawaited(loadShipments());
        if (has('sms.view')) {
          unawaited(loadSmsMessages(autoCheck: false));
          unawaited(loadSmsDashboard(silent: true));
        }
        unawaited(loadDashboard());
      }
      if (report.remaining > 0) {
        // عملیات‌ها دانه‌دانه و با فاصله تکرار می‌شوند؛ بعد از خطا هم زمان backoff رعایت می‌شود.
        final delay = report.retried > 0 ? const Duration(seconds: 22) : const Duration(seconds: 3);
        Future<void>.delayed(delay, () => _syncOfflineQueue());
      }
      if (manual) {
        if (report.completed > 0) showSnack('${toFa(report.completed)} عملیات به‌آرامی همگام‌سازی شد');
        else if (report.remaining > 0) showSnack('صف همگام‌سازی آماده است؛ عملیات بعدی با فاصله انجام می‌شود');
        else showSnack('صف آفلاین خالی است');
      }
    } catch (e) {
      if (manual) showSnack('همگام‌سازی انجام نشد: $e');
    } finally {
      if (mounted) setState(() => syncingOffline = false);
    }
  }

  Future<void> _enqueueSmsPayload(Map<String, dynamic> payload) async {
    final operationId = (payload['client_operation_id'] ?? '').toString();
    await offlineStore.enqueue(owner: username, type: 'sms_send', operationId: operationId, payload: payload);
    await _refreshPendingSyncCount();
  }

  Future<Map<String, dynamic>?> _sendSmsOrQueue(Map<String, dynamic> payload) async {
    if (!requireActiveSubscriptionUi()) throw StateError('اشتراک فعال لازم است');
    final operationId = (payload['client_operation_id'] ?? '').toString();
    if (operationId.isEmpty) payload['client_operation_id'] = _operationId('sms');
    if (!await _hasNetworkConnection()) {
      await _enqueueSmsPayload(payload);
      return null;
    }
    try {
      return await api.postJson('/sms_send.php', payload);
    } catch (error) {
      if (!_shouldQueueError(error)) rethrow;
      await _enqueueSmsPayload(payload);
      return null;
    }
  }

  Future<void> loadSmsConfig({bool silent = true}) async {
    try {
      final result = await api.getJson('/health.php');
      final data = result['data'] is Map ? Map<String, dynamic>.from(result['data'] as Map) : result;
      final newSmsir = asText(data['smsir_sender'], smsirSender);
      final newMelli = asText(data['melli_sender'], melliSender);
      if (!mounted) return;
      setState(() {
        smsirSender = newSmsir.isNotEmpty ? newSmsir : smsirSender;
        melliSender = newMelli.isNotEmpty ? newMelli : melliSender;
        final current = smsSenderController.text.trim();
        if (current.isEmpty || current == '30002108020400' || current == '50002710080704') {
          smsSenderController.text = senderForSmsService(smsService);
        }
      });
    } catch (e) {
      if (!silent) showSnack('تنظیمات پیامک دریافت نشد: $e');
    }
  }

  int firstAllowedPage() {
    if (has('shipment.create')) return 0;
    if (has('shipment.view')) return 1;
    if (has('sms.send')) return 2;
    if (has('sms.view')) return 3;
    if (has('dashboard.view')) return 5;
    if (has('user.view')) return 7;
    return 0;
  }

  @override
  void initState() {
    super.initState();
    api.onTokenRefreshed = (freshToken) async {
      await secureStore.write(key: 'post_token', value: freshToken);
    };
    _setToday();
    unawaited(_initializeOfflineStore());
    _restoreSession();
  }

  @override
  void dispose() {
    connectivitySubscription?.cancel();
    searchDebounce?.cancel();
    smsNameLookupDebounce?.cancel();
    subscriptionPollTimer?.cancel();
    for (final c in [
      apiController, loginUserController, loginPassController, searchController, fullnameController,
      phoneController, receiverController, newUserController, newPassController, userIdController,
      smsSenderController, smsNumbersController, smsTextController, smsGroupController, smsKeywordController,
      smsNumberLineController, smsNameLineController, smsTemplateIdController, smsTemplateKeywordController,
      smsTemplateTextController, smsSearchController, smsInboxSearchController, logUserController,
    ]) {
      c.dispose();
    }
    smsNumberLineFocus.dispose();
    smsNameLineFocus.dispose();
    super.dispose();
  }

  void _setToday() {
    final now = DateTime.now();
    final j = gregorianToJalali(now.year, now.month, now.day);
    jy = ry = j[0];
    jm = rm = j[1];
    jd = rd = j[2];
  }

  Future<void> _restoreSession() async {
    final prefs = await SharedPreferences.getInstance();
    apiController.text = asText(prefs.get('post_api_base'), kDefaultApiBase);
    rememberMe = prefs.get('post_remember_me') is bool ? prefs.getBool('post_remember_me') ?? true : true;
    final savedUser = (await secureStore.read(key: 'post_saved_user')) ?? asText(prefs.get('post_user'));
    final savedPass = (await secureStore.read(key: 'post_saved_pass')) ?? '';
    if (savedUser.isNotEmpty) loginUserController.text = savedUser;
    if (rememberMe && savedPass.isNotEmpty) loginPassController.text = savedPass;
    // پاک‌سازی داده‌های حساس نسخه‌های قدیمی که داخل SharedPreferences ذخیره می‌شدند.
    await prefs.remove('post_token');
    await prefs.remove('post_saved_pass');
    await prefs.remove('post_saved_user');

    final token = (await secureStore.read(key: 'post_token')) ?? '';
    if (token.isNotEmpty) {
      api.baseUrl = apiController.text.trim();
      api.token = token;
      username = asText(prefs.get('post_user'));
      role = asText(prefs.get('post_role'));
      roleLabel = asText(prefs.get('post_role_label'), role);
      workScope = asText(prefs.get('post_work_scope'), 'main');
      villageName = asText(prefs.get('post_village_name'));
      permissions = asStringList(prefs.get('post_permissions'));
      setState(() {
        loggedIn = true;
        pageIndex = firstAllowedPage();
      });
      await boot();
      unawaited(checkForAppUpdate());
      return;
    }

    if (rememberMe && savedUser.isNotEmpty && savedPass.isNotEmpty) {
      await Future<void>.delayed(const Duration(milliseconds: 250));
      if (mounted && !loggedIn) await login(silent: true);
    }
  }

  Future<void> _purgeLegacySmsPreferences(SharedPreferences prefs) async {
    for (final key in legacySmsPreferenceKeys) {
      await prefs.remove(key);
    }
  }

  Future<void> login({bool silent = false}) async {
    final base = (apiController.text.trim().isEmpty ? kDefaultApiBase : apiController.text.trim()).replaceAll(RegExp(r'/+$'), '');
    setState(() => loading = true);
    try {
      api.baseUrl = base;
      final result = await api.login(loginUserController.text.trim(), loginPassController.text);
      api.token = asText(result['token']);
      username = asText(result['username']);
      role = asText(result['role']);
      roleLabel = asText(result['role_label'], role);
      workScope = asText(result['work_scope'], 'main');
      villageName = asText(result['village_name']);
      permissions = asStringList(result['permissions']);
      final prefs = await SharedPreferences.getInstance();
      final previousLocalOwner = asText(prefs.get('post_user'));
      if (previousLocalOwner.isNotEmpty && previousLocalOwner != username) {
        // داده‌های Legacy قبل از چندکاربره شدن Owner نداشتند؛ روی تغییر حساب
        // به‌جای نسبت‌دادن اشتباه به کاربر جدید، کاملاً پاک می‌شوند.
        await _purgeLegacySmsPreferences(prefs);
      }
      await prefs.setString('post_api_base', base);
      await secureStore.write(key: 'post_token', value: api.token);
      await secureStore.write(key: 'post_api_base_secure', value: base);
      await prefs.setString('post_user', username);
      await prefs.setString('post_role', role);
      await prefs.setString('post_role_label', roleLabel);
      await prefs.setString('post_work_scope', workScope);
      await prefs.setString('post_village_name', villageName);
      await prefs.setStringList('post_permissions', permissions);
      await prefs.setBool('post_remember_me', rememberMe);
      if (rememberMe) {
        await secureStore.write(key: 'post_saved_user', value: loginUserController.text.trim());
        await secureStore.write(key: 'post_saved_pass', value: loginPassController.text);
      } else {
        await secureStore.delete(key: 'post_saved_user');
        await secureStore.delete(key: 'post_saved_pass');
      }
      setState(() {
        loggedIn = true;
        pageIndex = firstAllowedPage();
      });
      await boot();
      unawaited(checkForAppUpdate());
      if (!silent) showSnack('ورود موفق بود');
    } catch (e) {
      showSnack(e.toString());
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await secureStore.delete(key: 'post_token');
    await prefs.remove('post_user');
    await prefs.remove('post_role');
    await prefs.remove('post_role_label');
    await prefs.remove('post_work_scope');
    await prefs.remove('post_village_name');
    await prefs.remove('post_permissions');
    await _purgeLegacySmsPreferences(prefs);
    api.token = '';
    setState(() {
      loggedIn = false;
      dashboard = null;
      smsStats = null;
      shipments.clear();
      users.clear();
      logs.clear();
      smsMessages.clear();
      smsContacts.clear();
      smsTemplates.clear();
      smsInboxMessages.clear();
      adminMode = false;
      adminPageIndex = 0;
      versionTapCount = 0;
      subscriptionData = {};
    });
  }


  Future<void> requestLogout() async {
    if (await confirm('از حساب خارج شوید؟') != true) return;
    await logout();
  }

  Future<bool> onBackPressed() async {
    if (!loggedIn) return true;
    final first = firstAllowedPage();
    if (pageIndex != first) {
      setState(() => pageIndex = first);
      return false;
    }
    final ok = await confirm('از برنامه خارج شوید؟') == true;
    return ok;
  }

  Future<bool> handleSessionFailure(Object error) async {
    if (error is! ApiException || !error.isAuthFailure) return false;
    if (sessionResetting) return true;
    sessionResetting = true;
    try {
      await logout();
      if (mounted) showSnack('نشست شما منقضی یا نامعتبر شده است. دوباره وارد شوید.');
    } finally {
      sessionResetting = false;
    }
    return true;
  }

  Future<void> boot() async {
    try {
      await loadSubscription();
      if (!canAdmin && subscriptionData['active'] != true && mounted) setState(() => pageIndex = 11);
      if (has('sms.send')) { await loadSmsConfig(); await loadSmsTemplates(silent: true); }
      if (canAdmin) unawaited(startBankListenerIfConfigured());
      final tasks = <Future<void>>[];
      if (has('dashboard.view')) tasks.add(loadDashboard());
      if (has('sms.view')) tasks.add(loadSmsDashboard(silent: true));
      if (pageIndex == 1 && has('shipment.view')) tasks.add(loadShipments());
      if (pageIndex == 3 && has('sms.view')) tasks.add(loadSmsMessages(autoCheck: false));
      if (pageIndex == 10 && has('sms.view')) tasks.add(loadSmsInbox());
      if (tasks.isNotEmpty) await Future.wait(tasks);
      if (has('sms.send')) unawaited(syncOldLocalSmsMessages());
      await _refreshPendingSyncCount();
      unawaited(_syncOfflineQueue());
    } catch (e) {
      showSnack(e.toString());
    }
  }


  Future<void> checkForAppUpdate({bool manual = false}) async {
    try {
      if (api.baseUrl.trim().isEmpty) api.baseUrl = kDefaultApiBase;
      final result = await api.getJson('/app_update.php', query: {
        'platform': 'android',
        'current_code': '$kAppVersionCode',
        'current_version': kAppVersionName,
      });
      final raw = result['data'] is Map ? Map<String, dynamic>.from(result['data'] as Map) : Map<String, dynamic>.from(result);
      final info = AppUpdateInfo.fromJson(raw);
      if (!mounted) return;
      setState(() => availableUpdate = info.isNewer ? info : null);
      if (info.isNewer) {
        final prefs = await SharedPreferences.getInstance();
        final dismissedCode = prefs.getInt('post_dismissed_update_code') ?? 0;
        if (manual || info.forceUpdate || dismissedCode != info.versionCode) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) showUpdateDialog(info);
          });
        }
      } else if (manual) {
        showSnack('نسخه برنامه به‌روز است');
      }
    } catch (e) {
      if (manual) showSnack('بررسی آپدیت انجام نشد: $e');
    }
  }

  Future<void> showUpdateDialog(AppUpdateInfo info) async {
    if (updateDialogOpen || !mounted) return;
    updateDialogOpen = true;
    try {
      await showDialog<void>(
        context: context,
        barrierDismissible: !info.forceUpdate,
        builder: (context) => WillPopScope(
          onWillPop: () async => !info.forceUpdate,
          child: AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
            title: Row(children: const [
              Icon(Icons.system_update_alt, color: kNavy),
              SizedBox(width: 8),
              Expanded(child: Text('نسخه جدید آماده است')),
            ]),
            content: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: kSoftMint,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: kBorder),
              ),
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('نسخه فعلی: $kAppVersionName', style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                Text('نسخه جدید: ${info.versionName}', style: const TextStyle(fontWeight: FontWeight.w900, color: kNavy)),
                const SizedBox(height: 10),
                Text(info.notes, style: const TextStyle(height: 1.6)),
                const SizedBox(height: 10),
                const Text('فایل جدید را روی همین برنامه نصب کن؛ نیازی به حذف نسخه قبلی نیست.', style: TextStyle(fontWeight: FontWeight.w700)),
              ]),
            ),
            actions: [
              if (!info.forceUpdate)
                TextButton(
                  onPressed: () async {
                    final prefs = await SharedPreferences.getInstance();
                    await prefs.setInt('post_dismissed_update_code', info.versionCode);
                    if (context.mounted) Navigator.pop(context);
                  },
                  child: const Text('بعداً'),
                ),
              FilledButton.icon(
                onPressed: () async {
                  final uri = Uri.tryParse(info.downloadUrl);
                  if (uri == null) {
                    showSnack('لینک آپدیت معتبر نیست');
                    return;
                  }
                  final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
                  if (!opened) showSnack('لینک دانلود باز نشد');
                  if (!info.forceUpdate && context.mounted) Navigator.pop(context);
                },
                icon: const Icon(Icons.download),
                label: const Text('دانلود و نصب'),
              ),
            ],
          ),
        ),
      );
    } finally {
      updateDialogOpen = false;
    }
  }

  Future<void> loadDashboard({bool silent = true}) async {
    if (!has('dashboard.view')) return;
    try {
      final result = await api.getJson('/dashboard.php', query: adminMode ? null : {'mine': '1'}).timeout(const Duration(seconds: 12));
      if (!mounted) return;
      setState(() => dashboard = DashboardData.fromJson(Map<String, dynamic>.from(result['data'])));
    } catch (e) {
      if (!silent && mounted) showSnack('داشبورد موقتاً بارگذاری نشد');
    }
  }

  Future<void> loadSmsDashboard({bool silent = false}) async {
    if (!has('sms.view')) return;
    try {
      final result = await api.getJson('/sms_dashboard.php', query: adminMode ? null : {'mine': '1'});
      final data = Map<String, dynamic>.from(result['data'] as Map);
      final failedRaw = data['own_failed_messages'] as List? ?? const [];
      setState(() {
        smsStats = SmsStats.fromJson(data);
        dashboardFailedMessages = failedRaw
            .whereType<Map>()
            .map((e) => SmsMessage.fromJson(Map<String, dynamic>.from(e)))
            .toList();
      });
    } catch (e) {
      if (!silent) showSnack(e.toString());
    }
  }

  int _shipmentSearchSerial = 0;

  Future<void> loadShipments({bool? todayOnly}) async {
    if (!has('shipment.view')) return;
    final requestSerial = ++_shipmentSearchSerial;
    final useTodayOnly = todayOnly ?? shipmentTodayOnly;
    final query = <String, String>{};
    if (!adminMode) query['mine'] = '1';
    final q = searchController.text.trim();
    final cacheKey = 'shipments:$username:${adminMode ? 'admin' : 'mine'}:${useTodayOnly ? 'today' : 'all'}';

    if (q.isNotEmpty) {
      query['q'] = q;
      query['limit'] = '120';
    } else {
      if (useTodayOnly) query['today'] = '1';
      query['limit'] = '120';
    }

    try {
      final result = await api.getJson('/shipments.php', query: query).timeout(const Duration(seconds: 15));
      if (!mounted || requestSerial != _shipmentSearchSerial) return;
      final data = result['data'] as List? ?? [];
      if (q.isEmpty && offlineReady) unawaited(offlineStore.writeCache(cacheKey, data));
      setState(() => shipments = data.map((e) => Shipment.fromJson(Map<String, dynamic>.from(e as Map))).toList());
    } catch (e) {
      if (!mounted || requestSerial != _shipmentSearchSerial) return;
      if (await handleSessionFailure(e)) return;
      final cached = q.isEmpty && offlineReady ? await offlineStore.readCache(cacheKey) : null;
      if (cached is List) {
        setState(() => shipments = cached.whereType<Map>().map((e) => Shipment.fromJson(Map<String, dynamic>.from(e))).toList());
        showSnack('اینترنت در دسترس نیست؛ نسخه ذخیره‌شده مرسولات نمایش داده شد');
      } else {
        showSnack('دریافت مرسولات انجام نشد: $e');
      }
    }
  }

  Future<void> loadUsers() async {
    if (!has('user.view')) return;
    final result = await api.getJson('/users.php');
    final data = result['data'] as List? ?? [];
    setState(() => users = data.map((e) => AppUser.fromJson(Map<String, dynamic>.from(e as Map))).toList());
  }

  Future<void> loadLogs() async {
    if (!has('log.view')) return;
    final query = <String, String>{};
    if (logUserController.text.trim().isNotEmpty) query['username'] = logUserController.text.trim();
    if (logAction.isNotEmpty) query['action'] = logAction;
    if (logEntity.isNotEmpty) query['entity'] = logEntity;
    final result = await api.getJson('/logs.php', query: query);
    final data = result['data'] as List? ?? [];
    setState(() => logs = data.map((e) => AppLog.fromJson(Map<String, dynamic>.from(e as Map))).toList());
  }

  Future<void> loadSmsMessages({bool autoCheck = true}) async {
    if (!has('sms.view')) return;
    final requestSerial = ++_smsSearchSerial;
    final query = <String, String>{};
    if (!adminMode) query['mine'] = '1';
    final smsQ = smsSearchController.text.trim();
    final hasSearch = smsQ.isNotEmpty;
    final cacheKey = 'sms_messages:$username:${adminMode ? 'admin' : 'mine'}:${smsFailedOnly ? 'failed' : (smsTodayOnly ? 'today' : 'all')}';
    if (smsFailedOnly) {
      query['failed'] = '1';
      query['limit'] = hasSearch ? '80' : '120';
    }
    if (hasSearch) {
      query['q'] = smsQ;
      query['limit'] = smsFailedOnly ? '80' : '60';
    } else if (!smsFailedOnly) {
      if (smsTodayOnly) query['today'] = '1';
      query['limit'] = '90';
    }
    if (mounted) setState(() => loadingSmsMessages = true);
    try {
      final result = await api.getJson('/sms_messages.php', query: query).timeout(const Duration(seconds: 10));
      if (!mounted || requestSerial != _smsSearchSerial) return;
      final data = result['data'] as List? ?? [];
      if (!hasSearch && offlineReady) unawaited(offlineStore.writeCache(cacheKey, data));
      final loaded = data
          .map((e) => SmsMessage.fromJson(Map<String, dynamic>.from(e as Map)))
          .where((m) => !smsLocallyResolvedIds.contains(m.id))
          .where((m) => !smsFailedOnly || smsMessageIsFailed(m))
          .toList();
      setState(() => smsMessages = loaded);
      if (autoCheck && !hasSearch) unawaited(autoUpdatePendingDeliveries());
    } catch (e) {
      if (!mounted || requestSerial != _smsSearchSerial) return;
      if (await handleSessionFailure(e)) return;
      final cached = !hasSearch && offlineReady ? await offlineStore.readCache(cacheKey) : null;
      if (cached is List) {
        final loaded = cached
            .whereType<Map>()
            .map((e) => SmsMessage.fromJson(Map<String, dynamic>.from(e)))
            .where((m) => !smsLocallyResolvedIds.contains(m.id))
            .where((m) => !smsFailedOnly || smsMessageIsFailed(m))
            .toList();
        setState(() => smsMessages = loaded);
        showSnack('اینترنت در دسترس نیست؛ نسخه ذخیره‌شده پیام‌ها نمایش داده شد');
      } else {
        showSnack('دریافت پیام‌های ثبت‌شده انجام نشد: $e');
      }
    } finally {
      if (mounted && requestSerial == _smsSearchSerial) setState(() => loadingSmsMessages = false);
    }
  }

  Future<void> loadSmsContacts() async {
    if (!canAdmin) return;
    final cacheKey = 'sms_contacts:admin:$username';
    try {
      final result = await api.getJson('/sms_contacts.php');
      final data = result['data'] as List? ?? [];
      if (offlineReady) unawaited(offlineStore.writeCache(cacheKey, data));
      setState(() => smsContacts = data.map((e) => SmsContact.fromJson(Map<String, dynamic>.from(e as Map))).toList());
    } catch (e) {
      final cached = offlineReady ? await offlineStore.readCache(cacheKey) : null;
      if (cached is List && mounted) {
        setState(() => smsContacts = cached.whereType<Map>().map((e) => SmsContact.fromJson(Map<String, dynamic>.from(e))).toList());
        showSnack('فهرست شماره‌های ذخیره‌شده آفلاین نمایش داده شد');
      } else {
        showSnack('دریافت شماره‌ها انجام نشد: $e');
      }
    }
  }


  Future<void> loadSmsInbox() async {
    if (!has('sms.view')) return;
    final query = <String, String>{'limit': '160'};
    if (!adminMode) query['mine'] = '1';
    final q = smsInboxSearchController.text.trim();
    if (q.isNotEmpty) query['q'] = q;
    if (mounted) setState(() => loadingSmsInbox = true);
    try {
      final result = await api.getJson('/sms_inbox.php', query: query).timeout(const Duration(seconds: 20));
      final data = result['data'] as List? ?? [];
      if (!mounted) return;
      setState(() => smsInboxMessages = data.map((e) => SmsInboxMessage.fromJson(Map<String, dynamic>.from(e as Map))).toList());
    } catch (e) {
      if (!mounted) return;
      showSnack('پیام‌های دریافتی دریافت نشد؛ تنظیمات وبهوک یا اتصال سرور را بررسی کن');
    } finally {
      if (mounted) setState(() => loadingSmsInbox = false);
    }
  }

  Future<void> autoUpdatePendingDeliveries({bool force = false}) async {
    if (!has('sms.view') || autoCheckingDelivery) return;
    final now = DateTime.now();
    if (!force && lastAutoDeliveryCheck != null && now.difference(lastAutoDeliveryCheck!).inMinutes < 4) return;
    final pending = smsMessages
        .where((m) => m.recId.isNotEmpty && m.sendOk && m.deliveryLevel != 'delivered' && m.deliveryLevel != 'failed')
        .take(60)
        .toList();
    if (pending.isEmpty) return;
    autoCheckingDelivery = true;
    lastAutoDeliveryCheck = now;
    try {
      for (final m in pending) {
        try {
          await api.postJson('/sms_delivery.php', {
            'id': m.id,
            'service': m.service,
            'rec_id': m.recId,
            'receiver': m.receiver,
          });
        } catch (_) {}
      }
      await loadSmsMessages(autoCheck: false);
      await loadSmsDashboard(silent: true);
    } finally {
      autoCheckingDelivery = false;
    }
  }

  Future<void> syncOldLocalSmsMessages({bool manual = false}) async {
    if (!has('sms.send')) return;
    final prefs = await SharedPreferences.getInstance();
    final keys = legacySmsPreferenceKeys;
    var total = 0;
    var skipped = 0;
    for (final key in keys) {
      final stored = prefs.get(key);
      final candidates = <String>[];
      if (stored is List<String>) {
        candidates.addAll(stored);
      } else if (stored is List) {
        candidates.addAll(stored.map((e) => e?.toString() ?? '').where((e) => e.isNotEmpty));
      } else if (stored is String && stored.trim().isNotEmpty) {
        candidates.add(stored);
      }
      if (candidates.isEmpty) continue;
      var uploadedThisKey = false;
      for (final raw in candidates) {
        try {
          final decoded = jsonDecode(raw);
          final messages = decoded is List ? decoded : [decoded];
          final result = await api.postJson('/sms_import_local.php', {'messages': messages, 'source': key});
          final imported = int.tryParse('${result['imported'] ?? 0}') ?? 0;
          final duplicate = int.tryParse('${result['duplicates'] ?? 0}') ?? 0;
          total += imported;
          skipped += duplicate;
          if (imported > 0 || duplicate > 0 || '${result['ok']}' == 'true') uploadedThisKey = true;
        } catch (_) {}
      }
      if (uploadedThisKey) await prefs.remove(key);
    }
    try {
      final result = await api.postJson('/sms_sync_panel_history.php', {'days': 7});
      total += int.tryParse('${result['imported'] ?? 0}') ?? 0;
      skipped += int.tryParse('${result['duplicates'] ?? 0}') ?? 0;
    } catch (_) {}

    if (total > 0) {
      if (has('sms.view')) {
        await loadSmsMessages(autoCheck: false);
        await loadSmsDashboard(silent: true);
      }
      if (manual) showSnack('همگام‌سازی انجام شد: ${toFa(total)} پیام منتقل شد');
    } else if (manual) {
      final dupText = skipped > 0 ? '؛ ${toFa(skipped)} پیام قبلاً روی هاست بود' : '';
      showSnack('پیام جدیدی برای انتقال پیدا نشد$dupText');
    }
  }

  void showSnack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  void openNumberPad(
    TextEditingController controller, {
    required String title,
    String doneLabel = 'بعدی',
    VoidCallback? onDone,
  }) {
    FocusScope.of(context).unfocus();
    setState(() {
      activeNumberPadController = controller;
      activeNumberPadTitle = title;
      activeNumberPadDoneLabel = doneLabel;
      activeNumberPadOnDone = onDone;
    });
  }

  void closeNumberPad() {
    if (activeNumberPadController == null) return;
    setState(() {
      activeNumberPadController = null;
      activeNumberPadOnDone = null;
    });
  }

  void numberPadAppend(String digit) {
    final controller = activeNumberPadController;
    if (controller == null) return;
    final text = normalizeDigits(controller.text).replaceAll(RegExp(r'[^0-9]'), '');
    controller.value = TextEditingValue(
      text: '$text$digit',
      selection: TextSelection.collapsed(offset: text.length + digit.length),
    );
    if (identical(controller, smsNumberLineController)) scheduleSmsNameLookup(controller.text);
    setState(() {});
  }

  void numberPadBackspace() {
    final controller = activeNumberPadController;
    if (controller == null) return;
    final text = normalizeDigits(controller.text).replaceAll(RegExp(r'[^0-9]'), '');
    if (text.isEmpty) return;
    final next = text.substring(0, text.length - 1);
    controller.value = TextEditingValue(text: next, selection: TextSelection.collapsed(offset: next.length));
    if (identical(controller, smsNumberLineController)) {
      if (next.length < 11 && smsNameLineController.text.trim().isNotEmpty) {
        smsNameLineController.clear();
      }
      scheduleSmsNameLookup(next);
    }
    setState(() {});
  }

  void numberPadClear() {
    final controller = activeNumberPadController;
    if (controller == null) return;
    controller.clear();
    if (identical(controller, smsNumberLineController)) smsNameLineController.clear();
    setState(() {});
  }

  void numberPadDone() {
    final cb = activeNumberPadOnDone;
    closeNumberPad();
    if (cb != null) {
      Future<void>.delayed(const Duration(milliseconds: 80), cb);
    }
  }

  Widget appNumberField({
    required TextEditingController controller,
    required String label,
    String doneLabel = 'بعدی',
    VoidCallback? onDone,
    FocusNode? focusNode,
    ValueChanged<String>? onChanged,
  }) {
    return TextField(
      controller: controller,
      focusNode: focusNode,
      readOnly: true,
      showCursor: true,
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.right,
      keyboardType: TextInputType.none,
      inputFormatters: numberInputFormatters,
      decoration: InputDecoration(labelText: label),
      onChanged: onChanged,
      onTap: () => openNumberPad(controller, title: label, doneLabel: doneLabel, onDone: onDone),
    );
  }

  Widget numberPadButton(String text, {VoidCallback? onTap, IconData? icon, Color? color}) {
    final fg = color ?? kText;
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(4),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Container(
            height: 54,
            decoration: BoxDecoration(
              color: kSurface,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: kBorder),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 3))],
            ),
            alignment: Alignment.center,
            child: icon == null
                ? Text(text, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: fg))
                : Icon(icon, color: fg, size: 26),
          ),
        ),
      ),
    );
  }

  Widget buildRightHandNumberPad() {
    final controller = activeNumberPadController;
    if (controller == null) return const SizedBox.shrink();
    final screenWidth = MediaQuery.sizeOf(context).width;
    final padWidth = screenWidth < 390 ? screenWidth * 0.82 : 320.0;

    Widget digitRow(List<String> digits) => Row(
          children: digits.map((d) => numberPadButton(d, onTap: () => numberPadAppend(d))).toList(),
        );

    return SafeArea(
      top: false,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
        decoration: BoxDecoration(
          color: kSoftBg,
          border: const Border(top: BorderSide(color: kBorder)),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.16), blurRadius: 18, offset: const Offset(0, -4))],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Row(textDirection: TextDirection.rtl, children: [
              IconButton(onPressed: closeNumberPad, icon: const Icon(Icons.keyboard_hide_rounded)),
              Expanded(
                child: Text(
                  activeNumberPadTitle,
                  textAlign: TextAlign.right,
                  style: const TextStyle(fontWeight: FontWeight.w900, color: kText),
                ),
              ),
              const SizedBox(width: 8),
              Directionality(
                textDirection: TextDirection.ltr,
                child: Text(
                  controller.text.isEmpty ? '' : controller.text,
                  style: const TextStyle(fontWeight: FontWeight.w900, color: kNavy, fontSize: 16),
                ),
              ),
            ]),
            Directionality(
              textDirection: TextDirection.ltr,
              child: Align(
                alignment: Alignment.centerRight,
                child: SizedBox(
                  width: padWidth,
                  child: Column(
                    children: [
                      digitRow(const ['1', '2', '3']),
                      digitRow(const ['4', '5', '6']),
                      digitRow(const ['7', '8', '9']),
                      Row(children: [
                        numberPadButton('پاک', onTap: numberPadClear, color: kDanger),
                        numberPadButton('0', onTap: () => numberPadAppend('0')),
                        numberPadButton('', icon: Icons.backspace_rounded, onTap: numberPadBackspace, color: kDanger),
                      ]),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 6),
            Align(
              alignment: Alignment.centerRight,
              child: SizedBox(
                width: padWidth,
                height: 50,
                child: FilledButton.icon(
                  onPressed: numberPadDone,
                  icon: const Icon(Icons.keyboard_return_rounded),
                  label: Text(activeNumberPadDoneLabel, style: const TextStyle(fontWeight: FontWeight.w900)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  bool canOpenPage(int index) {
    if (index == 0) return has('shipment.create');
    if (index == 1 || index == 6) return has('shipment.view');
    if (index == 2) return has('sms.send');
    if (index == 3 || index == 10) return has('sms.view');
    if (index == 4) return canAdmin;
    if (index == 5) return has('dashboard.view') || has('sms.view');
    if (index == 7 || index == 8 || index == 9) return canAdmin;
    if (index == 11) return true;
    if (index == 12) return has('shipment.scan');
    return false;
  }

  Future<void> openPage(int index, {bool closeDrawer = false}) async {
    if (!canOpenPage(index)) {
      showSnack('شما به این بخش دسترسی ندارید');
      return;
    }
    if (closeDrawer && Navigator.of(context).canPop()) {
      Navigator.of(context).pop();
      await Future<void>.delayed(const Duration(milliseconds: 120));
    }
    if (!mounted) return;
    setState(() => pageIndex = index);
    try {
      if (index == 1) await loadShipments();
      if (index == 2) await loadSmsDashboard(silent: true);
      if (index == 3) await loadSmsMessages();
      if (index == 4) await loadSmsContacts();
      if (index == 5) { if (has('dashboard.view')) await loadDashboard(); if (has('sms.view')) await loadSmsDashboard(silent: true); }
      if (index == 6) await loadShipments();
      if (index == 7) await loadUsers();
      if (index == 8) await loadLogs();
      if (index == 9) await loadSmsTemplates(silent: true);
      if (index == 10) await loadSmsInbox();
      if (index == 11) await loadSubscription(silent: false);
      if (index == 12 && scanDrafts.isEmpty) {}
    } catch (e) {
      showSnack(e.toString());
    }
  }

  Future<void> pickFromCamera() async {
    final photo = await picker.pickImage(source: ImageSource.camera, imageQuality: 82, maxWidth: 1600);
    if (photo == null) return;
    final bytes = await photo.readAsBytes();
    if (!mounted) return;
    setState(() => selectedPhotos.add(PendingPhoto(photo, bytes)));
  }

  Future<void> pickFromGallery() async {
    final photos = await picker.pickMultiImage(imageQuality: 82, maxWidth: 1600);
    final pending = <PendingPhoto>[];
    for (final photo in photos) pending.add(PendingPhoto(photo, await photo.readAsBytes()));
    setState(() => selectedPhotos.addAll(pending));
  }


  String subscriptionErrorText(Object error) {
    if (error is ApiException && error.statusCode == 404) {
      return canAdmin
          ? 'ماژول اشتراک روی سرور نصب نشده است. Backend جدید را در مسیر /post/api بارگذاری کنید.'
          : 'سرویس اشتراک روی سرور فعال نیست. با مدیر سامانه تماس بگیرید.';
    }
    if (error is ApiException && error.code == 'server_not_configured') {
      return canAdmin
          ? 'تنظیمات امن Backend کامل نشده است؛ config.local.php سرور را بررسی کنید.'
          : 'سرویس اشتراک موقتاً در دسترس نیست.';
    }
    return 'ارتباط با سرویس اشتراک برقرار نشد: $error';
  }

  Future<void> loadSubscription({bool silent = true}) async {
    if (!loggedIn) return;
    if (mounted) setState(() => subscriptionLoading = true);
    try {
      final result = await api.getJson('/subscription.php');
      if (!mounted) return;
      setState(() => subscriptionData = Map<String, dynamic>.from(result));
      final active = result['active'] == true;
      if (active) subscriptionPollTimer?.cancel();
      final pending = result['pending'];
      if (!active && pending is Map) {
        subscriptionPollTimer?.cancel();
        subscriptionPollTimer = Timer.periodic(const Duration(seconds: 12), (_) => loadSubscription());
      }
    } catch (e) {
      if (!silent) showSnack(subscriptionErrorText(e));
    } finally {
      if (mounted) setState(() => subscriptionLoading = false);
    }
  }

  Future<void> createPaymentRequest() async {
    setState(() => subscriptionLoading = true);
    try {
      final result = await api.postJson('/subscription.php', const {});
      if (!mounted) return;
      setState(() => subscriptionData = Map<String, dynamic>.from(result));
      if (result['active'] == true) {
        showSnack('اشتراک شما فعال است');
      } else {
        showSnack('درخواست پرداخت ساخته شد؛ مبلغ را دقیقاً واریز کنید');
        subscriptionPollTimer?.cancel();
        subscriptionPollTimer = Timer.periodic(const Duration(seconds: 12), (_) => loadSubscription());
      }
    } catch (e) {
      showSnack(subscriptionErrorText(e));
    } finally {
      if (mounted) setState(() => subscriptionLoading = false);
    }
  }

  Future<void> _forwardBankSms(tel.SmsMessage message) async {
    try {
      final enabled = await secureStore.read(key: 'bank_listener_enabled');
      if (enabled != '1') return;
      final deviceId = await secureStore.read(key: 'bank_listener_device_id') ?? '';
      final key = await secureStore.read(key: 'bank_listener_device_key') ?? '';
      if (deviceId.isEmpty || key.isEmpty) return;
      await http.post(
        api.uri('/payment_match.php'),
        headers: {'Content-Type': 'application/json; charset=utf-8', 'X-Device-Key': key},
        body: jsonEncode({'device_id': deviceId, 'sender': message.address ?? '', 'body': message.body ?? '', 'received_at': DateTime.now().toIso8601String()}),
      ).timeout(const Duration(seconds: 18));
      if (adminMode) unawaited(loadAdminPayments(silent: true));
    } catch (_) {}
  }

  Future<void> startBankListenerIfConfigured() async {
    if (!canAdmin || bankListenerStarted) return;
    final enabled = await secureStore.read(key: 'bank_listener_enabled');
    if (enabled != '1') return;
    final deviceId = await secureStore.read(key: 'bank_listener_device_id') ?? '';
    final key = await secureStore.read(key: 'bank_listener_device_key') ?? '';
    if (deviceId.isEmpty || key.isEmpty) return;
    tel.Telephony.instance.listenIncomingSms(
      onNewMessage: (message) => _forwardBankSms(message),
      onBackgroundMessage: bankSmsBackgroundHandler,
      listenInBackground: true,
    );
    bankListenerStarted = true;
  }

  Future<void> enableBankListener() async {
    if (!canAdmin) return showSnack('فقط مدیر کل می‌تواند شنود بانکی را فعال کند');
    try {
      final granted = await tel.Telephony.instance.requestSmsPermissions;
      if (granted != true) return showSnack('مجوز دریافت پیامک داده نشد');
      var deviceId = await secureStore.read(key: 'bank_listener_device_id') ?? '';
      if (deviceId.isEmpty) deviceId = 'admin-${DateTime.now().microsecondsSinceEpoch}-${Random.secure().nextInt(1 << 31)}';
      final result = await api.postJson('/payment_listener_register.php', {'device_id': deviceId, 'label': 'گوشی مدیر'});
      final key = asText(result['device_key']);
      if (key.isEmpty) throw StateError('کلید دستگاه دریافت نشد');
      await secureStore.write(key: 'bank_listener_device_id', value: deviceId);
      await secureStore.write(key: 'bank_listener_device_key', value: key);
      await secureStore.write(key: 'bank_listener_enabled', value: '1');
      await secureStore.write(key: 'post_api_base_secure', value: api.baseUrl);
      bankListenerStarted = false;
      await startBankListenerIfConfigured();
      showSnack('شنود پیامک بانکی روی این گوشی فعال شد');
    } catch (e) {
      showSnack('فعال‌سازی شنود انجام نشد: $e');
    }
  }

  Future<void> disableBankListener() async {
    final deviceId = await secureStore.read(key: 'bank_listener_device_id') ?? '';
    try {
      if (deviceId.isNotEmpty && canAdmin) {
        await api.postJson('/payment_listener_disable.php', {'device_id': deviceId});
      }
    } catch (e) {
      showSnack('غیرفعال‌سازی سرور انجام نشد: $e');
      return;
    }
    await secureStore.write(key: 'bank_listener_enabled', value: '0');
    await secureStore.delete(key: 'bank_listener_device_key');
    bankListenerStarted = false;
    showSnack('Listener بانکی در این گوشی و سرور غیرفعال شد');
  }

  Future<void> loadAdminStats({bool silent = false}) async {
    if (!canAdmin) return;
    try {
      final result = await api.getJson('/admin_stats.php');
      if (mounted) setState(() => adminStats = Map<String, dynamic>.from(result['data'] as Map));
    } catch (e) { if (!silent) showSnack(e.toString()); }
  }

  Future<void> loadAdminPayments({bool silent = false}) async {
    if (!canAdmin) return;
    try {
      final result = await api.getJson('/admin_payments.php');
      final settings = await api.getJson('/admin_settings.php');
      if (!mounted) return;
      setState(() {
        adminPayments = (result['data'] as List? ?? []).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
        bankSmsEvents = (result['events'] as List? ?? []).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
        paymentSettings = Map<String, dynamic>.from(settings['data'] as Map);
      });
    } catch (e) { if (!silent) showSnack(e.toString()); }
  }

  Future<void> savePaymentSettingsDialog() async {
    if (!canAdmin) return;
    await loadAdminPayments(silent: true);
    final price = TextEditingController(text: asText(paymentSettings['subscription_price_toman'], '150000'));
    final expiry = TextEditingController(text: asText(paymentSettings['payment_expiry_minutes'], '30'));
    final card = TextEditingController(text: asText(paymentSettings['card_number']));
    final holder = TextEditingController(text: asText(paymentSettings['card_holder']));
    final bank = TextEditingController(text: asText(paymentSettings['bank_name']));
    final senders = TextEditingController(text: asText(paymentSettings['bank_sms_senders']));
    final keywords = TextEditingController(text: asText(paymentSettings['bank_credit_keywords']));
    final ok = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: const Text('تنظیمات اشتراک و کارت‌به‌کارت'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'قیمت اشتراک (تومان)')),
        const SizedBox(height: 8), TextField(controller: expiry, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'مهلت Pending (دقیقه)')),
        const SizedBox(height: 8), TextField(controller: card, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'شماره کارت مقصد')),
        const SizedBox(height: 8), TextField(controller: holder, decoration: const InputDecoration(labelText: 'نام صاحب کارت')),
        const SizedBox(height: 8), TextField(controller: bank, decoration: const InputDecoration(labelText: 'نام بانک')),
        const SizedBox(height: 8), TextField(controller: senders, decoration: const InputDecoration(labelText: 'فرستنده‌های معتبر پیامک بانک؛ با کاما جدا')),
        const SizedBox(height: 8), TextField(controller: keywords, decoration: const InputDecoration(labelText: 'کلمات واریز؛ با کاما جدا')),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('لغو')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('ذخیره'))],
    ));
    if (ok == true) {
      try {
        await api.postJson('/admin_settings.php', {'subscription_price_toman': normalizeDigits(price.text), 'payment_expiry_minutes': normalizeDigits(expiry.text), 'card_number': normalizeDigits(card.text).replaceAll(RegExp(r'\D'), ''), 'card_holder': holder.text.trim(), 'bank_name': bank.text.trim(), 'bank_sms_senders': senders.text.trim(), 'bank_credit_keywords': keywords.text.trim()});
        await loadAdminPayments(silent: true);
        showSnack('تنظیمات پرداخت ذخیره شد');
      } catch (e) { showSnack(e.toString()); }
    }
    for (final c in [price, expiry, card, holder, bank, senders, keywords]) { c.dispose(); }
  }

  Future<void> manualActivatePayment(int id) async {
    if (await confirm('این پرداخت به‌صورت دستی تأیید و اشتراک یک‌ماهه فعال شود؟') != true) return;
    try { await api.postJson('/admin_payments.php', {'action': 'activate', 'id': id}); await loadAdminPayments(); await loadAdminStats(silent: true); showSnack('اشتراک فعال شد'); } catch (e) { showSnack(e.toString()); }
  }

  Future<void> quickDeliverMessage(SmsMessage message) async {
    if (!requireActiveSubscriptionUi()) return;
    if (!has('shipment.status')) return showSnack('اجازه تحویل مرسوله ندارید');
    final name = TextEditingController(text: message.fullName);
    final phone = TextEditingController(text: message.receiver);
    final ok = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: const Text('ثبت سریع تحویل'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: name, decoration: const InputDecoration(labelText: 'نام و نام خانوادگی گیرنده')), const SizedBox(height: 10), TextField(controller: phone, keyboardType: TextInputType.phone, inputFormatters: numberInputFormatters, decoration: const InputDecoration(labelText: 'شماره گیرنده'))]),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('لغو')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('تحویل شد'))],
    ));
    if (ok == true) {
      try {
        await api.postJson('/quick_delivery.php', {'sms_message_id': message.id, 'fullname': name.text.trim(), 'phone': normalizeDigits(phone.text).replaceAll(RegExp(r'[^0-9]'), '')});
        await loadSmsMessages(autoCheck: false); if (has('shipment.view')) await loadShipments(); await loadDashboard(); await loadSmsDashboard(silent: true); showSnack('تحویل ثبت شد و پیام مرتبط حذف شد');
      } catch (e) { showSnack(e.toString()); }
    }
    name.dispose(); phone.dispose();
  }

  Future<void> _processSingleScan(XFile photo, {required String mode}) async {
    showSnack('در حال تشخیص بارکد و اطلاعات مرسوله...');
    final draft = await SmartShipmentScanner.scan(photo);
    if (!mounted) return;
    setState(() => scanDrafts = [draft]);
    unawaited(api.postJson('/scan_record.php', {'count': 1, 'successful': draft.readyToMessage ? 1 : 0, 'mode': mode}).catchError((_) => <String, dynamic>{}));
  }

  Future<void> scanSingleShipment() async {
    if (!has('shipment.scan')) return showSnack('اجازه اسکن مرسوله ندارید');
    if (!requireActiveSubscriptionUi()) return;
    final photo = await picker.pickImage(source: ImageSource.camera, imageQuality: 90, maxWidth: 2200);
    if (photo == null) return;
    await _processSingleScan(photo, mode: 'single_camera');
  }

  Future<void> scanSingleShipmentFromGallery() async {
    if (!has('shipment.scan')) return showSnack('اجازه اسکن مرسوله ندارید');
    if (!requireActiveSubscriptionUi()) return;
    final photo = await picker.pickImage(source: ImageSource.gallery, imageQuality: 92, maxWidth: 2400);
    if (photo == null) return;
    await _processSingleScan(photo, mode: 'single_gallery');
  }

  Future<void> _processBatchScan(List<XFile> photos, {required String mode}) async {
    if (photos.isEmpty) return;
    final limited = photos.take(30).toList();
    showSnack('در حال پردازش گروهی ${toFa(limited.length)} مرسوله...');
    final drafts = await SmartShipmentScanner.scanBatch(limited);
    if (!mounted) return;
    setState(() => scanDrafts = drafts);
    final success = drafts.where((e) => e.readyToMessage).length;
    unawaited(api.postJson('/scan_record.php', {'count': drafts.length, 'successful': success, 'mode': mode}).catchError((_) => <String, dynamic>{}));
  }

  Future<void> scanBatchShipments() async {
    if (!has('shipment.scan')) return showSnack('اجازه اسکن گروهی ندارید');
    if (!requireActiveSubscriptionUi()) return;
    final photos = <XFile>[];
    var more = true;
    while (more && photos.length < 30) {
      final photo = await picker.pickImage(source: ImageSource.camera, imageQuality: 90, maxWidth: 2200);
      if (photo == null) break;
      photos.add(photo);
      if (!mounted) return;
      more = await showDialog<bool>(
            context: context,
            builder: (context) => AlertDialog(
              title: Text('${toFa(photos.length)} عکس ثبت شد'),
              content: const Text('عکس مرسوله بعدی گرفته شود؟'),
              actions: [
                TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('پایان')),
                FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('عکس بعدی')),
              ],
            ),
          ) ??
          false;
    }
    await _processBatchScan(photos, mode: 'batch_camera');
  }

  Future<void> scanBatchShipmentsFromGallery() async {
    if (!has('shipment.scan')) return showSnack('اجازه اسکن گروهی ندارید');
    if (!requireActiveSubscriptionUi()) return;
    final photos = await picker.pickMultiImage(imageQuality: 92, maxWidth: 2400);
    if (photos.isEmpty) return;
    if (photos.length > 30) showSnack('حداکثر ۳۰ تصویر اول پردازش می‌شود');
    await _processBatchScan(photos, mode: 'batch_gallery');
  }

  Future<void> registerScannedDraft(ScannedShipmentDraft draft) async {
    if (!requireActiveSubscriptionUi()) return;
    if (draft.fullname.trim().isEmpty) return showSnack('نام گیرنده را تکمیل کنید');
    try {
      final bytes = await draft.file.readAsBytes();
      await api.saveShipment(fields: {'fullname': draft.fullname.trim(), 'phone': draft.phone, 'shipment_type': 'بسته', 'receiver_info': [draft.paymentType, if (draft.trackingCode.isNotEmpty) 'بارکد: ${draft.trackingCode}'].where((e) => e.isNotEmpty).join(' | '), 'description': draft.rawText.length > 500 ? draft.rawText.substring(0, 500) : draft.rawText, 'shamsi_date': todayShamsiDate(), 'client_operation_id': _operationId('scan')}, photos: [PendingPhoto(draft.file, bytes)]);
      showSnack('مرسوله اسکن‌شده ثبت شد'); if (has('shipment.view')) unawaited(loadShipments()); unawaited(loadDashboard());
    } catch (e) { showSnack(e.toString()); }
  }

  Future<void> sendScannedDraftMessage(ScannedShipmentDraft draft) async {
    if (!requireActiveSubscriptionUi()) return;
    if (!draft.readyToMessage) return showSnack('نام و شماره معتبر باید استخراج یا تکمیل شود');
    if (!has('sms.send')) return showSnack('اجازه ارسال پیامک ندارید');
    if (smsTemplates.isEmpty) await loadSmsTemplates(silent: true);
    String service = smsService;
    SmsTemplate? selected = smsTemplates.isNotEmpty ? smsTemplates.first : null;
    final text = TextEditingController(text: selected?.text ?? 'مرسوله شما به دفتر پست رسیده است.');
    final ok = await showDialog<bool>(context: context, builder: (context) => StatefulBuilder(builder: (context, setLocal) => AlertDialog(
      title: Text('ارسال پیام به ${draft.fullname}'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        DropdownButtonFormField<String>(value: service, decoration: const InputDecoration(labelText: 'شرکت پیامکی'), items: const [DropdownMenuItem(value: 'melli', child: Text('ملی پیامک')), DropdownMenuItem(value: 'smsir', child: Text('SMS.ir'))], onChanged: (v) => setLocal(() => service = v ?? 'melli')),
        const SizedBox(height: 10),
        if (smsTemplates.isNotEmpty) DropdownButtonFormField<int>(value: selected?.id, decoration: const InputDecoration(labelText: 'کلمه کلیدی / قالب'), items: smsTemplates.map((t) => DropdownMenuItem(value: t.id, child: Text(t.keyword))).toList(), onChanged: (id) { final list = smsTemplates.where((e) => e.id == id).toList(); if (list.isNotEmpty) setLocal(() { selected = list.first; text.text = selected!.text; }); }),
        const SizedBox(height: 10), TextField(controller: text, minLines: 3, maxLines: 6, decoration: const InputDecoration(labelText: 'متن پیام')),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('لغو')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('ارسال'))],
    )));
    if (ok == true) {
      try {
        final result = await _sendSmsOrQueue({'service': service, 'sender': senderForSmsService(service), 'receivers': '${draft.phone} ${draft.fullname}', 'text': text.text.trim(), 'group_title': selected?.keyword ?? 'اسکن مرسوله', 'template_key': selected?.keyword ?? '', 'client_operation_id': _operationId('sms')});
        showSnack(result == null ? 'پیام در صف آفلاین قرار گرفت' : 'پیام ارسال و ثبت شد');
      } catch (e) { showSnack(e.toString()); }
    }
    text.dispose();
  }

  Future<void> sendAllReadyScans() async {
    if (!requireActiveSubscriptionUi()) return;
    final ready = scanDrafts.where((e) => e.readyToMessage).toList();
    if (ready.isEmpty) return showSnack('هیچ ردیف آماده ارسال نیست');
    if (!has('sms.send')) return showSnack('اجازه ارسال پیامک ندارید');
    if (smsTemplates.isEmpty) await loadSmsTemplates(silent: true);

    String service = smsService;
    SmsTemplate? selected = smsTemplates.isNotEmpty ? smsTemplates.first : null;
    final text = TextEditingController(text: selected?.text ?? 'مرسوله شما به دفتر پست رسیده است.');
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setLocal) => AlertDialog(
          title: Text('ارسال گروهی به ${toFa(ready.length)} گیرنده'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  value: service,
                  decoration: const InputDecoration(labelText: 'شرکت پیامکی'),
                  items: const [
                    DropdownMenuItem(value: 'melli', child: Text('ملی پیامک')),
                    DropdownMenuItem(value: 'smsir', child: Text('SMS.ir')),
                  ],
                  onChanged: (v) => setLocal(() => service = v ?? 'melli'),
                ),
                const SizedBox(height: 10),
                if (smsTemplates.isNotEmpty)
                  DropdownButtonFormField<int>(
                    value: selected?.id,
                    decoration: const InputDecoration(labelText: 'کلمه کلیدی / قالب'),
                    items: smsTemplates.map((t) => DropdownMenuItem(value: t.id, child: Text(t.keyword))).toList(),
                    onChanged: (id) {
                      final list = smsTemplates.where((e) => e.id == id).toList();
                      if (list.isNotEmpty) {
                        setLocal(() {
                          selected = list.first;
                          text.text = selected!.text;
                        });
                      }
                    },
                  ),
                const SizedBox(height: 10),
                TextField(
                  controller: text,
                  minLines: 3,
                  maxLines: 6,
                  decoration: const InputDecoration(labelText: 'متن پیام'),
                ),
                const SizedBox(height: 10),
                const Text('فقط ردیف‌هایی ارسال می‌شوند که نام و شماره موبایل معتبر دارند.', style: TextStyle(color: kMuted)),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('لغو')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('ارسال گروهی')),
          ],
        ),
      ),
    );

    if (ok == true) {
      final body = text.text.trim();
      if (body.isEmpty) {
        text.dispose();
        return showSnack('متن پیام نمی‌تواند خالی باشد');
      }
      final receivers = ready.map((e) => '${e.phone} ${e.fullname}').join('\n');
      try {
        final result = await _sendSmsOrQueue({
          'service': service,
          'sender': senderForSmsService(service),
          'receivers': receivers,
          'text': body,
          'group_title': selected?.keyword ?? 'اسکن گروهی',
          'template_key': selected?.keyword ?? '',
          'client_operation_id': _operationId('sms'),
        });
        showSnack(result == null ? 'ارسال گروهی در صف آفلاین قرار گرفت' : 'ارسال گروهی ثبت شد');
      } catch (e) {
        showSnack(e.toString());
      }
    }
    text.dispose();
  }

  Future<void> onVersionTap() async {
    versionTapCount++;
    if (versionTapCount < 7) return;
    versionTapCount = 0;
    if (!canAdmin) return showSnack('پنل مدیریت فقط برای مدیر کل فعال است');
    if (Navigator.of(context).canPop()) Navigator.of(context).pop();
    setState(() { adminMode = true; adminPageIndex = 0; });
    await loadAdminStats(silent: true); await loadUsers(); await startBankListenerIfConfigured();
  }

  Future<void> openAdminPage(int index, {bool closeDrawer = false}) async {
    if (!canAdmin) return;
    if (closeDrawer && Navigator.of(context).canPop()) { Navigator.of(context).pop(); await Future<void>.delayed(const Duration(milliseconds: 100)); }
    if (!mounted) return; setState(() => adminPageIndex = index);
    if (index == 0) await loadAdminStats(silent: true);
    if (index == 1) await loadUsers();
    if (index == 2) await loadSmsContacts();
    if (index == 3) await loadAdminPayments(silent: true);
    if (index == 4) await loadLogs();
    if (index == 5) await loadSmsTemplates(silent: true);
    if (index == 6) await loadShipments(todayOnly: false);
    if (index == 7) await loadSmsMessages(autoCheck: false);
  }

  Future<void> saveShipment() async {
    if (!has('shipment.create')) return showSnack('شما اجازه ثبت ندارید');
    if (!requireActiveSubscriptionUi()) return;
    if (fullnameController.text.trim().isEmpty) return showSnack('نام و نام خانوادگی گیرنده الزامی است');
    setState(() => saving = true);
    final fields = <String, String>{
      'editId': editingShipmentId?.toString() ?? '',
      'fullname': fullnameController.text.trim(),
      'phone': phoneController.text.trim(),
      'shipment_type': shipmentType,
      'receiver_info': receiverController.text.trim(),
      'description': '',
      'shamsi_date': dateVal(jy, jm, jd),
      'client_operation_id': _operationId('shipment'),
    };
    final photos = List<PendingPhoto>.from(selectedPhotos);
    Future<void> queueCurrentShipment() async {
      await offlineStore.enqueueShipment(
        owner: username,
        operationId: fields['client_operation_id']!,
        fields: fields,
        photos: photos
            .map((photo) => OfflineBinaryPhoto(filename: photo.file.name.isEmpty ? 'photo.jpg' : photo.file.name, bytes: photo.bytes))
            .toList(),
      );
      await _refreshPendingSyncCount();
    }

    try {
      if (!await _hasNetworkConnection()) {
        await queueCurrentShipment();
        resetForm();
        showSnack('مرسوله داخل گوشی ذخیره شد و با وصل‌شدن اینترنت به‌آرامی همگام‌سازی می‌شود');
        return;
      }
      await api.saveShipment(fields: fields, photos: photos);
      resetForm();
      searchController.clear();
      if (has('shipment.view')) {
        await loadShipments();
        if (mounted) setState(() => pageIndex = 1);
      }
      await loadDashboard();
      showSnack('مرسوله ذخیره شد');
    } catch (e) {
      if (_shouldQueueError(e)) {
        await queueCurrentShipment();
        resetForm();
        showSnack('اتصال ناپایدار بود؛ مرسوله در صف همگام‌سازی ذخیره شد');
      } else {
        showSnack(e.toString());
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  void resetForm() {
    fullnameController.clear();
    phoneController.clear();
    receiverController.clear();
    editingShipmentId = null;
    shipmentType = shipmentTypes.first;
    selectedPhotos.clear();
    _setToday();
    setState(() {});
  }

  void editShipment(Shipment shipment) {
    if (!has('shipment.edit')) return showSnack('شما اجازه ویرایش ندارید');
    setState(() {
      editingShipmentId = shipment.id;
      fullnameController.text = shipment.fullname;
      phoneController.text = shipment.phone;
      receiverController.text = shipment.receiverInfo;
      shipmentType = shipmentTypes.contains(shipment.shipmentType) ? shipment.shipmentType : shipmentTypes.first;
      selectedPhotos.clear();
      pageIndex = 0;
    });
  }

  Future<bool?> confirm(String message) => showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('تأیید'),
          content: Text(message),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('لغو')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('تأیید')),
          ],
        ),
      );

  Future<void> deleteShipment(Shipment shipment) async {
    if (!has('shipment.delete')) return showSnack('شما اجازه حذف ندارید');
    if (await confirm('این مرسوله حذف شود؟') != true) return;
    try {
      await api.deleteJson('/delete.php', query: {'id': shipment.id.toString()});
      await loadShipments();
      await loadDashboard();
      showSnack('مرسوله حذف شد');
    } catch (e) {
      showSnack(e.toString());
    }
  }

  Future<void> markShipmentDelivered(Shipment shipment) async {
    if (!has('shipment.status')) return showSnack('شما اجازه تغییر وضعیت ندارید');
    if (!requireActiveSubscriptionUi()) return;
    if (shipment.status == 'delivered') return showSnack('این مرسوله قبلاً تحویل شده است');
    if (await confirm('مرسوله ${shipment.fullname} تحویل شد؟ پیام‌های ثبت‌شده مرتبط پس از همگام‌سازی حذف می‌شوند.') != true) return;
    final payload = <String, dynamic>{
      'id': shipment.id,
      'status': 'delivered',
      'client_operation_id': _operationId('status'),
    };
    try {
      if (!await _hasNetworkConnection()) {
        await offlineStore.enqueue(owner: username, type: 'shipment_status', operationId: payload['client_operation_id'] as String, payload: payload);
        await _refreshPendingSyncCount();
        showSnack('ثبت تحویل در صف آفلاین ذخیره شد');
        return;
      }
      final result = await api.postJson('/change_status.php', payload);
      final removed = int.tryParse('${result['removed_sms'] ?? 0}') ?? 0;
      await loadShipments();
      if (has('sms.view')) await loadSmsMessages(autoCheck: false);
      await loadDashboard();
      await loadSmsDashboard(silent: true);
      showSnack('تحویل ثبت شد؛ ${toFa(removed)} پیام مرتبط حذف شد');
    } catch (e) {
      if (_shouldQueueError(e)) {
        await offlineStore.enqueue(owner: username, type: 'shipment_status', operationId: payload['client_operation_id'] as String, payload: payload);
        await _refreshPendingSyncCount();
        showSnack('اتصال ناپایدار بود؛ ثبت تحویل در صف همگام‌سازی قرار گرفت');
      } else {
        showSnack(e.toString());
      }
    }
  }

  void resetUserForm() {
    userIdController.clear();
    newUserController.clear();
    newPassController.clear();
    newUserActive = true;
    newUserWorkScope = 'main';
    villageNameController.clear();
    permSmsSend = false;
    permSmsView = false;
    permShipmentCreate = true;
    permShipmentView = true;
    permShipmentDeliver = true;
    permShipmentScan = true;
    setState(() {});
  }

  void editUser(AppUser user) {
    if (!has('user.manage')) return showSnack('شما اجازه مدیریت کاربر ندارید');
    userIdController.text = user.id.toString();
    newUserController.text = user.username;
    newPassController.clear();
    newUserActive = user.isActive;
    newUserWorkScope = user.workScope;
    villageNameController.text = user.villageName;
    permSmsSend = user.can('sms.send');
    permSmsView = user.can('sms.view');
    permShipmentCreate = user.can('shipment.create');
    permShipmentView = user.can('shipment.view');
    permShipmentDeliver = user.can('shipment.status');
    permShipmentScan = user.can('shipment.scan');
    setState(() {});
    showSnack('کاربر ${user.username} برای ویرایش انتخاب شد');
  }

  Future<void> saveUser() async {
    if (!has('user.manage')) return showSnack('شما اجازه مدیریت کاربر ندارید');
    try {
      await api.postJson('/save_user.php', {
        'id': int.tryParse(userIdController.text) ?? 0,
        'username': newUserController.text.trim(),
        'password': newPassController.text,
        'is_active': newUserActive ? 1 : 0,
        'work_scope': newUserWorkScope,
        'village_name': newUserWorkScope == 'village' ? villageNameController.text.trim() : '',
        'can_send_sms': permSmsSend ? 1 : 0,
        'can_view_sms': permSmsView ? 1 : 0,
        'can_register_shipment': permShipmentCreate ? 1 : 0,
        'can_view_shipments': permShipmentView ? 1 : 0,
        'can_deliver_shipment': permShipmentDeliver ? 1 : 0,
        'can_scan_shipment': permShipmentScan ? 1 : 0,
      });
      resetUserForm();
      await loadUsers();
      showSnack('کاربر ذخیره شد');
    } catch (e) {
      showSnack(e.toString());
    }
  }

  Future<void> disableUser(AppUser user) async {
    if (!has('user.manage')) return;
    if (await confirm('کاربر ${user.username} غیرفعال شود؟') != true) return;
    try {
      await api.deleteJson('/delete_user.php', query: {'id': user.id.toString()});
      await loadUsers();
      showSnack('کاربر غیرفعال شد');
    } catch (e) {
      showSnack(e.toString());
    }
  }


  Future<void> loadSmsTemplates({bool silent = false}) async {
    if (!has('sms.send')) return;
    try {
      final result = await api.getJson('/sms_templates.php', query: adminMode && canAdmin ? {'admin_all': '1'} : null);
      final data = result['data'] as List? ?? [];
      if (!mounted) return;
      setState(() => smsTemplates = data.map((e) => SmsTemplate.fromJson(Map<String, dynamic>.from(e as Map))).toList());
    } catch (e) {
      if (!silent) showSnack('کلمات کلیدی پیامک دریافت نشد: $e');
    }
  }

  void applySmsTemplateKeyword(String value) {
    final key = value.trim();
    final matches = smsTemplates.where((t) => t.keyword == key).toList();
    if (matches.isEmpty) return;
    final tpl = matches.first;
    smsGroupController.text = tpl.keyword;
    if (smsTextController.text.trim().isEmpty || smsTextController.text.trim() != tpl.text.trim()) {
      smsTextController.text = tpl.text;
    }
  }

  Future<void> saveSmsTemplate() async {
    if (!has('sms.send')) return showSnack('اجازه مدیریت کلمات کلیدی ندارید');
    final keyword = smsTemplateKeywordController.text.trim();
    final text = smsTemplateTextController.text.trim();
    if (keyword.isEmpty || text.isEmpty) return showSnack('کلمه کلیدی و متن پیام را وارد کنید');
    setState(() => savingSmsTemplate = true);
    try {
      await api.postJson('/sms_templates.php', {
        'id': int.tryParse(smsTemplateIdController.text) ?? 0,
        'keyword': keyword,
        'text': text,
      });
      smsTemplateIdController.clear();
      smsTemplateKeywordController.clear();
      smsTemplateTextController.clear();
      await loadSmsTemplates();
      showSnack('کلمه کلیدی ذخیره شد');
    } catch (e) {
      showSnack(e.toString());
    } finally {
      if (mounted) setState(() => savingSmsTemplate = false);
    }
  }

  Future<void> deleteSmsTemplate(SmsTemplate tpl) async {
    if (!has('sms.send')) return;
    if (await confirm('کلمه کلیدی «${tpl.keyword}» حذف شود؟') != true) return;
    try {
      await api.deleteJson('/sms_templates.php', query: {'id': tpl.id.toString()});
      await loadSmsTemplates();
      showSnack('حذف شد');
    } catch (e) {
      showSnack(e.toString());
    }
  }

  void editSmsTemplate(SmsTemplate tpl) {
    smsTemplateIdController.text = tpl.id.toString();
    smsTemplateKeywordController.text = tpl.keyword;
    smsTemplateTextController.text = tpl.text;
  }

  void useSmsTemplate(SmsTemplate tpl) {
    smsKeywordController.text = tpl.keyword;
    smsGroupController.text = tpl.keyword;
    smsTextController.text = tpl.text;
    openPage(2);
  }

  void scheduleSmsNameLookup(String rawNumber) {
    final phone = normalizeDigits(rawNumber).replaceAll(RegExp(r'[^0-9]'), '');
    smsNameLookupDebounce?.cancel();
    if (!RegExp(r'^09\d{9}$').hasMatch(phone)) return;
    if (smsNameLineController.text.trim().isNotEmpty) return;
    smsNameLookupDebounce = Timer(const Duration(milliseconds: 180), () => lookupSmsNameForNumber(phone));
  }

  Future<void> lookupSmsNameForNumber(String rawNumber, {bool force = false}) async {
    final phone = normalizeDigits(rawNumber).replaceAll(RegExp(r'[^0-9]'), '');
    if (!RegExp(r'^09\d{9}$').hasMatch(phone)) return;
    if (!force && smsNameLineController.text.trim().isNotEmpty) return;
    final cached = smsKnownNamesByPhone[phone];
    if (cached != null && cached.trim().isNotEmpty) {
      if (mounted && (force || smsNameLineController.text.trim().isEmpty)) {
        setState(() => smsNameLineController.text = cached);
      }
      return;
    }
    if (!force && smsNameLookupTried.contains(phone)) return;
    smsNameLookupTried.add(phone);
    try {
      final result = await api.getJson('/sms_contact_lookup.php', query: {'phone': phone}).timeout(const Duration(seconds: 5));
      final name = asText(result['name']);
      if (name.trim().isNotEmpty) {
        smsKnownNamesByPhone[phone] = name.trim();
        if (mounted && (force || smsNameLineController.text.trim().isEmpty) && normalizeDigits(smsNumberLineController.text).replaceAll(RegExp(r'[^0-9]'), '') == phone) {
          setState(() => smsNameLineController.text = name.trim());
        }
      }
    } catch (_) {}
  }

  void addSmsReceiverLine() {
    final number = normalizeDigits(smsNumberLineController.text.trim());
    final clean = number.replaceAll(RegExp(r'[^0-9+]'), '');
    var name = smsNameLineController.text.trim();
    if (name.isEmpty) name = smsKnownNamesByPhone[clean] ?? '';
    if (clean.isEmpty) return showSnack('شماره را وارد کنید');
    final line = name.isEmpty ? clean : '$clean $name';
    final old = smsNumbersController.text.trim();
    smsNumbersController.text = old.isEmpty ? line : '$old\n$line';
    smsNumberLineController.clear();
    smsNameLineController.clear();
    Future<void>.delayed(const Duration(milliseconds: 80), () { if (mounted) smsNumberLineFocus.requestFocus(); });
  }

  void submitSmsNumberLine() {
    if (smsNumberLineController.text.trim().isEmpty) {
      showSnack('شماره را وارد کنید');
      return;
    }
    lookupSmsNameForNumber(smsNumberLineController.text);
    smsNameLineFocus.requestFocus();
  }

  void submitSmsNameLine() {
    addSmsReceiverLine();
  }

  Future<void> sendSms() async {
    if (!has('sms.send')) return showSnack('شما اجازه ارسال پیامک ندارید');
    final numbers = smsNumbersController.text.trim();
    if (smsTextController.text.trim().isEmpty && smsKeywordController.text.trim().isNotEmpty) {
      applySmsTemplateKeyword(smsKeywordController.text);
    }
    final text = smsTextController.text.trim();
    if (numbers.isEmpty || text.isEmpty) return showSnack('شماره گیرنده و متن پیام را وارد کنید');
    final sender = senderForSmsService(smsService);
    smsSenderController.text = sender;
    final payload = <String, dynamic>{
      'service': smsService,
      'sender': sender,
      'receivers': numbers,
      'text': text,
      'group_title': smsGroupController.text.trim(),
      'template_key': smsKeywordController.text.trim(),
      'client_operation_id': _operationId('sms'),
    };
    setState(() => sendingSms = true);
    try {
      final result = await _sendSmsOrQueue(payload);
      smsNumbersController.clear();
      smsGroupController.clear();
      smsKeywordController.clear();
      if (result == null) {
        showSnack('پیام داخل گوشی ذخیره شد و پس از وصل‌شدن اینترنت، مرحله‌ای ارسال می‌شود');
        return;
      }
      final success = result['success_count'] ?? 0;
      final failed = result['failed_count'] ?? 0;
      if (has('sms.view')) {
        await loadSmsDashboard(silent: true);
        await loadSmsMessages();
        setState(() => pageIndex = 3);
      }
      showSnack('ارسال ثبت شد؛ موفق: $success / ناموفق: $failed');
    } catch (e) {
      showSnack(e.toString());
    } finally {
      if (mounted) setState(() => sendingSms = false);
    }
  }

  Future<void> updateDelivery(SmsMessage message) async {
    if (message.recId.isEmpty) return showSnack('این پیام شناسه دلیوری ندارد');
    try {
      await api.postJson('/sms_delivery.php', {
        'id': message.id,
        'service': message.service,
        'rec_id': message.recId,
        'receiver': message.receiver,
      });
      await loadSmsMessages();
      await loadSmsDashboard(silent: true);
      showSnack('وضعیت دلیوری به‌روزرسانی شد');
    } catch (e) {
      showSnack(e.toString());
    }
  }


  Future<void> resendWithPanel(SmsMessage message, String targetService) async {
    if (!has('sms.send')) return showSnack('شما اجازه ارسال پیامک ندارید');
    final service = targetService == 'smsir' ? 'smsir' : 'melli';
    final sender = senderForSmsService(service);
    try {
      final result = await _sendSmsOrQueue({
        'service': service,
        'sender': sender,
        'receivers': message.fullName.isNotEmpty ? '${message.receiver} ${message.fullName}' : message.receiver,
        'text': message.text,
        'group_title': 'ارسال با ${service == 'smsir' ? 'SMS.ir' : 'ملی پیامک'} پس از ناموفق',
        'client_operation_id': _operationId('sms'),
      });
      if (result == null) {
        showSnack('ارسال با پنل دیگر در صف آفلاین ذخیره شد');
        return;
      }
      final success = int.tryParse('${result['success_count'] ?? 0}') ?? 0;
      final failed = int.tryParse('${result['failed_count'] ?? 0}') ?? 0;
      if (success > 0) await markSmsMessagesResolvedByPanel([message.id], service, phones: [message.receiver]);
      await loadSmsDashboard(silent: true);
      await loadSmsMessages(autoCheck: false);
      showSnack('ارسال جایگزین ثبت شد؛ موفق: $success / ناموفق: $failed');
    } catch (e) {
      showSnack(e.toString());
    }
  }

  Future<void> markFailedMessagesSuccess(List<SmsMessage> items, {bool ask = true}) async {
    final failed = failedOnlyFrom(items);
    if (failed.isEmpty) return showSnack('پیام ناموفقی انتخاب نشده است');
    if (ask && await confirm('${toFa(failed.length)} پیام ناموفق به حالت موفق تبدیل شوند؟') != true) return;
    try {
      final ids = failed.map((m) => m.id).where((id) => id > 0).toList();
      if (ids.isEmpty) return showSnack('شناسه پیام‌ها معتبر نیست');
      final result = await api.postJson('/sms_mark_success.php', {'ids': ids});
      final updated = int.tryParse('${result['updated'] ?? 0}') ?? 0;
      smsLocallyResolvedIds.addAll(ids);
      if (mounted) setState(() {
        smsMessages.removeWhere((m) => ids.contains(m.id));
        dashboardFailedMessages.removeWhere((m) => ids.contains(m.id));
      });
      await loadSmsDashboard(silent: true);
      if (pageIndex == 3 || adminMode) await loadSmsMessages(autoCheck: false);
      showSnack('${toFa(updated)} پیام به حالت موفق تغییر کرد');
    } catch (e) {
      showSnack('تغییر وضعیت پیام‌ها انجام نشد: $e');
    }
  }

  List<SmsMessage> failedOnlyFrom(List<SmsMessage> items) => items.where((m) => smsMessageIsFailed(m)).toList();

  String failedNumbersOnly(List<SmsMessage> items) {
    final numbers = <String>{};
    for (final message in failedOnlyFrom(items)) {
      final number = canonicalMobile(message.receiver);
      if (number.isNotEmpty) numbers.add(number);
    }
    return numbers.join('\n');
  }

  Future<void> copyFailedNumbers(List<SmsMessage> items) async {
    final text = failedNumbersOnly(items);
    if (text.isEmpty) return showSnack('شماره ناموفق قابل کپی پیدا نشد');
    await Clipboard.setData(ClipboardData(text: text));
    final count = text.split('\n').length;
    showSnack('${toFa(count)} شماره ناموفق فقط به‌صورت شماره کپی شد');
  }

  Future<void> markSmsMessagesResolvedByPanel(List<int> ids, String service, {List<String> phones = const []}) async {
    if (ids.isEmpty && phones.isEmpty) return;
    smsLocallyResolvedIds.addAll(ids);
    try {
      await api.postJson('/sms_mark_resend_resolved.php', {'ids': ids, 'phones': phones, 'service': service});
    } catch (_) {}
  }

  Future<void> resendFailedBulkWithPanel(List<SmsMessage> items, {String? targetService}) async {
    if (!has('sms.send')) return showSnack('شما اجازه ارسال پیامک ندارید');
    final failed = failedOnlyFrom(items);
    if (failed.isEmpty) return showSnack('پیام ناموفقی برای ارسال گروهی وجود ندارد');
    if (await confirm('برای ${toFa(failed.length)} شماره ناموفق، ارسال گروهی با پنل انجام شود؟') != true) return;

    setState(() => bulkSendingSms = true);
    var totalSuccess = 0;
    var totalFailed = 0;
    final resolvedIds = <int>[];

    final groups = <String, List<SmsMessage>>{};
    for (final m in failed) {
      final key = '${m.text}__${m.groupTitle}__${targetService ?? m.service}';
      groups.putIfAbsent(key, () => []).add(m);
    }

    try {
      for (final entry in groups.entries) {
        final part = entry.value;
        final service = targetService ?? (part.first.service == 'melli' ? 'smsir' : 'melli');
        final sender = senderForSmsService(service);
        final receivers = part.map((m) => m.fullName.isNotEmpty ? '${m.receiver} ${m.fullName}' : m.receiver).join('\n');
        final result = await _sendSmsOrQueue({
          'service': service,
          'sender': sender,
          'receivers': receivers,
          'text': part.first.text,
          'group_title': 'ارسال گروهی ناموفق‌ها با ${service == 'smsir' ? 'SMS.ir' : 'ملی پیامک'}',
          'client_operation_id': _operationId('sms'),
        });
        if (result == null) {
          continue;
        }
        final success = int.tryParse('${result['success_count'] ?? 0}') ?? 0;
        final failedCount = int.tryParse('${result['failed_count'] ?? 0}') ?? 0;
        totalSuccess += success;
        totalFailed += failedCount;
        if (success > 0) {
          final sentData = result['data'];
          if (sentData is List) {
            final okReceivers = sentData
                .whereType<Map>()
                .where((row) => row['ok'] == true || '${row['ok']}' == '1')
                .map((row) => '${row['receiver'] ?? ''}'.replaceAll(RegExp(r'[^0-9+]'), ''))
                .toSet();
            resolvedIds.addAll(part.where((m) => okReceivers.contains(m.receiver.replaceAll(RegExp(r'[^0-9+]'), ''))).map((m) => m.id));
          } else {
            resolvedIds.addAll(part.take(success).map((m) => m.id));
          }
        }
      }
      if (resolvedIds.isNotEmpty) {
        final service = targetService ?? 'smsir';
        await markSmsMessagesResolvedByPanel(resolvedIds, service, phones: failed.map((m) => m.receiver).toList());
      }
      await loadSmsDashboard(silent: true);
      await loadSmsMessages(autoCheck: false);
      showSnack('ارسال گروهی انجام شد؛ موفق: $totalSuccess / ناموفق: $totalFailed');
    } catch (e) {
      showSnack('ارسال گروهی با پنل انجام نشد: $e');
    } finally {
      if (mounted) setState(() => bulkSendingSms = false);
    }
  }

  Future<void> sendFailedBulkWithDevice(List<SmsMessage> items) async {
    final failed = failedOnlyFrom(items);
    if (failed.isEmpty) return showSnack('پیام ناموفقی برای ارسال با گوشی وجود ندارد');
    final firstText = failed.first.text.trim();
    final sameText = failed.every((m) => m.text.trim() == firstText);
    if (!sameText) {
      showSnack('ارسال گروهی با گوشی فقط برای پیام‌های هم‌متن داخل یک کارت انجام می‌شود');
      return;
    }
    if (await confirm('برنامه پیامک گوشی برای ${toFa(failed.length)} شماره باز شود؟') != true) return;

    final phones = failed
        .map((m) => m.receiver.replaceAll(RegExp(r'[^0-9+]'), ''))
        .where((p) => p.isNotEmpty)
        .toSet()
        .toList();
    if (phones.isEmpty) return showSnack('شماره معتبری پیدا نشد');

    final addressComma = phones.join(',');
    final addressSemi = phones.join(';');
    final text = firstText;
    final candidates = <Uri>[
      Uri.parse('sms:?addresses=$addressComma&body=${Uri.encodeComponent(text)}'),
      Uri.parse('smsto:$addressComma?body=${Uri.encodeComponent(text)}'),
      Uri.parse('sms:$addressSemi?body=${Uri.encodeComponent(text)}'),
      Uri.parse('smsto:$addressSemi?body=${Uri.encodeComponent(text)}'),
    ];

    var opened = false;
    Object? lastError;
    for (final uri in candidates) {
      try {
        opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
        if (opened) break;
      } catch (e) {
        lastError = e;
      }
    }
    if (!opened) {
      showSnack('برنامه پیامک گوشی برای ارسال گروهی باز نشد');
      debugPrint('Bulk SMS launch failed: $lastError');
      return;
    }

    final ids = failed.map((m) => m.id).toList();
    smsLocallyResolvedIds.addAll(ids);
    setState(() => smsMessages.removeWhere((m) => ids.contains(m.id)));
    final devicePayload = <String, dynamic>{
      'ids': ids,
      'phones': failed.map((m) => m.receiver).toList(),
      'text': firstText,
      'client_operation_id': _operationId('device_sms'),
    };
    try {
      await api.postJson('/sms_mark_device_sent.php', devicePayload);
    } catch (error) {
      if (offlineReady && _shouldQueueError(error)) {
        await offlineStore.enqueue(
          owner: username,
          type: 'sms_device_sent',
          operationId: devicePayload['client_operation_id'] as String,
          payload: devicePayload,
        );
        await _refreshPendingSyncCount();
      }
    }
    await loadSmsMessages(autoCheck: false);
    await loadSmsDashboard(silent: true);
    showSnack('ارسال گروهی با گوشی ثبت شد و از لیست ناموفق خارج شد');
  }

  Future<void> sendWithDeviceSms(SmsMessage message) async {
    final rawPhone = message.receiver.trim();
    final phone = rawPhone.replaceAll(RegExp(r'[^0-9+]'), '');
    if (phone.isEmpty) return showSnack('شماره گیرنده موجود نیست');
    try {
      final text = message.text.trim();
      final candidates = <Uri>[
        Uri(scheme: 'smsto', path: phone, queryParameters: {'body': text}),
        Uri(scheme: 'sms', path: phone, queryParameters: {'body': text}),
        Uri.parse('sms:$phone?body=${Uri.encodeComponent(text)}'),
        Uri.parse('smsto:$phone?body=${Uri.encodeComponent(text)}'),
        Uri.parse('sms:?addresses=$phone&body=${Uri.encodeComponent(text)}'),
        Uri.parse('mmsto:$phone?body=${Uri.encodeComponent(text)}'),
      ];

      var opened = false;
      Object? lastError;
      for (final uri in candidates) {
        try {
          opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
          if (opened) break;
        } catch (e) {
          lastError = e;
        }
      }

      if (!opened) {
        showSnack('برنامه پیامک گوشی باز نشد. لطفاً یک برنامه SMS پیش‌فرض روی گوشی تنظیم کنید.');
        debugPrint('SMS launch failed: $lastError');
        return;
      }

      smsLocallyResolvedIds.add(message.id);
      setState(() => smsMessages.removeWhere((m) => m.id == message.id));
      final devicePayload = <String, dynamic>{
        'id': message.id,
        'receiver': phone,
        'text': text,
        'client_operation_id': _operationId('device_sms'),
      };
      try {
        await api.postJson('/sms_mark_device_sent.php', devicePayload);
      } catch (error) {
        if (offlineReady && _shouldQueueError(error)) {
          await offlineStore.enqueue(
            owner: username,
            type: 'sms_device_sent',
            operationId: devicePayload['client_operation_id'] as String,
            payload: devicePayload,
          );
          await _refreshPendingSyncCount();
        }
      }

      await loadSmsMessages(autoCheck: false);
      await loadSmsDashboard(silent: true);
      showSnack('ارسال با گوشی ثبت شد و از لیست ناموفق خارج شد');
    } catch (e) {
      showSnack('خطای ارسال با پیام عادی: $e');
    }
  }

  String canonicalMobile(String value) {
    var n = normalizeDigits(value).replaceAll(RegExp(r'[^0-9+]'), '');
    if (n.startsWith('+98')) n = '0${n.substring(3)}';
    if (n.startsWith('0098')) n = '0${n.substring(4)}';
    if (n.startsWith('98') && n.length == 12) n = '0${n.substring(2)}';
    return RegExp(r'^09\d{9}$').hasMatch(n) ? n : '';
  }

  bool isValidMobile(String value) => canonicalMobile(value).isNotEmpty;

  Future<List<SmsContact>> _fetchContactCandidates() async {
    try {
      final result = await api.getJson('/sms_contacts.php', query: {'exportable': '1'});
      final data = result['data'] as List? ?? [];
      return data.map((e) => SmsContact.fromJson(Map<String, dynamic>.from(e as Map))).toList();
    } catch (_) {
      return List<SmsContact>.from(smsContacts);
    }
  }

  Future<void> saveOnlyNewContactsToPhone() async {
    try {
      final granted = await FlutterContacts.requestPermission(readonly: false);
      if (!granted) return showSnack('اجازه دسترسی به مخاطبین گوشی داده نشد');
      final candidates = await _fetchContactCandidates();
      final existingContacts = await FlutterContacts.getContacts(withProperties: true);
      final existing = <String>{};
      for (final contact in existingContacts) {
        for (final phone in contact.phones) {
          final normalized = canonicalMobile(phone.number);
          if (normalized.isNotEmpty) existing.add(normalized);
        }
      }
      final unique = <String, SmsContact>{};
      for (final candidate in candidates) {
        final normalized = canonicalMobile(candidate.number);
        if (normalized.isNotEmpty) unique.putIfAbsent(normalized, () => candidate);
      }
      final onlyNew = unique.entries.where((entry) => !existing.contains(entry.key)).toList();
      if (onlyNew.isEmpty) return showSnack('همه شماره‌ها از قبل داخل همین گوشی ذخیره شده‌اند');

      var saved = 0;
      for (final entry in onlyNew) {
        final rawName = entry.value.name.trim();
        final name = rawName.isEmpty ? 'مخاطب سامانه مرسولات' : rawName.replaceAll(RegExp(r'\s+'), ' ');
        final parts = name.split(' ');
        final contact = Contact()
          ..name.first = parts.first
          ..name.last = parts.skip(1).join(' ')
          ..phones = [Phone(entry.key)];
        await contact.insert();
        saved++;
        await Future<void>.delayed(const Duration(milliseconds: 70));
      }
      try {
        await api.postJson('/sms_mark_exported.php', {
          'contacts': onlyNew.map((entry) => {'number': entry.key, 'name': entry.value.name}).toList(),
        });
      } catch (_) {}
      showSnack('${toFa(saved)} شماره جدید ذخیره شد؛ ${toFa(existing.length)} شماره تکراری عبور داده شد');
    } catch (e) {
      showSnack('ذخیره مخاطبین انجام نشد: $e');
    }
  }

  Future<void> shareVcf() async {
    final candidates = await _fetchContactCandidates();
    final filtered = <String, SmsContact>{};
    for (final contact in candidates) {
      final number = canonicalMobile(contact.number);
      if (number.isNotEmpty) filtered.putIfAbsent(number, () => contact);
    }
    if (filtered.isEmpty) return showSnack('شماره معتبری برای خروجی وجود ندارد');
    final buffer = StringBuffer();
    for (final entry in filtered.entries) {
      final name = (entry.value.name.trim().isEmpty ? 'مخاطب سامانه مرسولات' : entry.value.name.trim()).replaceAll('\n', ' ');
      buffer.write('BEGIN:VCARD\nVERSION:3.0\nFN:$name\nTEL;TYPE=CELL:${entry.key}\nEND:VCARD\n');
    }
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/sms_contacts_${DateTime.now().millisecondsSinceEpoch}.vcf');
    await file.writeAsString(buffer.toString(), encoding: utf8);
    await Share.shareXFiles([XFile(file.path)], text: 'خروجی شماره‌های پنل پیامکی');
  }

  List<Shipment> reportRows() {
    final rows = List<Shipment>.from(shipments);
    if (reportTypeIndex == 0) return rows.where((e) => e.shamsiDate == dateVal(ry, rm, rd)).toList();
    if (reportTypeIndex == 1) return rows.where((e) => e.shamsiDate.startsWith('$ry/${persianMonths[rm - 1]}/')).toList();
    return rows;
  }

  @override
  Widget build(BuildContext context) => loggedIn ? (adminMode ? buildAdminShell() : buildShell()) : buildLogin();


  int normalizedRialAmount(Object? rialValue, Object? tomanValue) {
    final toman = int.tryParse('${tomanValue ?? 0}') ?? 0;
    final rial = int.tryParse('${rialValue ?? ''}');
    return (rial != null && rial > 0) ? rial : toman * 10;
  }

  Widget buildSubscription() {
    final active = subscriptionData['active'] == true || canAdmin;
    final pending = subscriptionData['pending'] is Map ? Map<String, dynamic>.from(subscriptionData['pending'] as Map) : <String, dynamic>{};
    final sub = subscriptionData['subscription'] is Map ? Map<String, dynamic>.from(subscriptionData['subscription'] as Map) : <String, dynamic>{};
    final amountToman = int.tryParse('${pending['amount_toman'] ?? 0}') ?? 0;
    final amountRial = normalizedRialAmount(pending['amount_rial'], pending['amount_toman']);
    final price = int.tryParse('${subscriptionData['price_toman'] ?? 150000}') ?? 150000;
    final card = asText(subscriptionData['card_number']);
    final holder = asText(subscriptionData['card_holder']);
    final bank = asText(subscriptionData['bank_name']);
    return pageList(onRefresh: () => loadSubscription(silent: false), children: [
      sectionTitle('اشتراک کاربری', 'اشتراک ماهانه برای ثبت/تحویل مرسوله، اسکن و ارسال پیامک'),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [
        CircleAvatar(backgroundColor: active ? kSoftGreen : kSoftYellow, child: Icon(active ? Icons.verified_rounded : Icons.schedule_rounded, color: active ? kNavy2 : kNavy)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(active ? 'اشتراک فعال' : (pending.isNotEmpty ? 'در انتظار واریز' : 'اشتراک غیرفعال'), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
          if (active && asText(sub['ends_at']).isNotEmpty) Text('اعتبار تا: ${formatServerDateTimeShamsi(asText(sub['ends_at']))}', style: const TextStyle(color: kMuted)),
          if (!active && pending.isEmpty) Text('هزینه یک ماه: ${moneyFa(price)} تومان', style: const TextStyle(color: kMuted)),
        ])),
        if (subscriptionLoading) const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)),
      ]))),
      if (!active && pending.isEmpty) ...[
        const SizedBox(height: 8),
        SizedBox(width: double.infinity, height: 54, child: FilledButton.icon(onPressed: subscriptionLoading ? null : createPaymentRequest, icon: const Icon(Icons.credit_card_rounded), label: const Text('دریافت مبلغ یکتا و شماره کارت'))),
      ],
      if (!active && pending.isNotEmpty) ...[
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('مبلغ را دقیقاً به کارت زیر واریز کنید', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
          const SizedBox(height: 12),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.account_balance_wallet_rounded),
            title: Text('${moneyFa(amountToman)} تومان', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 22, color: kNavy)),
            subtitle: const Text('مبلغ پرداختی به تومان'),
            trailing: IconButton(
              onPressed: () { Clipboard.setData(ClipboardData(text: '$amountToman')); showSnack('مبلغ تومانی کپی شد'); },
              icon: const Icon(Icons.copy_rounded),
            ),
          ),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(color: kSoftBlue, borderRadius: BorderRadius.circular(16)),
            child: Row(children: [
              const Icon(Icons.account_balance_rounded, color: kNavy),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('معادل ریالی برای پیامک بانک', style: TextStyle(color: kMuted, fontWeight: FontWeight.w700, fontSize: 12)),
                const SizedBox(height: 3),
                Text('${moneyFa(amountRial)} ریال', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20, color: kNavy)),
              ])),
              IconButton(
                onPressed: () { Clipboard.setData(ClipboardData(text: '$amountRial')); showSnack('مبلغ ریالی کپی شد'); },
                icon: const Icon(Icons.copy_rounded),
              ),
            ]),
          ),
          const Padding(
            padding: EdgeInsets.only(top: 8, bottom: 4),
            child: Text(
              'مبلغ تومان و ریال معادل هم هستند؛ مبلغ را دقیقاً پرداخت کنید. پیامک بانک معمولاً مبلغ واریزی را به ریال نمایش می‌دهد.',
              style: TextStyle(color: kMuted, fontSize: 12, fontWeight: FontWeight.w600),
            ),
          ),
          if (card.isNotEmpty) ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.credit_card), title: Text(card, textDirection: TextDirection.ltr, style: const TextStyle(fontWeight: FontWeight.w900)), subtitle: Text([holder, bank].where((e) => e.isNotEmpty).join(' - ')), trailing: IconButton(onPressed: () { Clipboard.setData(ClipboardData(text: card)); showSnack('شماره کارت کپی شد'); }, icon: const Icon(Icons.copy_rounded))),
          const Divider(),
          Row(children: const [Icon(Icons.hourglass_top_rounded, color: kNavy), SizedBox(width: 8), Expanded(child: Text('وضعیت: Pending — پس از دریافت پیامک بانکی معتبر، اشتراک خودکار فعال می‌شود.', style: TextStyle(fontWeight: FontWeight.w700, color: kMuted)))]),
          if (asText(pending['expires_at']).isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text('مهلت پرداخت: ${formatServerDateTimeShamsi(asText(pending['expires_at']))}', style: const TextStyle(color: kDanger, fontWeight: FontWeight.w800))),
          const SizedBox(height: 10),
          SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: subscriptionLoading ? null : () => loadSubscription(silent: false), icon: const Icon(Icons.refresh_rounded), label: const Text('بررسی وضعیت واریز'))),
        ]))),
      ],
      const SizedBox(height: 8),
      const Card(child: ListTile(leading: Icon(Icons.security_rounded), title: Text('فعال‌سازی سمت سرور انجام می‌شود'), subtitle: Text('تصویر رسید باعث فعال‌سازی خودکار نمی‌شود؛ فقط پیامک بانکی معتبر و مبلغ یکتای Pending مبنای تأیید است.'))),
    ]);
  }

  Widget buildSmartScan() {
    final readyCount = scanDrafts.where((e) => e.readyToMessage).length;
    return pageList(children: [
      sectionTitle('اسکن حرفه‌ای مرسولات', 'پردازش چندمرحله‌ای رایگان با ML Kit + ZXing + OCR فارسی؛ بارکد، کدرهگیری، موبایل، نام و نوع پرداخت قبل از ثبت قابل ویرایش است.'),
      Wrap(spacing: 8, runSpacing: 8, children: [
        FilledButton.icon(onPressed: scanSingleShipment, icon: const Icon(Icons.photo_camera_rounded), label: const Text('دوربین تکی')),
        FilledButton.tonalIcon(onPressed: scanSingleShipmentFromGallery, icon: const Icon(Icons.photo_library_rounded), label: const Text('عکس از گوشی')),
        FilledButton.icon(onPressed: scanBatchShipments, icon: const Icon(Icons.collections_rounded), label: const Text('دوربین گروهی')),
        FilledButton.tonalIcon(onPressed: scanBatchShipmentsFromGallery, icon: const Icon(Icons.collections_rounded), label: const Text('گالری گروهی')),
        if (readyCount > 0 && has('sms.send')) OutlinedButton.icon(onPressed: sendAllReadyScans, icon: const Icon(Icons.send_rounded), label: Text('ارسال گروهی آماده‌ها (${toFa(readyCount)})')),
      ]),
      const SizedBox(height: 8),
      const Card(
        child: ListTile(
          leading: Icon(Icons.auto_awesome_rounded),
          title: Text('حالت حرفه‌ای رایگان'),
          subtitle: Text('بارکد با دو موتور مستقل + تصویر تقویت‌شده؛ OCR فارسی/اعداد در چند پاس. نتیجه ضعیف خودکار به‌عنوان نام معتبر پذیرفته نمی‌شود.'),
        ),
      ),
      const SizedBox(height: 10),
      if (scanDrafts.isEmpty) emptyBox('هنوز مرسوله‌ای اسکن نشده است'),
      ...scanDrafts.asMap().entries.map((entry) {
        final i = entry.key;
        final d = entry.value;
        return Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.file(File(d.file.path), width: 82, height: 82, fit: BoxFit.cover)),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('مرسوله ${toFa(i + 1)}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
              Text(
                'اطمینان کلی: ${toFa((d.confidence * 100).round())}٪',
                style: TextStyle(color: d.confidence >= .80 ? kNavy2 : kDanger, fontWeight: FontWeight.w800),
              ),
              if (d.needsReview)
                const Padding(
                  padding: EdgeInsets.only(top: 3),
                  child: Text('نیاز به بررسی دستی', style: TextStyle(color: kDanger, fontWeight: FontWeight.w900)),
                ),
              if (d.barcodes.isNotEmpty)
                Text('بارکد Decode شده: ${d.barcodes.first}', maxLines: 2, overflow: TextOverflow.ellipsis, textDirection: TextDirection.ltr),
            ])),
          ]),
          const SizedBox(height: 10),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              Chip(label: Text('نام ${toFa((d.nameConfidence * 100).round())}٪')),
              Chip(label: Text('موبایل ${toFa((d.phoneConfidence * 100).round())}٪')),
              Chip(label: Text('رهگیری ${toFa((d.trackingConfidence * 100).round())}٪')),
              if (d.paymentType.isNotEmpty) Chip(label: Text('نوع مالی ${toFa((d.paymentConfidence * 100).round())}٪')),
            ],
          ),
          if (d.warnings.isNotEmpty) ...[
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: kSoftYellow, borderRadius: BorderRadius.circular(14)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: d.warnings.map((w) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Text('• $w', style: const TextStyle(color: kDanger, fontWeight: FontWeight.w700, fontSize: 12)),
                )).toList(),
              ),
            ),
          ],
          const SizedBox(height: 8),
          TextFormField(initialValue: d.fullname, decoration: const InputDecoration(labelText: 'نام و نام خانوادگی گیرنده'), onChanged: (v) => setState(() => d.fullname = v.trim())),
          const SizedBox(height: 8),
          TextFormField(initialValue: d.phone, keyboardType: TextInputType.phone, inputFormatters: numberInputFormatters, decoration: const InputDecoration(labelText: 'شماره گیرنده'), onChanged: (v) => setState(() => d.phone = normalizeDigits(v).replaceAll(RegExp(r'[^0-9]'), ''))),
          const SizedBox(height: 8),
          TextFormField(initialValue: d.trackingCode, decoration: const InputDecoration(labelText: 'بارکد / کدرهگیری'), onChanged: (v) => d.trackingCode = normalizeDigits(v).trim()),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(value: ['کرایه در مقصد', 'پرداخت در محل', ''].contains(d.paymentType) ? d.paymentType : '', decoration: const InputDecoration(labelText: 'نوع مالی'), items: const [DropdownMenuItem(value: '', child: Text('نامشخص')), DropdownMenuItem(value: 'کرایه در مقصد', child: Text('کرایه در مقصد')), DropdownMenuItem(value: 'پرداخت در محل', child: Text('پرداخت در محل'))], onChanged: (v) => setState(() => d.paymentType = v ?? '')),
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: [
            if (has('shipment.create')) FilledButton.tonalIcon(onPressed: () => registerScannedDraft(d), icon: const Icon(Icons.add_box_rounded), label: const Text('ثبت مرسوله')),
            if (d.readyToMessage && has('sms.send')) FilledButton.icon(onPressed: () => sendScannedDraftMessage(d), icon: const Icon(Icons.send_rounded), label: const Text('ارسال پیام')),
            if (!d.readyToMessage) const Chip(avatar: Icon(Icons.info_outline_rounded, size: 18), label: Text('برای ارسال، نام + موبایل معتبر لازم است')),
          ]),
        ])));
      }),
    ]);
  }

  Widget adminActionStatCard(String title, Object value, IconData icon, int page, {String? hint}) => Card(
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => openAdminPage(page),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Icon(icon, color: Theme.of(context).colorScheme.primary),
                const Spacer(),
                const Icon(Icons.chevron_left_rounded, color: kMuted),
              ]),
              const Spacer(),
              Text(toFa(value), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
              Text(title, style: TextStyle(color: Colors.blueGrey.shade600, fontWeight: FontWeight.bold)),
              if (hint != null) Text(hint, style: const TextStyle(color: kMuted, fontSize: 11)),
            ]),
          ),
        ),
      );

  Widget buildAdminDashboard() {
    return pageList(onRefresh: () => loadAdminStats(), children: [
      sectionTitle('مرکز مدیریت', 'روی هر کارت بزنید تا مستقیماً وارد بخش مدیریتی مربوط شوید.'),
      GridView.count(
        crossAxisCount: MediaQuery.sizeOf(context).width > 720 ? 4 : 2,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        childAspectRatio: 1.25,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
        children: [
          adminActionStatCard('کاربران', adminStats['users'] ?? 0, Icons.people_alt_rounded, 1),
          adminActionStatCard('مرسولات', adminStats['shipments'] ?? 0, Icons.inventory_2_rounded, 6),
          adminActionStatCard('پیام‌ها', adminStats['sms'] ?? 0, Icons.sms_rounded, 7),
          adminActionStatCard('شماره‌های یکتا', adminStats['unique_phones'] ?? 0, Icons.contacts_rounded, 2),
          adminActionStatCard('اسکن‌ها', adminStats['scans'] ?? 0, Icons.document_scanner_rounded, 4, hint: 'مشاهده در لاگ عملیات'),
          adminActionStatCard('اشتراک فعال', adminStats['active_subscriptions'] ?? 0, Icons.workspace_premium_rounded, 3),
          adminActionStatCard('پرداخت Pending', adminStats['pending_payments'] ?? 0, Icons.hourglass_top_rounded, 3),
          adminActionStatCard('تحویل‌شده', adminStats['delivered'] ?? 0, Icons.task_alt_rounded, 6),
        ],
      ),
      const SizedBox(height: 12),
      sectionTitle('عملیات مدیریت'),
      Card(child: Column(children: [
        ListTile(leading: const Icon(Icons.manage_accounts_rounded), title: const Text('کاربران و سطح دسترسی'), trailing: const Icon(Icons.chevron_left_rounded), onTap: () => openAdminPage(1)),
        const Divider(height: 1),
        ListTile(leading: const Icon(Icons.payments_rounded), title: const Text('اشتراک، کارت و پرداخت‌ها'), trailing: const Icon(Icons.chevron_left_rounded), onTap: () => openAdminPage(3)),
        const Divider(height: 1),
        ListTile(leading: const Icon(Icons.inventory_2_rounded), title: const Text('مدیریت همه مرسولات'), trailing: const Icon(Icons.chevron_left_rounded), onTap: () => openAdminPage(6)),
        const Divider(height: 1),
        ListTile(leading: const Icon(Icons.mark_chat_read_rounded), title: const Text('مدیریت همه پیام‌ها'), trailing: const Icon(Icons.chevron_left_rounded), onTap: () => openAdminPage(7)),
        const Divider(height: 1),
        ListTile(leading: const Icon(Icons.contacts_rounded), title: const Text('استخراج شماره‌ها'), trailing: const Icon(Icons.chevron_left_rounded), onTap: () => openAdminPage(2)),
        const Divider(height: 1),
        ListTile(leading: const Icon(Icons.receipt_long_rounded), title: const Text('لاگ کامل عملیات'), trailing: const Icon(Icons.chevron_left_rounded), onTap: () => openAdminPage(4)),
        const Divider(height: 1),
        ListTile(leading: const Icon(Icons.key_rounded), title: const Text('کلمات و قالب‌های پیامک'), trailing: const Icon(Icons.chevron_left_rounded), onTap: () => openAdminPage(5)),
      ])),
    ]);
  }

  Widget buildAdminPayments() {
    final enabledFuture = secureStore.read(key: 'bank_listener_enabled');
    return pageList(onRefresh: () => loadAdminPayments(), children: [
      sectionTitle('اشتراک و پرداخت‌ها', 'کارت‌به‌کارت با مبلغ یکتا و تأیید خودکار از پیامک بانکی دستگاه مدیر'),
      Wrap(spacing: 8, runSpacing: 8, children: [
        FilledButton.icon(onPressed: savePaymentSettingsDialog, icon: const Icon(Icons.settings_rounded), label: const Text('تنظیمات کارت و بانک')),
        FilledButton.icon(onPressed: enableBankListener, icon: const Icon(Icons.sms_rounded), label: const Text('فعال‌سازی Listener بانکی')),
        OutlinedButton.icon(onPressed: disableBankListener, icon: const Icon(Icons.sms_failed_rounded), label: const Text('غیرفعال‌سازی Listener')),
      ]),
      FutureBuilder<String?>(future: enabledFuture, builder: (context, snap) => Card(child: ListTile(leading: Icon(snap.data == '1' ? Icons.verified_rounded : Icons.warning_amber_rounded, color: snap.data == '1' ? kNavy2 : kDanger), title: Text(snap.data == '1' ? 'Listener بانکی این گوشی فعال است' : 'Listener بانکی این گوشی فعال نیست'), subtitle: const Text('فقط دستگاه ثبت‌شده مدیر اجازه ارسال پیامک بانکی برای تطبیق پرداخت را دارد.')))),
      if (paymentSettings.isNotEmpty) Card(child: ListTile(leading: const Icon(Icons.credit_card_rounded), title: Text('${asText(paymentSettings['card_number'], 'شماره کارت تنظیم نشده')}'), subtitle: Text('${asText(paymentSettings['card_holder'])} | ${asText(paymentSettings['bank_name'])}\nاشتراک: ${toFa(paymentSettings['subscription_price_toman'] ?? '150000')} تومان'))),
      sectionTitle('پرداخت‌های اخیر'),
      if (adminPayments.isEmpty) emptyBox('پرداختی ثبت نشده است'),
      ...adminPayments.take(100).map((p) => Card(child: ListTile(
        leading: Icon(asText(p['status']) == 'paid' ? Icons.check_circle_rounded : (asText(p['status']) == 'pending' ? Icons.hourglass_top_rounded : Icons.cancel_outlined), color: asText(p['status']) == 'paid' ? kNavy2 : kNavy),
        title: Text('${asText(p['username'])} | ${moneyFa(p['amount_toman'] ?? 0)} تومان', style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text('معادل: ${moneyFa(normalizedRialAmount(p['amount_rial'], p['amount_toman']))} ریال\nوضعیت: ${asText(p['status'])}\nساخته‌شده: ${formatServerDateTimeShamsi(asText(p['created_at']))}${asText(p['subscription_ends_at']).isNotEmpty ? '\nاشتراک تا: ${formatServerDateTimeShamsi(asText(p['subscription_ends_at']))}' : ''}'),
        isThreeLine: true,
        trailing: asText(p['status']) == 'pending' ? IconButton(onPressed: () => manualActivatePayment(int.tryParse('${p['id']}') ?? 0), icon: const Icon(Icons.verified_user_rounded), tooltip: 'تأیید دستی') : null,
      ))),
      sectionTitle('پیامک‌های بانکی اخیر'),
      if (bankSmsEvents.isEmpty) emptyBox('پیامک بانکی ثبت نشده است'),
      ...bankSmsEvents.take(50).map((e) => Card(child: ListTile(leading: Icon(asText(e['status']) == 'matched' ? Icons.link_rounded : Icons.link_off_rounded, color: asText(e['status']) == 'matched' ? kNavy2 : kDanger), title: Text('${asText(e['sender'])} | ${asText(e['status'])}'), subtitle: Text(asText(e['body']), maxLines: 3, overflow: TextOverflow.ellipsis)))),
    ]);
  }

  Widget buildAdminShell() {
    final pages = [buildAdminDashboard(), buildUsers(), buildSmsContacts(), buildAdminPayments(), buildLogs(), buildSmsTemplates(), buildShipmentList(), buildSmsMessages()];
    const titles = ['مرکز مدیریت', 'کاربران و دسترسی‌ها', 'استخراج شماره‌ها', 'اشتراک و پرداخت‌ها', 'لاگ عملیات', 'کلمات پیامک', 'همه مرسولات', 'همه پیام‌ها'];
    return WillPopScope(
      onWillPop: () async { setState(() => adminMode = false); return false; },
      child: Scaffold(
        appBar: AppBar(
          title: Text(titles[adminPageIndex], style: const TextStyle(fontWeight: FontWeight.w900)),
          leading: Builder(
            builder: (context) => IconButton(
              onPressed: () => Scaffold.of(context).openDrawer(),
              icon: const Icon(Icons.menu_rounded),
              tooltip: 'منوی مدیریت',
            ),
          ),
          actions: [
            IconButton(
              onPressed: () => setState(() => adminMode = false),
              icon: const Icon(Icons.arrow_back_rounded),
              tooltip: 'بازگشت به پنل کاربری',
            ),
          ],
        ),
        drawer: Drawer(child: SafeArea(child: ListView(padding: EdgeInsets.zero, children: [
          const DrawerHeader(decoration: BoxDecoration(gradient: LinearGradient(colors: [kNavy, kNavy2])), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.admin_panel_settings_rounded, size: 44, color: Colors.white), Spacer(), Text('پنل مدیریت مستقل', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18))])),
          _adminDrawerItem(0, Icons.dashboard_customize_rounded, 'مرکز مدیریت'),
          _adminDrawerItem(1, Icons.manage_accounts_rounded, 'کاربران و دسترسی‌ها'),
          _adminDrawerItem(2, Icons.contacts_rounded, 'استخراج شماره‌ها'),
          _adminDrawerItem(3, Icons.payments_rounded, 'اشتراک و پرداخت‌ها'),
          _adminDrawerItem(6, Icons.inventory_2_rounded, 'همه مرسولات'),
          _adminDrawerItem(7, Icons.mark_chat_read_rounded, 'همه پیام‌ها'),
          _adminDrawerItem(5, Icons.key_rounded, 'کلمات پیامک'),
          _adminDrawerItem(4, Icons.receipt_long_rounded, 'لاگ عملیات'),
          const Divider(),
          ListTile(leading: const Icon(Icons.home_rounded), title: const Text('بازگشت به پنل کاربری'), onTap: () { Navigator.pop(context); setState(() => adminMode = false); }),
        ]))),
        body: SafeArea(child: pages[adminPageIndex]),
      ),
    );
  }

  Widget _adminDrawerItem(int index, IconData icon, String title) => ListTile(selected: adminPageIndex == index, leading: Icon(icon), title: Text(title), onTap: () => openAdminPage(index, closeDrawer: true));

  Widget buildLogin() {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(gradient: LinearGradient(colors: [kSoftBlue, kSoftGreen, kSurface])),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(18),
              child: Card(
                elevation: 18,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                child: Padding(
                  padding: const EdgeInsets.all(22),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Text('📮✉️', style: TextStyle(fontSize: 50)),
                    const SizedBox(height: 8),
                    const Text('ورود به سامانه', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 6),
                    Text('مرسولات + پنل پیامکی آنلاین', style: TextStyle(color: Colors.blueGrey.shade600)),
                    const SizedBox(height: 18),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xffeef2ff),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: const Color(0xffc7d2fe)),
                      ),
                      child: const Text('اتصال به سرور اصلی فعال است', textAlign: TextAlign.center),
                    ),
                    const SizedBox(height: 12),
                    TextField(controller: loginUserController, decoration: const InputDecoration(labelText: 'نام کاربری')),
                    const SizedBox(height: 12),
                    TextField(controller: loginPassController, obscureText: true, decoration: const InputDecoration(labelText: 'رمز عبور')),
                    const SizedBox(height: 8),
                    CheckboxListTile(value: rememberMe, onChanged: (v) => setState(() => rememberMe = v ?? true), title: const Text('مرا به خاطر بسپار'), controlAffinity: ListTileControlAffinity.leading, contentPadding: EdgeInsets.zero),
                    const SizedBox(height: 8),
                    SizedBox(width: double.infinity, height: 52, child: FilledButton(onPressed: loading ? null : login, child: loading ? const CircularProgressIndicator() : const Text('ورود'))),
                  ]),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget buildShell() {
    final pages = [
      buildShipmentForm(), buildShipmentList(), buildSmsSend(), buildSmsMessages(), buildSmsContacts(), buildDashboard(), buildReport(), buildUsers(), buildLogs(), buildSmsTemplates(), buildSmsInbox(), buildSubscription(), buildSmartScan()
    ];
    const titles = ['ثبت مرسوله', 'مرسولات حوزه من', 'ارسال پیامک', 'پیام‌های حوزه من', 'استخراج شماره‌ها', 'داشبورد من', 'گزارش مرسولات', 'کاربران', 'لاگ‌ها', 'کلمات پیامک', 'پیام‌های دریافتی من', 'اشتراک', 'اسکن هوشمند'];
    return WillPopScope(
      onWillPop: onBackPressed,
      child: Scaffold(
        appBar: AppBar(
          title: Text(titles[pageIndex], style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
          actions: [
            Center(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 8), child: Text(username, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800)))),
            IconButton(onPressed: requestLogout, icon: const Icon(Icons.logout), tooltip: 'خروج'),
          ],
        ),
        drawer: Drawer(child: SafeArea(child: buildDrawer())),
        body: Container(color: kSoftBg, child: SafeArea(child: Column(children: [if (availableUpdate != null) updateBanner(availableUpdate!), Expanded(child: pages[pageIndex])]))),
        floatingActionButton: pageIndex == 11 ? null : Row(mainAxisSize: MainAxisSize.min, children: [
          if (pageIndex != 2 && has('sms.send')) FloatingActionButton.extended(heroTag: 'quick_sms', onPressed: () => openPage(2), icon: const Icon(Icons.send_rounded), label: const Text('پیام')),
          if (pageIndex != 2 && has('sms.send') && pageIndex != 0 && has('shipment.create')) const SizedBox(width: 8),
          if (pageIndex != 0 && has('shipment.create')) FloatingActionButton.extended(heroTag: 'quick_ship', onPressed: () => openPage(0), icon: const Icon(Icons.add_box_outlined), label: const Text('مرسوله')),
        ]),
      ),
    );
  }


  Widget updateBanner(AppUpdateInfo info) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: () => showUpdateDialog(info),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [kSoftBlue, kSoftGreen]),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: kBorder),
            ),
            child: Row(children: [
              const Icon(Icons.system_update_alt, color: kNavy),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('آپدیت جدید ${info.versionName}', style: const TextStyle(fontWeight: FontWeight.w900)),
                  const Text('برای نصب، روی این باکس بزنید. حذف نسخه قبلی لازم نیست.', style: TextStyle(fontSize: 12)),
                ]),
              ),
              const Icon(Icons.chevron_left, color: kNavy),
            ]),
          ),
        ),
      );

  Widget buildDrawer() {
    Widget item(int index, IconData icon, String title) => ListTile(
          selected: pageIndex == index,
          leading: Icon(icon),
          title: Text(title),
          onTap: () => openPage(index, closeDrawer: true),
        );
    return ListView(padding: EdgeInsets.zero, children: [
      DrawerHeader(
        decoration: const BoxDecoration(gradient: LinearGradient(colors: [kNavy, kNavy2, Color(0xff67e8f9)])),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('📮✉️', style: TextStyle(fontSize: 42)),
          const Spacer(),
          Text(username, style: const TextStyle(color: kSurface, fontWeight: FontWeight.w900, fontSize: 18)),
          Text(roleLabel, style: const TextStyle(color: kSoftBlue)),
          Text(workScope == 'village' && villageName.isNotEmpty ? 'روستا: $villageName' : 'حوزه: شهرستان اصلی', style: const TextStyle(color: kSoftGreen, fontSize: 12, fontWeight: FontWeight.w700)),
        ]),
      ),
      if (has('dashboard.view') || has('sms.view')) item(5, Icons.dashboard_rounded, 'داشبورد من'),
      if (has('shipment.create')) item(0, Icons.add_circle_rounded, 'ثبت مرسوله'),
      if (has('shipment.view')) item(1, Icons.inventory_2_rounded, 'مرسولات من'),
      if (has('shipment.scan')) item(12, Icons.document_scanner_rounded, 'اسکن هوشمند'),
      const Divider(),
      if (has('sms.send')) item(2, Icons.send_rounded, 'ارسال پیامک'),
      if (has('sms.view')) item(3, Icons.mark_chat_read_rounded, 'پیام‌های من'),
      if (has('sms.view')) item(10, Icons.inbox_rounded, 'پیام‌های دریافتی حوزه'),
      if (has('sms.send')) item(9, Icons.key_rounded, 'کلمات پیامک من'),
      const Divider(),
      item(11, Icons.workspace_premium_rounded, 'اشتراک'),
      if (has('report.view')) item(6, Icons.bar_chart_rounded, 'گزارش من'),
      const Divider(),
      ListTile(
        leading: const Icon(Icons.info_outline_rounded),
        title: Text('نسخه $kAppVersionName'),
        subtitle: const Text('اطلاعات نسخه برنامه'),
        onTap: onVersionTap,
      ),
      ListTile(leading: const Icon(Icons.system_update_alt), title: const Text('بررسی آپدیت'), onTap: () async { if (Navigator.of(context).canPop()) Navigator.of(context).pop(); await Future<void>.delayed(const Duration(milliseconds: 120)); checkForAppUpdate(manual: true); }),
      ListTile(leading: const Icon(Icons.logout), title: const Text('خروج'), onTap: () async { if (Navigator.of(context).canPop()) Navigator.of(context).pop(); await Future<void>.delayed(const Duration(milliseconds: 120)); await requestLogout(); }),
    ]);
  }


  Widget offlineSyncBanner() {
    if (!offlineReady || (networkAvailable && pendingSyncCount == 0 && !syncingOffline)) return const SizedBox.shrink();
    final title = !networkAvailable
        ? 'حالت آفلاین فعال است'
        : (syncingOffline ? 'همگام‌سازی مرحله‌ای در حال انجام است' : '${toFa(pendingSyncCount)} عملیات در صف همگام‌سازی');
    final subtitle = !networkAvailable
        ? 'مرسولات و پیام‌ها در گوشی نگه داشته می‌شوند و پس از اتصال، آرام‌آرام ارسال می‌شوند.'
        : 'هر بار حداکثر دو عملیات با فاصله زمانی فرستاده می‌شود تا فشار و خطا ایجاد نشود.';
    return Card(
      color: kSoftYellow,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(!networkAvailable ? Icons.cloud_off_rounded : Icons.sync_rounded, color: kNavy),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: kText)),
            const SizedBox(height: 3),
            Text(subtitle, style: const TextStyle(color: kMuted, height: 1.45)),
          ])),
          const SizedBox(width: 6),
          IconButton(
            tooltip: 'همگام‌سازی',
            onPressed: syncingOffline ? null : () => _syncOfflineQueue(manual: true),
            icon: syncingOffline ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.refresh_rounded),
          ),
        ]),
      ),
    );
  }

  Widget pageList({required List<Widget> children, Future<void> Function()? onRefresh}) {
    final bottomPadding = activeNumberPadController == null ? 16.0 : 330.0;
    final pageChildren = <Widget>[
      if (loggedIn && offlineReady && (!networkAvailable || pendingSyncCount > 0 || syncingOffline)) offlineSyncBanner(),
      ...children,
    ];
    final list = ListView(padding: EdgeInsets.fromLTRB(16, 16, 16, bottomPadding), children: pageChildren);
    final content = onRefresh == null ? list : RefreshIndicator(onRefresh: onRefresh, child: list);
    return Stack(children: [
      content,
      if (activeNumberPadController != null) Positioned(left: 0, right: 0, bottom: 0, child: buildRightHandNumberPad()),
    ]);
  }

  Widget sectionTitle(String title, [String? subtitle]) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 12, 4, 8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          if (subtitle != null) Text(subtitle, style: TextStyle(color: Colors.blueGrey.shade600)),
        ]),
      );

  Widget statCard(String title, Object value, IconData icon) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(icon, color: Theme.of(context).colorScheme.primary),
            const Spacer(),
            Text(toFa(value), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
            Text(title, style: TextStyle(color: Colors.blueGrey.shade600, fontWeight: FontWeight.bold)),
          ]),
        ),
      );

  Widget buildDashboard() {
    final d = dashboard;
    final s = smsStats;
    return pageList(onRefresh: () async { await loadDashboard(); await loadSmsDashboard(); }, children: [
      sectionTitle('داشبورد', 'خلاصه مرسولات و پیامک‌ها'),
      GridView.count(
        crossAxisCount: MediaQuery.sizeOf(context).width > 720 ? 4 : 2,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        childAspectRatio: 1.35,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        children: [
          statCard('کل مرسولات', d?.total ?? 0, Icons.inventory_2),
          statCard('مرسولات امروز', d?.today ?? 0, Icons.today),
          statCard('کل پیامک‌های حوزه', s?.total ?? 0, Icons.sms),
          statCard('ناموفق‌های من', s?.ownFailed ?? 0, Icons.sms_failed_rounded),
        ],
      ),
      if (dashboardFailedMessages.isNotEmpty) ...[
        const SizedBox(height: 10),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('پیام‌های ناموفق من: ${toFa(dashboardFailedMessages.length)}', style: const TextStyle(fontWeight: FontWeight.w900, color: kDanger)),
              const SizedBox(height: 8),
              Wrap(spacing: 8, runSpacing: 8, children: [
                OutlinedButton.icon(
                  onPressed: () => copyFailedNumbers(dashboardFailedMessages),
                  icon: const Icon(Icons.copy_all_rounded),
                  label: const Text('کپی گروهی شماره‌ها'),
                ),
                FilledButton.tonalIcon(
                  onPressed: () => markFailedMessagesSuccess(dashboardFailedMessages),
                  icon: const Icon(Icons.task_alt_rounded),
                  label: const Text('همه را موفق کن'),
                ),
              ]),
              const Divider(height: 22),
              ...dashboardFailedMessages.take(20).map((m) => ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.error_outline_rounded, color: kDanger),
                title: Text(m.fullName.isNotEmpty ? m.fullName : m.receiver, style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text('${m.receiver}${m.groupTitle.isNotEmpty ? ' | ${m.groupTitle}' : ''}', textDirection: TextDirection.rtl),
                trailing: IconButton(
                  tooltip: 'موفق شد',
                  onPressed: () => markFailedMessagesSuccess([m]),
                  icon: const Icon(Icons.check_circle_outline_rounded),
                ),
              )),
              if (dashboardFailedMessages.length > 20)
                TextButton.icon(onPressed: () { setState(() { pageIndex = 3; smsFailedOnly = true; }); loadSmsMessages(autoCheck: false); }, icon: const Icon(Icons.list_alt_rounded), label: const Text('نمایش همه ناموفق‌ها')),
            ]),
          ),
        ),
      ],
      const SizedBox(height: 8),
      Card(child: ListTile(leading: const Icon(Icons.sync_rounded), title: const Text('ذخیره آنلاین و آفلاین فعال است'), subtitle: const Text('مرسولات و عملیات پیامک ابتدا در گوشی هم نگه داشته می‌شوند و بعد از اتصال، مرحله‌ای با سرور همگام می‌شوند.'))),
      if (d?.latest.isNotEmpty == true) ...[
        sectionTitle('آخرین مرسولات'),
        ...d!.latest.map((e) => Card(child: ListTile(title: Text(e.fullname), subtitle: Text('${e.trackingCode}\n${e.phone}'), isThreeLine: true, leading: shipmentThumbs(e), onTap: () => openPage(1)))).toList(),
      ],
    ]);
  }

  Widget buildShipmentList() {
    if (!has('shipment.view')) return noAccess();
    return pageList(onRefresh: loadShipments, children: [
      sectionTitle(
        shipmentTodayOnly ? 'مرسولات ثبت‌شده امروز' : 'همه مرسولات ثبت‌شده',
        shipmentTodayOnly ? 'نمایش فقط امروز فعال است؛ برای دیدن سوابق، آن را خاموش کنید.' : 'سوابق اخیر مرسولات نمایش داده می‌شود؛ جستجو روی همه اطلاعات انجام می‌شود.',
      ),
      FilterChip(
        selected: shipmentTodayOnly,
        avatar: Icon(shipmentTodayOnly ? Icons.today_rounded : Icons.list_alt_rounded, size: 18),
        label: Text(shipmentTodayOnly ? 'فقط مرسولات امروز' : 'نمایش همه مرسولات'),
        onSelected: (value) {
          setState(() => shipmentTodayOnly = value);
          loadShipments();
        },
      ),
      const SizedBox(height: 8),
      TextField(
        controller: searchController,
        decoration: InputDecoration(prefixIcon: const Icon(Icons.search), labelText: 'جستجو در مرسولات', suffixIcon: IconButton(icon: const Icon(Icons.refresh), onPressed: loadShipments)),
        onChanged: (_) {
          searchDebounce?.cancel();
    smsNameLookupDebounce?.cancel();
    subscriptionPollTimer?.cancel();
          searchDebounce = Timer(const Duration(milliseconds: 800), loadShipments);
        },
      ),
      const SizedBox(height: 10),
      if (shipments.isEmpty) emptyBox('مرسوله‌ای پیدا نشد'),
      ...shipments.map((s) => Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  shipmentThumbs(s),
                  const SizedBox(width: 10),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [Expanded(child: Text(s.fullname, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16))), Chip(label: Text(statusText[s.status] ?? s.status))]),
                    Text('کد: ${s.trackingCode}'),
                    if (s.phone.isNotEmpty) Text('تلفن: ${s.phone}'),
                    Text('نوع: ${s.shipmentType} | تاریخ: ${s.shamsiDate}'),
                    if (s.createdBy.isNotEmpty) Text('ثبت‌کننده: ${s.createdBy}', style: const TextStyle(color: kMuted, fontSize: 12)),
                    if (s.receiverInfo.isNotEmpty) Text(s.receiverInfo),
                  ])),
                ]),
                Wrap(spacing: 6, runSpacing: 6, children: [
                  if (has('shipment.status') && s.status != 'delivered') TextButton.icon(onPressed: () => markShipmentDelivered(s), icon: const Icon(Icons.check_circle_rounded), label: const Text('تحویل به گیرنده')),
                  if (has('shipment.edit')) TextButton.icon(onPressed: () => editShipment(s), icon: const Icon(Icons.edit), label: const Text('ویرایش')),
                  if (has('shipment.delete')) TextButton.icon(onPressed: () => deleteShipment(s), icon: const Icon(Icons.delete), label: const Text('حذف')),
                ]),
              ]),
            ),
          )),
    ]);
  }


  Widget secureImage(String src, {double? width, double? height, BoxFit fit = BoxFit.cover}) {
    return FutureBuilder<Uint8List>(
      future: api.imageBytes(src),
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return Container(
            width: width,
            height: height,
            alignment: Alignment.center,
            color: kSoftBlue.withOpacity(0.35),
            child: const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
          );
        }
        if (snapshot.hasError || !snapshot.hasData) {
          return Container(
            width: width,
            height: height,
            alignment: Alignment.center,
            color: kSoftBlue.withOpacity(0.35),
            child: const Icon(Icons.broken_image_outlined, color: kMuted),
          );
        }
        return Image.memory(snapshot.data!, width: width, height: height, fit: fit);
      },
    );
  }

  Widget shipmentThumbs(Shipment shipment) {
    if (shipment.images.isEmpty) {
      return Container(
        width: 74,
        height: 74,
        decoration: BoxDecoration(color: kSoftBlue.withOpacity(0.35), borderRadius: BorderRadius.circular(16)),
        child: const Icon(Icons.image_not_supported_outlined, color: kMuted),
      );
    }
    final first = shipment.images.first;
    return GestureDetector(
      onTap: () => showShipmentImages(shipment),
      child: Stack(children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: secureImage(first, width: 74, height: 74, fit: BoxFit.cover),
        ),
        if (shipment.images.length > 1)
          Positioned(
            left: 4,
            bottom: 4,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(color: kNavy.withOpacity(0.55), borderRadius: BorderRadius.circular(10)),
              child: Text('+${toFa(shipment.images.length - 1)}', style: const TextStyle(color: Colors.white, fontSize: 11)),
            ),
          ),
      ]),
    );
  }

  void showShipmentImages(Shipment shipment) {
    if (shipment.images.isEmpty) return;
    showDialog(
      context: context,
      builder: (context) => Dialog(
        insetPadding: const EdgeInsets.all(12),
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(children: [
              Expanded(child: Text(shipment.fullname, style: const TextStyle(fontWeight: FontWeight.w900))),
              IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close)),
            ]),
            SizedBox(
              height: MediaQuery.sizeOf(context).height * 0.65,
              child: PageView(
                children: shipment.images.map((img) => InteractiveViewer(
                  child: Center(child: secureImage(img, fit: BoxFit.contain)),
                )).toList(),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget selectedPhotoPreview() {
    if (selectedPhotos.isEmpty) return const SizedBox.shrink();
    return SizedBox(
      height: 92,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: selectedPhotos.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) => Stack(children: [
          ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.memory(selectedPhotos[i].bytes, width: 92, height: 92, fit: BoxFit.cover)),
          Positioned(
            top: 2,
            left: 2,
            child: InkWell(
              onTap: () => setState(() => selectedPhotos.removeAt(i)),
              child: Container(decoration: BoxDecoration(color: kNavy.withOpacity(0.42), shape: BoxShape.circle), padding: const EdgeInsets.all(3), child: const Icon(Icons.close, color: Colors.white, size: 16)),
            ),
          ),
        ]),
      ),
    );
  }


  Widget mediaPickButton({required String label, required IconData icon, required Color color, required VoidCallback onPressed}) =>
      SizedBox(
        width: 154,
        height: 58,
        child: FilledButton.tonalIcon(
          onPressed: onPressed,
          style: FilledButton.styleFrom(
            backgroundColor: color.withOpacity(0.14),
            foregroundColor: color,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(18),
              side: BorderSide(color: color.withOpacity(0.28)),
            ),
          ),
          icon: Icon(icon, size: 26, color: color),
          label: Text(label, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
        ),
      );

  Widget buildShipmentForm() {
    if (!has('shipment.create')) return noAccess();
    return pageList(children: [
      sectionTitle(editingShipmentId == null ? 'ثبت سریع مرسوله' : 'ویرایش مرسوله', 'این صفحه، صفحه اصلی برنامه است.'),
      TextField(controller: fullnameController, decoration: const InputDecoration(labelText: 'نام و نام خانوادگی گیرنده')),
      const SizedBox(height: 10),
      appNumberField(controller: phoneController, label: 'شماره تماس', doneLabel: 'تأیید', onDone: closeNumberPad),
      const SizedBox(height: 10),
      DropdownButtonFormField<String>(value: shipmentType, decoration: const InputDecoration(labelText: 'نوع مرسوله'), items: shipmentTypes.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setState(() => shipmentType = v ?? shipmentTypes.first)),
      const SizedBox(height: 10),
      TextField(controller: receiverController, minLines: 3, maxLines: 5, decoration: const InputDecoration(labelText: 'اطلاعات گیرنده / توضیحات')),
      const SizedBox(height: 10),
      buildDatePicker('تاریخ شمسی', jy, jm, jd, (y, m, d) => setState(() { jy = y; jm = m; jd = d; })),
      const SizedBox(height: 10),
      Center(
        child: Wrap(
          alignment: WrapAlignment.center,
          crossAxisAlignment: WrapCrossAlignment.center,
          spacing: 12,
          runSpacing: 12,
          children: [
            mediaPickButton(label: 'دوربین', icon: Icons.add_a_photo_rounded, color: const Color(0xff00a8e8), onPressed: pickFromCamera),
            mediaPickButton(label: 'انتخاب از گوشی', icon: Icons.photo_library_rounded, color: const Color(0xff16b886), onPressed: pickFromGallery),
            if (selectedPhotos.isNotEmpty) mediaPickButton(label: 'حذف عکس‌ها', icon: Icons.delete_sweep_rounded, color: kDanger, onPressed: () => setState(selectedPhotos.clear)),
          ],
        ),
      ),
      const SizedBox(height: 10),
      selectedPhotoPreview(),
      const SizedBox(height: 16),
      SizedBox(width: double.infinity, height: 52, child: FilledButton(onPressed: saving ? null : saveShipment, child: saving ? const CircularProgressIndicator() : const Text('ذخیره مرسوله'))),
    ]);
  }

  Widget buildDatePicker(String title, int y, int m, int d, void Function(int, int, int) onChanged) => Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: DropdownButtonFormField<int>(value: y, items: List.generate(8, (i) => 1403 + i).map((e) => DropdownMenuItem(value: e, child: Text(toFa(e)))).toList(), onChanged: (v) => onChanged(v ?? y, m, d), decoration: const InputDecoration(labelText: 'سال'))),
              const SizedBox(width: 8),
              Expanded(child: DropdownButtonFormField<int>(value: m, items: List.generate(12, (i) => i + 1).map((e) => DropdownMenuItem(value: e, child: Text(persianMonths[e - 1]))).toList(), onChanged: (v) => onChanged(y, v ?? m, d), decoration: const InputDecoration(labelText: 'ماه'))),
              const SizedBox(width: 8),
              Expanded(child: DropdownButtonFormField<int>(value: d, items: List.generate(31, (i) => i + 1).map((e) => DropdownMenuItem(value: e, child: Text(toFa(e)))).toList(), onChanged: (v) => onChanged(y, m, v ?? d), decoration: const InputDecoration(labelText: 'روز'))),
            ]),
          ]),
        ),
      );

  Widget buildReport() {
    if (!has('report.view')) return noAccess();
    final rows = reportRows();
    return pageList(children: [
      sectionTitle('گزارش مرسولات'),
      SegmentedButton<int>(segments: const [ButtonSegment(value: 0, label: Text('روزانه')), ButtonSegment(value: 1, label: Text('ماهانه')), ButtonSegment(value: 2, label: Text('همه'))], selected: {reportTypeIndex}, onSelectionChanged: (v) => setState(() => reportTypeIndex = v.first)),
      const SizedBox(height: 10),
      if (reportTypeIndex != 2) buildDatePicker('تاریخ گزارش', ry, rm, rd, (y, m, d) => setState(() { ry = y; rm = m; rd = d; })),
      Card(child: ListTile(leading: const Icon(Icons.bar_chart), title: Text('تعداد نتیجه: ${toFa(rows.length)}'))),
      ...rows.map((e) => Card(child: ListTile(title: Text(e.fullname), subtitle: Text('${e.trackingCode} | ${e.shamsiDate}')))),
    ]);
  }

  Widget buildSmsSend() {
    if (!has('sms.send')) return noAccess();
    return pageList(children: [
      sectionTitle('ارسال پیامک', 'پیام‌ها بعد از ارسال در دیتابیس آنلاین ذخیره می‌شوند'),
      DropdownButtonFormField<String>(
        value: smsService,
        decoration: const InputDecoration(labelText: 'سرویس ارسال'),
        items: const [DropdownMenuItem(value: 'smsir', child: Text('SMS.ir')), DropdownMenuItem(value: 'melli', child: Text('ملی پیامک'))],
        onChanged: (v) => setState(() => applySmsService(v ?? 'melli')),
      ),
      const SizedBox(height: 10),
      appNumberField(controller: smsSenderController, label: 'شماره خط فرستنده', doneLabel: 'تأیید', onDone: closeNumberPad),
      const SizedBox(height: 10),
      TextField(
        controller: smsKeywordController,
        textInputAction: TextInputAction.done,
        decoration: InputDecoration(
          labelText: 'کلمه کلیدی متن / عنوان گروه',
          hintText: 'مثلاً میز1',
          suffixIcon: IconButton(icon: const Icon(Icons.auto_fix_high_rounded), onPressed: () => applySmsTemplateKeyword(smsKeywordController.text)),
        ),
        onChanged: applySmsTemplateKeyword,
      ),
      const SizedBox(height: 8),
      if (smsTemplates.isNotEmpty) Card(
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('کلمات آماده: ${toFa(smsTemplates.length)} مورد', style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: smsTemplates.map((t) => ActionChip(
                label: Text(t.keyword, overflow: TextOverflow.visible),
                onPressed: () => useSmsTemplate(t),
              )).toList(),
            ),
          ]),
        ),
      ),
      const SizedBox(height: 10),
      TextField(controller: smsGroupController, decoration: const InputDecoration(labelText: 'عنوان گروه ارسال - اختیاری')),
      const SizedBox(height: 10),
      Row(textDirection: TextDirection.rtl, children: [
        Expanded(child: appNumberField(
          controller: smsNumberLineController,
          focusNode: smsNumberLineFocus,
          label: 'شماره جدید',
          doneLabel: 'بعدی',
          onDone: submitSmsNumberLine,
          onChanged: scheduleSmsNameLookup,
        )),
        const SizedBox(width: 8),
        Expanded(child: TextField(
          controller: smsNameLineController,
          focusNode: smsNameLineFocus,
          textAlign: TextAlign.right,
          keyboardType: TextInputType.name,
          textInputAction: TextInputAction.done,
          decoration: const InputDecoration(labelText: 'نام و نام خانوادگی'),
          onTap: closeNumberPad,
          onSubmitted: (_) => submitSmsNameLine(),
        )),
      ]),
      const SizedBox(height: 8),
      SizedBox(width: double.infinity, height: 46, child: OutlinedButton.icon(onPressed: addSmsReceiverLine, icon: const Icon(Icons.add_rounded), label: const Text('افزودن به لیست گیرنده‌ها'))),
      const SizedBox(height: 10),
      TextField(controller: smsNumbersController, minLines: 5, maxLines: 10, keyboardType: TextInputType.multiline, decoration: const InputDecoration(labelText: 'لیست گیرنده‌ها', hintText: 'هر خط: شماره + نام اختیاری')),
      const SizedBox(height: 10),
      TextField(controller: smsTextController, minLines: 5, maxLines: 10, keyboardType: TextInputType.multiline, decoration: const InputDecoration(labelText: 'متن پیام')),
      const SizedBox(height: 16),
      SizedBox(width: double.infinity, height: 52, child: FilledButton.icon(onPressed: sendingSms ? null : sendSms, icon: const Icon(Icons.send), label: sendingSms ? const Text('در حال ارسال...') : const Text('ارسال و ذخیره آنلاین'))),
      const SizedBox(height: 8),
      const Card(child: ListTile(leading: Icon(Icons.security), title: Text('کلیدهای پیامک داخل اپ نیست'), subtitle: Text('خط ملی پیامک و SMS.ir از بک‌اند خوانده می‌شود و کلیدها فقط روی هاست نگهداری می‌شوند.'))),
    ]);
  }

  List<SmsGroup> groupedSmsMessages() {
    final map = <String, List<SmsMessage>>{};
    final titles = <String, String>{};
    for (final message in smsMessages) {
      final fallbackDate = message.createdAt.length >= 10 ? message.createdAt.substring(0, 10) : message.createdAt;
      final key = message.groupId.isNotEmpty ? message.groupId : '${message.text}__$fallbackDate';
      map.putIfAbsent(key, () => []).add(message);
      titles[key] = message.groupTitle.isNotEmpty ? message.groupTitle : (message.text.length > 42 ? '${message.text.substring(0, 42)}...' : message.text);
    }
    final groups = map.entries.map((e) => SmsGroup(id: e.key, title: titles[e.key] ?? 'ارسال پیامک', messages: e.value)).toList();
    groups.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return groups;
  }

  String smsDeliveryLabel(SmsMessage m) {
    final level = m.deliveryLevel;
    if (level == 'delivered') return 'رسیده به گوشی';
    if (level == 'failed') return 'ناموفق / نرسیده';
    if (level == 'device_sent') return 'ارسال شده با گوشی';
    if (level == 'panel_resent') return 'ارسال مجدد با پنل ثبت شد';
    if (level == 'manual_success') return 'موفق - تأیید دستی';
    if (level == 'operator') return 'تحویل به مخابرات';
    if (level == 'pending') return 'در انتظار رسیدن به گوشی';
    return m.deliveryText.isNotEmpty ? m.deliveryText : 'در انتظار بررسی خودکار';
  }

  Color smsStatusColor(SmsMessage m) {
    if (m.deliveryLevel == 'device_sent' || m.deliveryLevel == 'panel_resent' || m.deliveryLevel == 'manual_success') return kNavy2;
    if (smsMessageIsFailed(m)) return kDanger;
    if (m.deliveryLevel == 'delivered') return kNavy2;
    return kNavy;
  }

  String smsSendLabel(SmsMessage m) => m.sendOk ? 'ارسال اولیه موفق' : 'ارسال ناموفق';

  Widget smsStatusBadge(String text, Color color, {IconData? icon}) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(
          color: color.withOpacity(0.10),
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: color.withOpacity(0.22)),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          if (icon != null) ...[
            Icon(icon, size: 14, color: color),
            const SizedBox(width: 4),
          ],
          Text(text, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w900)),
        ]),
      );

  Widget smsGroupMetric(String label, int value, Color color, IconData icon) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: color.withOpacity(0.10),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.18)),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 15, color: color),
          const SizedBox(width: 5),
          Text('$label: ${toFa(value)}', style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 12)),
        ]),
      );

  Widget buildSmsMessages() {
    if (!has('sms.view')) return noAccess();
    final groups = groupedSmsMessages();
    final currentFailed = smsMessages.where((m) => smsMessageIsFailed(m)).toList();
    return pageList(onRefresh: loadSmsMessages, children: [
      sectionTitle(
        smsFailedOnly ? 'ارسال‌های ناموفق' : (smsTodayOnly ? 'پیام‌های ثبت‌شده امروز' : 'همه پیام‌های ثبت‌شده'),
        autoCheckingDelivery ? 'بررسی خودکار دلیوری در حال انجام است...' : (smsTodayOnly ? 'حالت امروز فعال است؛ جستجو و نمایش همه، سوابق کامل را می‌آورد.' : 'سوابق اخیر پیام‌ها نمایش داده می‌شود.'),
      ),
      Row(children: [
        Expanded(child: TextField(
          controller: smsSearchController,
          textInputAction: TextInputAction.search,
          decoration: InputDecoration(
            prefixIcon: const Icon(Icons.search),
            labelText: 'جستجوی سریع: ۴ رقم آخر شماره، نام یا گروه',
            helperText: 'مثلاً 7455 یا محمد؛ جستجو با Enter یا دکمه انجام می‌شود',
            suffixIcon: Row(mainAxisSize: MainAxisSize.min, children: [
              if (smsSearchController.text.trim().isNotEmpty)
                IconButton(icon: const Icon(Icons.close_rounded), onPressed: () { smsSearchController.clear(); loadSmsMessages(autoCheck: false); }),
              IconButton(icon: const Icon(Icons.search), onPressed: () => loadSmsMessages(autoCheck: false)),
            ]),
          ),
          onSubmitted: (_) => loadSmsMessages(autoCheck: false),
        )),
        const SizedBox(width: 8),
        Chip(label: Text(smsFailedOnly ? 'ناموفق' : (smsSearchController.text.trim().isEmpty ? (smsTodayOnly ? 'امروز' : 'همه') : 'جستجو')), avatar: Icon(smsFailedOnly ? Icons.error_outline_rounded : (smsSearchController.text.trim().isEmpty ? (smsTodayOnly ? Icons.today_rounded : Icons.list_alt_rounded) : Icons.manage_search_rounded), size: 18)),
      ]),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: FilterChip(
          selected: smsFailedOnly,
          avatar: Icon(smsFailedOnly ? Icons.error_rounded : Icons.error_outline_rounded, size: 18),
          label: const Text('ارسال‌های ناموفق'),
          onSelected: (v) {
            setState(() => smsFailedOnly = v);
            loadSmsMessages(autoCheck: false);
          },
        )),
        const SizedBox(width: 8),
        Expanded(child: OutlinedButton.icon(
          onPressed: () {
            setState(() {
              smsFailedOnly = false;
              smsTodayOnly = !smsTodayOnly;
              smsSearchController.clear();
            });
            loadSmsMessages(autoCheck: false);
          },
          icon: Icon(smsTodayOnly ? Icons.list_alt_rounded : Icons.today_rounded),
          label: Text(smsTodayOnly ? 'نمایش همه' : 'نمایش امروز'),
        )),
      ]),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: OutlinedButton.icon(onPressed: () => autoUpdatePendingDeliveries(force: true), icon: const Icon(Icons.autorenew_rounded), label: const Text('بررسی خودکار دلیوری'))),
        const SizedBox(width: 8),
        Expanded(child: OutlinedButton.icon(onPressed: () => syncOldLocalSmsMessages(manual: true), icon: const Icon(Icons.cloud_upload_rounded), label: const Text('همگام‌سازی پنل/گوشی'))),
      ]),
      if (loadingSmsMessages) ...[
        const SizedBox(height: 8),
        const LinearProgressIndicator(minHeight: 3),
      ],
      if (currentFailed.isNotEmpty) ...[
        const SizedBox(height: 8),
        Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('ارسال گروهی ناموفق‌ها: ${toFa(currentFailed.length)} شماره', style: const TextStyle(fontWeight: FontWeight.w900, color: kText)),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: [
            if (has('sms.send')) FilledButton.icon(onPressed: bulkSendingSms ? null : () => resendFailedBulkWithPanel(currentFailed), icon: const Icon(Icons.swap_horiz_rounded), label: const Text('همه با پنل دیگر')),
            if (has('sms.send')) OutlinedButton.icon(onPressed: bulkSendingSms ? null : () => sendFailedBulkWithDevice(currentFailed), icon: const Icon(Icons.phone_android_rounded), label: const Text('همه با گوشی')),
            OutlinedButton.icon(onPressed: () => copyFailedNumbers(currentFailed), icon: const Icon(Icons.copy_all_rounded), label: const Text('کپی فقط شماره‌های ناموفق')),
          ]),
        ]))),
      ],
      const SizedBox(height: 10),
      if (smsMessages.isEmpty) emptyBox('پیامی پیدا نشد'),
      ...groups.map((g) {
        final failed = g.failedCount;
        final mainColor = failed > 0 ? kDanger : (g.deliveredCount == g.messages.length && g.messages.isNotEmpty ? kNavy2 : kNavy);
        return Card(
          child: Theme(
            data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
            child: ExpansionTile(
              tilePadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              collapsedShape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              leading: Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [kSoftBlue, kSoftGreen]),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: kBorder),
                ),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  const Icon(Icons.forum_rounded, size: 18, color: kNavy),
                  Text(toFa(g.messages.length), style: const TextStyle(color: kText, fontWeight: FontWeight.w900, fontSize: 13)),
                ]),
              ),
              title: Text(g.title.isEmpty ? 'ارسال بدون عنوان' : g.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, color: kText, fontSize: 16)),
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(g.text, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(height: 1.65, color: kMuted, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 10),
                  Wrap(spacing: 6, runSpacing: 6, children: [
                    smsGroupMetric('گیرنده', g.messages.length, kNavy, Icons.people_alt_outlined),
                    smsGroupMetric('ارسال اولیه موفق', g.successCount, kNavy2, Icons.check_circle_outline),
                    smsGroupMetric('رسیده به گوشی', g.deliveredCount, kNavy2, Icons.done_all_rounded),
                    if (g.deviceSentCount > 0) smsGroupMetric('ارسال با گوشی', g.deviceSentCount, kNavy2, Icons.phone_android_rounded),
                    smsGroupMetric('در انتظار دلیوری', g.pendingCount, kNavy, Icons.schedule_rounded),
                    if (failed > 0) smsGroupMetric('ناموفق/نرسیده', failed, kDanger, Icons.error_outline),
                  ]),
                  const SizedBox(height: 8),
                  Row(children: [
                    Icon(Icons.access_time_rounded, size: 15, color: mainColor),
                    const SizedBox(width: 4),
                    Expanded(child: Text('تاریخ: ${formatServerDateTimeShamsi(g.createdAt)}', style: const TextStyle(color: kMuted, fontSize: 12, fontWeight: FontWeight.w700))),
                  ]),
                ]),
              ),
              children: [
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.only(top: 4, bottom: 10),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: kSoftMint,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: kBorder),
                  ),
                  child: Text(g.text, style: const TextStyle(height: 1.75, color: kText, fontWeight: FontWeight.w700)),
                ),
                if (failed > 0) Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Wrap(spacing: 8, runSpacing: 8, children: [
                    if (has('sms.send')) FilledButton.icon(onPressed: bulkSendingSms ? null : () => resendFailedBulkWithPanel(g.messages), icon: const Icon(Icons.swap_horiz_rounded), label: const Text('ارسال گروهی با پنل دیگر')),
                    if (has('sms.send')) OutlinedButton.icon(onPressed: bulkSendingSms ? null : () => sendFailedBulkWithDevice(g.messages), icon: const Icon(Icons.phone_android_rounded), label: const Text('ارسال گروهی با گوشی')),
                    OutlinedButton.icon(onPressed: () => copyFailedNumbers(g.messages), icon: const Icon(Icons.copy_all_rounded), label: const Text('کپی فقط شماره‌های ناموفق')),
                  ]),
                ),
                ...g.messages.map((m) {
                  final itemColor = smsStatusColor(m);
                  final delivery = smsDeliveryLabel(m);
                  return Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.all(11),
                    decoration: BoxDecoration(
                      color: kSurface,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: itemColor.withOpacity(0.20)),
                    ),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Container(
                          width: 38,
                          height: 38,
                          decoration: BoxDecoration(color: itemColor.withOpacity(0.12), shape: BoxShape.circle),
                          child: Icon(m.deliveryLevel == 'delivered' ? Icons.check_rounded : (m.deliveryLevel == 'failed' ? Icons.close_rounded : Icons.schedule_rounded), color: itemColor),
                        ),
                        const SizedBox(width: 10),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(m.fullName.isNotEmpty ? m.fullName : 'بدون نام', style: const TextStyle(fontWeight: FontWeight.w900, color: kText)),
                          const SizedBox(height: 3),
                          Text(m.receiver, textDirection: TextDirection.ltr, style: const TextStyle(color: kMuted, fontWeight: FontWeight.w800)),
                        ])),
                        smsStatusBadge(m.service.toUpperCase(), kNavy),
                      ]),
                      const SizedBox(height: 9),
                      Wrap(spacing: 6, runSpacing: 6, children: [
                        smsStatusBadge(smsSendLabel(m), itemColor, icon: m.sendOk ? Icons.check_circle_outline : Icons.error_outline),
                        smsStatusBadge('دلیوری: $delivery', m.deliveryLevel == 'failed' ? kDanger : (m.deliveryLevel == 'delivered' ? kNavy2 : kNavy), icon: Icons.cell_tower_rounded),
                      ]),
                      const SizedBox(height: 8),
                      Text('زمان: ${formatServerDateTimeShamsi(m.createdAt)}', style: const TextStyle(color: kMuted, fontSize: 12)),
                      const SizedBox(height: 8),
                      Wrap(spacing: 8, runSpacing: 8, children: [
                        SizedBox(
                          width: 142,
                          child: FilledButton.tonalIcon(
                            onPressed: m.recId.isNotEmpty ? () => updateDelivery(m) : null,
                            icon: Icon(m.deliveryLevel == 'delivered' ? Icons.verified_rounded : Icons.autorenew_rounded),
                            label: Text(m.deliveryLevel == 'delivered' ? 'تأیید رسیدن' : 'دلیوری خودکار'),
                          ),
                        ),
                        if (has('sms.send')) SizedBox(
                          width: 142,
                          child: OutlinedButton.icon(
                            onPressed: () { smsNumbersController.text = m.fullName.isNotEmpty ? '${m.receiver} ${m.fullName}' : m.receiver; smsTextController.text = m.text; smsGroupController.text = 'ارسال مجدد'; openPage(2); },
                            icon: const Icon(Icons.replay_rounded),
                            label: const Text('ارسال مجدد'),
                          ),
                        ),
                        if (has('sms.send') && smsMessageIsFailed(m)) SizedBox(
                          width: 168,
                          child: OutlinedButton.icon(
                            onPressed: () => resendWithPanel(m, m.service == 'melli' ? 'smsir' : 'melli'),
                            icon: const Icon(Icons.swap_horiz_rounded),
                            label: Text('ارسال با ${m.service == 'melli' ? 'SMS.ir' : 'ملی پیامک'}'),
                          ),
                        ),
                        if (has('sms.send')) SizedBox(
                          width: 164,
                          child: m.deliveryLevel == 'device_sent'
                              ? FilledButton.icon(
                                  style: FilledButton.styleFrom(backgroundColor: kNavy2),
                                  onPressed: () => showSnack('این پیام با گوشی ثبت شده است'),
                                  icon: const Icon(Icons.check_circle_rounded),
                                  label: const Text('با گوشی ارسال شد'),
                                )
                              : FilledButton.icon(
                                  onPressed: () => sendWithDeviceSms(m),
                                  icon: const Icon(Icons.phone_android_rounded),
                                  label: const Text('ارسال با گوشی'),
                                ),
                        ),
                        if (has('shipment.status')) SizedBox(
                          width: 164,
                          child: FilledButton.tonalIcon(
                            onPressed: () => quickDeliverMessage(m),
                            icon: const Icon(Icons.inventory_2_rounded),
                            label: const Text('ثبت تحویل'),
                          ),
                        ),
                      ]),
                    ]),
                  );
                }),
              ],
            ),
          ),
        );
      }),
    ]);
  }


  Widget buildSmsTemplates() {
    if (!has('sms.send')) return noAccess();
    return pageList(onRefresh: () => loadSmsTemplates(silent: false), children: [
      sectionTitle(adminMode ? 'کلمات کلیدی کاربران' : 'کلمات کلیدی من', adminMode ? 'مدیر کل همه کلمات و مالک هرکدام را می‌بیند.' : 'هر کلمه فقط برای حساب خودت ذخیره و در ارسال‌های خودت استفاده می‌شود.'),
      Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(children: [
        TextField(controller: smsTemplateKeywordController, decoration: const InputDecoration(labelText: 'کلمه کلیدی', hintText: 'مثلاً میز1')),
        const SizedBox(height: 10),
        TextField(controller: smsTemplateTextController, minLines: 4, maxLines: 8, keyboardType: TextInputType.multiline, decoration: const InputDecoration(labelText: 'متن پیام آماده', hintText: 'سلام بسته شما به اداره پست فنوج رسیده. میز1')),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: FilledButton.icon(onPressed: savingSmsTemplate ? null : saveSmsTemplate, icon: const Icon(Icons.save_rounded), label: Text(smsTemplateIdController.text.isEmpty ? 'ذخیره کلمه' : 'ذخیره ویرایش'))),
          if (smsTemplateIdController.text.isNotEmpty) ...[
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton.icon(onPressed: () => setState(() { smsTemplateIdController.clear(); smsTemplateKeywordController.clear(); smsTemplateTextController.clear(); }), icon: const Icon(Icons.close_rounded), label: const Text('لغو'))),
          ],
        ]),
      ]))),
      if (smsTemplates.isEmpty) emptyBox('کلمه کلیدی ثبت نشده'),
      ...smsTemplates.map((t) => Card(child: ListTile(
        leading: const Icon(Icons.key_rounded),
        title: Text(t.keyword, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Text('${adminMode && t.createdBy.isNotEmpty ? 'مالک: ${t.createdBy}\n' : ''}${t.text}', softWrap: true),
        ),
        trailing: Wrap(spacing: 2, children: [
          IconButton(onPressed: () => useSmsTemplate(t), icon: const Icon(Icons.send_rounded), tooltip: 'استفاده در ارسال'),
          IconButton(onPressed: () => setState(() => editSmsTemplate(t)), icon: const Icon(Icons.edit_rounded), tooltip: 'ویرایش'),
          IconButton(onPressed: () => deleteSmsTemplate(t), icon: const Icon(Icons.delete_rounded), tooltip: 'حذف'),
        ]),
      ))),
    ]);
  }


  Widget buildSmsInbox() {
    if (!has('sms.view')) return noAccess();
    final webhookUrl = '${api.baseUrl.replaceAll(RegExp(r'/+$'), '')}/sms_inbox_hook.php';
    return pageList(onRefresh: loadSmsInbox, children: [
      sectionTitle('پیام‌های دریافتی', 'پیام‌هایی که کاربران به خط پنل بفرستند اینجا نمایش داده می‌شود.'),
      Card(child: ListTile(
        leading: const Icon(Icons.link_rounded),
        title: const Text('آدرس اتصال دریافتی پنل'),
        subtitle: Text(webhookUrl, textDirection: TextDirection.ltr),
      )),
      TextField(
        controller: smsInboxSearchController,
        decoration: InputDecoration(
          labelText: 'جستجو در پیام‌های دریافتی',
          prefixIcon: IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: loadSmsInbox),
          suffixIcon: IconButton(icon: const Icon(Icons.search_rounded), onPressed: loadSmsInbox),
        ),
        onChanged: (_) {
          searchDebounce?.cancel();
    smsNameLookupDebounce?.cancel();
    subscriptionPollTimer?.cancel();
          searchDebounce = Timer(const Duration(milliseconds: 450), () { if (mounted) loadSmsInbox(); });
        },
      ),
      const SizedBox(height: 10),
      Row(children: [
        Expanded(child: OutlinedButton.icon(onPressed: loadingSmsInbox ? null : loadSmsInbox, icon: const Icon(Icons.download_rounded), label: const Text('بروزرسانی دریافتی‌ها'))),
        const SizedBox(width: 8),
        Expanded(child: OutlinedButton.icon(onPressed: () { smsInboxSearchController.clear(); loadSmsInbox(); }, icon: const Icon(Icons.clear_rounded), label: const Text('پاک کردن جستجو'))),
      ]),
      const SizedBox(height: 10),
      if (loadingSmsInbox) const Center(child: Padding(padding: EdgeInsets.all(16), child: CircularProgressIndicator())),
      if (!loadingSmsInbox && smsInboxMessages.isEmpty) emptyBox('پیام دریافتی پیدا نشد'),
      ...smsInboxMessages.map((m) => Card(child: ListTile(
        leading: const CircleAvatar(backgroundColor: kSoftGreen, child: Icon(Icons.mark_email_read_rounded, color: kNavy2)),
        title: Text(m.sender.isEmpty ? 'شماره نامشخص' : m.sender, textDirection: TextDirection.ltr, style: const TextStyle(fontWeight: FontWeight.w900, color: kText)),
        subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const SizedBox(height: 6),
          Text(m.text, style: const TextStyle(height: 1.6, color: kMuted, fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Text('خط: ${m.receiver.isEmpty ? '-' : m.receiver} | سرویس: ${m.service}', style: const TextStyle(fontSize: 12, color: kMuted), textDirection: TextDirection.rtl),
          Text('زمان: ${formatServerDateTimeShamsi(m.receivedAt.isNotEmpty ? m.receivedAt : m.createdAt)}', style: const TextStyle(fontSize: 12, color: kMuted)),
        ]),
        trailing: IconButton(
          icon: const Icon(Icons.reply_rounded),
          onPressed: () { smsNumbersController.text = m.sender; smsTextController.clear(); smsGroupController.text = 'پاسخ به پیام دریافتی'; openPage(2); },
        ),
      ))),
    ]);
  }

  Widget buildSmsContacts() {
    if (!canAdmin) return noAccess();
    return pageList(onRefresh: loadSmsContacts, children: [
      sectionTitle('استخراج شماره‌ها', 'از پیام‌های ذخیره‌شده آنلاین'),
      Wrap(spacing: 8, runSpacing: 8, children: [
        FilledButton.icon(onPressed: loadSmsContacts, icon: const Icon(Icons.refresh), label: const Text('به‌روزرسانی')),
        FilledButton.icon(onPressed: saveOnlyNewContactsToPhone, icon: const Icon(Icons.person_add_alt_1_rounded), label: const Text('ذخیره فقط شماره‌های جدید')),
        OutlinedButton.icon(onPressed: shareVcf, icon: const Icon(Icons.save_alt), label: const Text('خروجی VCF')),
      ]),
      const SizedBox(height: 8),
      const Text('تکراری‌ها از دفترچه مخاطبین همین گوشی تشخیص داده می‌شوند؛ شماره‌های جدید در گوشی دیگر هم قابل ذخیره‌اند.', style: TextStyle(color: kMuted, height: 1.45)),
      const SizedBox(height: 10),
      Card(child: ListTile(leading: const Icon(Icons.contacts), title: Text('شماره‌های یکتا: ${toFa(smsContacts.length)}'))),
      if (smsContacts.isEmpty) emptyBox('شماره‌ای پیدا نشد'),
      ...smsContacts.map((c) => Card(child: ListTile(leading: const Icon(Icons.person), title: Text(c.number, textDirection: TextDirection.ltr), subtitle: Text((c.name.isNotEmpty ? c.name : 'بدون نام') + ' | تعداد پیام: ${toFa(c.count)}')))),
    ]);
  }

  Widget permissionSwitch(String title, String subtitle, bool value, ValueChanged<bool> onChanged, {bool enabled = true}) => SwitchListTile(
        value: value,
        onChanged: enabled ? onChanged : null,
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(subtitle),
        activeColor: kOrange,
        contentPadding: EdgeInsets.zero,
      );

  String userPermissionSummary(AppUser u) {
    if (u.role == 'admin') return 'دسترسی کامل مدیر';
    final labels = <String>[];
    if (u.can('sms.send')) labels.add('ارسال پیام');
    if (u.can('sms.view')) labels.add('مشاهده پیام‌ها');
    if (u.can('shipment.create')) labels.add('ثبت مرسوله');
    if (u.can('shipment.view')) labels.add('مشاهده مرسولات');
    if (u.can('shipment.status')) labels.add('تحویل مرسوله');
    if (u.can('shipment.scan')) labels.add('اسکن مرسوله');
    return labels.isEmpty ? 'بدون دسترسی عملیاتی' : labels.join('، ');
  }

  Widget buildUsers() {
    if (!has('user.view')) return noAccess();
    final isEditingUser = userIdController.text.trim().isNotEmpty;
    final editingIsAdmin = users.any((u) => u.id.toString() == userIdController.text.trim() && u.role == 'admin') || newUserController.text.trim() == 'admin';
    return pageList(onRefresh: loadUsers, children: [
      sectionTitle(isEditingUser ? 'ویرایش کاربر' : 'مدیریت کاربران', 'برای هر کاربر دسترسی بخش‌ها را جداگانه مشخص کن'),
      if (has('user.manage')) Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (isEditingUser)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            margin: const EdgeInsets.only(bottom: 10),
            decoration: BoxDecoration(color: const Color(0xfffff7ed), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xffffedd5))),
            child: Text('حالت ویرایش فعال است؛ شناسه کاربر: ${userIdController.text}', textAlign: TextAlign.center),
          ),
        TextField(controller: newUserController, decoration: const InputDecoration(labelText: 'نام کاربری')),
        const SizedBox(height: 10),
        TextField(controller: newPassController, obscureText: true, decoration: InputDecoration(labelText: isEditingUser ? 'رمز جدید؛ اگر خالی بماند تغییر نمی‌کند' : 'رمز عبور')),
        SwitchListTile(value: newUserActive, onChanged: (v) => setState(() => newUserActive = v), title: const Text('کاربر فعال باشد'), activeColor: kOrange, contentPadding: EdgeInsets.zero),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: newUserWorkScope,
          decoration: const InputDecoration(labelText: 'حوزه کاری'),
          items: const [
            DropdownMenuItem(value: 'main', child: Text('شهرستان اصلی - اطلاعات مشترک')),
            DropdownMenuItem(value: 'village', child: Text('روستا - اطلاعات جدا')),
          ],
          onChanged: editingIsAdmin ? null : (v) => setState(() {
            newUserWorkScope = v ?? 'main';
            if (newUserWorkScope != 'village') villageNameController.clear();
          }),
        ),
        if (newUserWorkScope == 'village') ...[
          const SizedBox(height: 10),
          TextField(controller: villageNameController, decoration: const InputDecoration(labelText: 'نام روستا', hintText: 'مثلاً محترم‌آباد')),
        ],
        const Padding(
          padding: EdgeInsets.only(top: 8),
          child: Text('کاربران شهرستان اصلی داده‌های عملیاتی یک حوزه را مشترک می‌بینند. هر روستا فقط داده‌های همان روستا را می‌بیند؛ ثبت‌کننده هر رکورد همچنان جدا ذخیره می‌شود.', style: TextStyle(color: kMuted, fontSize: 12, height: 1.5)),
        ),
        const Divider(),
        Text('دسترسی‌ها', style: TextStyle(color: Colors.blueGrey.shade700, fontWeight: FontWeight.w900)),
        if (editingIsAdmin)
          const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Text('کاربر admin دسترسی کامل دارد و محدود نمی‌شود.')),
        permissionSwitch('ارسال پیامک', 'اجازه ورود به صفحه ارسال پیام و ارسال از پنل پیامکی', permSmsSend, (v) => setState(() => permSmsSend = v), enabled: !editingIsAdmin),
        permissionSwitch('مشاهده پیام‌های ارسالی', 'اجازه دیدن پیام‌های ذخیره‌شده و گروه‌های خودش', permSmsView, (v) => setState(() => permSmsView = v), enabled: !editingIsAdmin),
        permissionSwitch('ثبت مرسولات', 'اجازه ثبت سریع مرسوله جدید', permShipmentCreate, (v) => setState(() => permShipmentCreate = v), enabled: !editingIsAdmin),
        permissionSwitch('مشاهده مرسولات ثبت‌شده', 'اجازه دیدن لیست و جستجوی مرسولات', permShipmentView, (v) => setState(() => permShipmentView = v), enabled: !editingIsAdmin),
        permissionSwitch('تحویل مرسوله', 'اجازه ثبت تحویل و حذف امن پیام/تصویر مرتبط', permShipmentDeliver, (v) => setState(() => permShipmentDeliver = v), enabled: !editingIsAdmin),
        permissionSwitch('اسکن هوشمند', 'اجازه اسکن تکی و گروهی و استخراج اطلاعات مرسوله', permShipmentScan, (v) => setState(() => permShipmentScan = v), enabled: !editingIsAdmin),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: FilledButton(onPressed: saveUser, child: Text(isEditingUser ? 'ذخیره ویرایش' : 'ثبت کاربر'))),
          const SizedBox(width: 8),
          Expanded(child: OutlinedButton(onPressed: resetUserForm, child: const Text('فرم جدید'))),
        ]),
      ]))),
      if (users.isEmpty) emptyBox('کاربری پیدا نشد'),
      ...users.map((u) => Card(child: ListTile(
        leading: Icon(u.isActive ? Icons.check_circle_outline : Icons.block_outlined, color: u.isActive ? kNavy : kDanger),
        title: Text(u.username, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text(
          '${u.roleLabel} | ${u.isActive ? 'فعال' : 'غیرفعال'} | ${u.scopeLabel}\n'
          '${userPermissionSummary(u)}\n'
          'پیام: ${toFa(u.smsCount)} | ناموفق: ${toFa(u.failedSmsCount)} | مرسوله: ${toFa(u.shipmentCount)} | تحویل: ${toFa(u.deliveredCount)}\n'
          'شماره یکتا: ${toFa(u.uniquePhoneCount)} | اسکن: ${toFa(u.scanCount)}\n'
          'اشتراک تا: ${u.subscriptionUntil.isEmpty ? '-' : formatServerDateTimeShamsi(u.subscriptionUntil)}\n'
          'آخرین ورود: ${u.lastLoginAt}',
          maxLines: 7,
        ),
        isThreeLine: false,
        trailing: has('user.manage') ? Wrap(spacing: 4, children: [
          IconButton(icon: const Icon(Icons.edit_outlined), tooltip: 'ویرایش', onPressed: () => editUser(u)),
          if (u.username != 'admin') IconButton(icon: const Icon(Icons.block), tooltip: 'غیرفعال کردن', onPressed: () => disableUser(u)),
        ]) : null,
      ))),
    ]);
  }

  Widget buildLogs() {
    if (!has('log.view')) return noAccess();
    return pageList(onRefresh: loadLogs, children: [
      sectionTitle('لاگ‌ها'),
      TextField(controller: logUserController, decoration: InputDecoration(labelText: 'فیلتر نام کاربری', suffixIcon: IconButton(icon: const Icon(Icons.search), onPressed: loadLogs))),
      const SizedBox(height: 10),
      if (logs.isEmpty) emptyBox('لاگی پیدا نشد'),
      ...logs.map((l) => Card(child: ListTile(title: Text('${l.action} | ${l.entity}'), subtitle: Text('${l.username} | ${formatServerDateTimeShamsi(l.createdAt)}\n${l.details}'), isThreeLine: true))),
    ]);
  }

  Widget emptyBox(String text) => Card(child: Padding(padding: const EdgeInsets.all(24), child: Center(child: Text(text, style: TextStyle(color: Colors.blueGrey.shade600)))));
  Widget noAccess() => Center(child: Text('شما به این بخش دسترسی ندارید', style: TextStyle(color: Colors.blueGrey.shade700, fontWeight: FontWeight.bold)));
}
