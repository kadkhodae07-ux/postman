Flutter v33 — سامانه مرسولات، پیامک، اسکن و اشتراک

نسخه: 1.0.33+33

قابلیت‌های اصلی
- پنل کاربری چندمستاجری: هر حساب فقط داده‌های خودش را در داشبورد عادی می‌بیند.
- پنل مدیریت کاملاً جدا؛ فقط نقش admin و با ۷ بار لمس نسخه برنامه وارد UI مدیریت می‌شود.
- دسترسی‌های قابل تنظیم برای ثبت/مشاهده/تحویل/اسکن مرسوله و ارسال/مشاهده پیام.
- ثبت تحویل سریع از روی کارت پیام با Popup نام و تلفن.
- اسکن تکی و گروهی؛ Barcode با ML Kit و OCR فارسی آفلاین با Tesseract fas.traineddata داخل assets.
- بعد از تکمیل نام + موبایل معتبر، ارسال پیام با انتخاب شرکت و قالب/کلمه کلیدی فعال می‌شود.
- اشتراک ماهانه و کارت‌به‌کارت Pending با مبلغ یکتا.
- Listener پیامک بانک فقط برای گوشی مدیر، با RECEIVE_SMS و کلید اختصاصی دستگاه.
- Token/رمز در Flutter Secure Storage؛ کش/صف آفلاین و تصاویر Queue با AES-GCM رمزگذاری می‌شوند.
- داده‌های Legacy بدون Owner هنگام تغییر حساب پاک می‌شوند تا بین کاربران جابه‌جا نشوند.

وابستگی‌های مهم افزوده‌شده
- flutter_secure_storage 9.2.4
- cryptography 2.9.0
- google_mlkit_barcode_scanning 0.13.0
- google_mlkit_text_recognition 0.14.0
- flutter_tesseract_ocr 0.4.31
- another_telephony 0.4.1

Workflow داخل .github/workflows/build-apk.yml با Workflow v33 نهایی همگام است.
Flutter 3.24.5 / Java 17 / minSdk 23 استفاده می‌شود و در Build موفق فقط post-management-v33.apk به‌عنوان Artifact خروجی آپلود می‌شود.
