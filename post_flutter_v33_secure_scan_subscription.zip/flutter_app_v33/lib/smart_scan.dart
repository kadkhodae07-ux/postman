import 'dart:async';
import 'package:flutter_tesseract_ocr/flutter_tesseract_ocr.dart';
import 'package:google_mlkit_barcode_scanning/google_mlkit_barcode_scanning.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image_picker/image_picker.dart';

class ScannedShipmentDraft {
  ScannedShipmentDraft({required this.file, required this.rawText, required this.barcodes, required this.fullname, required this.phone, required this.paymentType, required this.trackingCode, required this.confidence});
  final XFile file;
  final String rawText;
  final List<String> barcodes;
  String fullname;
  String phone;
  String paymentType;
  String trackingCode;
  double confidence;
  bool get readyToMessage => fullname.trim().length >= 3 && RegExp(r'^09\d{9}$').hasMatch(phone);
}

class SmartShipmentScanner {
  static String _digits(String value) {
    var s = value;
    const fa = '۰۱۲۳۴۵۶۷۸۹', ar = '٠١٢٣٤٥٦٧٨٩';
    for (var i = 0; i < 10; i++) {
      s = s.replaceAll(fa[i], '$i').replaceAll(ar[i], '$i');
    }
    return s;
  }

  // مدل فارسی Tesseract داخل assets برنامه قرار دارد؛ اسکن فارسی به دانلود زمان اجرا وابسته نیست.
  static Future<String> _persianOcr(String path) async {
    try {
      return (await FlutterTesseractOcr.extractText(path, language: 'fas', args: const {
        'psm': '6',
        'preserve_interword_spaces': '1',
      })).trim();
    } catch (_) {
      return '';
    }
  }

  static String _phone(String text) {
    final normalized = _digits(text).replaceAll(RegExp(r'[\u200c\u200f]'), ' ');
    final matches = RegExp(r'(?:\+98|0098|98|0)?9\d{9}').allMatches(normalized);
    for (final m in matches) {
      var p = m.group(0)!.replaceAll(RegExp(r'\D'), '');
      if (p.startsWith('0098')) p = '0${p.substring(4)}';
      else if (p.startsWith('98') && p.length == 12) p = '0${p.substring(2)}';
      else if (p.length == 10 && p.startsWith('9')) p = '0$p';
      if (RegExp(r'^09\d{9}$').hasMatch(p)) return p;
    }
    return '';
  }

  static String _paymentType(String text) {
    final t = text.replaceAll('\n', ' ');
    if (RegExp(r'پرداخت\s*در\s*محل|COD', caseSensitive: false).hasMatch(t)) return 'پرداخت در محل';
    if (RegExp(r'کرایه\s*در\s*مقصد|پس\s*کرایه', caseSensitive: false).hasMatch(t)) return 'کرایه در مقصد';
    return '';
  }

  static String _name(String text) {
    final lines = text.split(RegExp(r'[\r\n]+')).map((e) => e.trim()).where((e) => e.length >= 3).toList();
    final labels = RegExp(r'(گیرنده|نام\s*گیرنده|تحویل\s*گیرنده|نام\s*و\s*نام\s*خانوادگی)\s*[:：\-]?\s*(.+)$', caseSensitive: false);
    for (final line in lines) {
      final m = labels.firstMatch(line);
      if (m != null) {
        final n = (m.group(2) ?? '').replaceAll(RegExp(r'[0-9۰-۹٠-٩]'), '').replaceAll(RegExp(r'\s+'), ' ').trim();
        if (n.length >= 3) return n;
      }
    }
    for (final line in lines) {
      if (RegExp(r'[آ-ی]').hasMatch(line) && !RegExp(r'شماره|تلفن|موبایل|کد|رهگیری|مقصد|مبلغ|پرداخت|کرایه|فرستنده|گیرنده').hasMatch(line)) {
        final n = line.replaceAll(RegExp(r'[0-9۰-۹٠-٩:،,\-_/]'), ' ').replaceAll(RegExp(r'\s+'), ' ').trim();
        if (n.split(' ').length >= 2 && n.length >= 5 && n.length <= 60) return n;
      }
    }
    return '';
  }

  static String _tracking(String rawText, List<String> barcodes) {
    for (final b in barcodes) {
      final v = _digits(b).replaceAll(RegExp(r'\s'), '');
      if (v.length >= 8) return v;
    }
    final text = _digits(rawText);
    final labeled = RegExp(r'(?:رهگیری|بارکد|tracking)\s*[:：\-]?\s*([A-Za-z0-9\-]{8,40})', caseSensitive: false).firstMatch(text);
    if (labeled != null) return labeled.group(1) ?? '';
    return '';
  }

  static Future<ScannedShipmentDraft> scan(XFile file) async {
    final input = InputImage.fromFilePath(file.path);
    final textRecognizer = TextRecognizer(script: TextRecognitionScript.latin);
    final barcodeScanner = BarcodeScanner(formats: [BarcodeFormat.all]);
    try {
      final results = await Future.wait<dynamic>([
        textRecognizer.processImage(input),
        barcodeScanner.processImage(input),
        _persianOcr(file.path),
      ]);
      final latinText = (results[0] as RecognizedText).text.trim();
      final persianText = (results[2] as String).trim();
      final text = [persianText, latinText].where((e) => e.isNotEmpty).join('\n');
      final codes = (results[1] as List<Barcode>).map((b) => (b.rawValue ?? '').trim()).where((e) => e.isNotEmpty).toSet().toList();
      final phone = _phone(text);
      final fullname = _name(text);
      final paymentType = _paymentType(text);
      final tracking = _tracking(text, codes);
      var score = 0.0;
      if (phone.isNotEmpty) score += .35;
      if (fullname.isNotEmpty) score += .30;
      if (tracking.isNotEmpty) score += .25;
      if (paymentType.isNotEmpty) score += .10;
      return ScannedShipmentDraft(file: file, rawText: text, barcodes: codes, fullname: fullname, phone: phone, paymentType: paymentType, trackingCode: tracking, confidence: score);
    } finally {
      await textRecognizer.close();
      await barcodeScanner.close();
    }
  }

  static Future<List<ScannedShipmentDraft>> scanBatch(List<XFile> files) async {
    final out = <ScannedShipmentDraft>[];
    for (final file in files) {
      try {
        out.add(await scan(file));
      } catch (_) {
        out.add(ScannedShipmentDraft(file: file, rawText: '', barcodes: const [], fullname: '', phone: '', paymentType: '', trackingCode: '', confidence: 0));
      }
    }
    return out;
  }
}
