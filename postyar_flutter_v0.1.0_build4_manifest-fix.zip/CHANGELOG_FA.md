# تغییرات پست‌یار

## نسخه 0.1.0+4

- رفع خطای `processReleaseMainManifest`.
- تعریف صریح مقدار `applicationName` با `android.app.Application`.
- رفع خطای حل‌نشدن `${applicationName}` هنگام اجرای مستقیم Gradle در GitHub Actions.
- حفظ Android Gradle Plugin `8.11.1`، Gradle `8.14.3`، Kotlin `2.2.20` و Java `17`.
- جایگزینی Workflow داخلی قدیمی با Workflow تأییدشده Build 7.


## نسخه 0.1.0+3

- رفع خطای `checkReleaseAarMetadata` در Build شماره 3.
- ارتقای Android Gradle Plugin از `8.7.3` به `8.11.1` برای سازگاری با AndroidX جدید و API 36.
- ارتقای Gradle Wrapper از `8.10.2` به `8.14.3`.
- ارتقای Kotlin Gradle Plugin از `2.1.0` به `2.2.20`.
- هماهنگ‌سازی نسخه Gradle در GitHub Actions با Gradle Wrapper پروژه.
- حفظ Workflow تک‌APK، انتخاب جدیدترین ZIP معتبر، تولید لاگ خطا و حذف خروجی‌های قدیمی فقط پس از Build موفق.

## نسخه 0.1.0+2

- رفع توقف `flutter analyze` در Flutter 3.44.8 به‌علت تداخل نام `TextDirection` بین Flutter و بسته `intl`.
- سازگارکردن فیلدهای کشویی با API جدید Flutter و جایگزینی `value` منسوخ‌شده با `initialValue`.
- اصلاح هشدار استفاده از `BuildContext` پس از عملیات async.
- جایگزینی `withOpacity` منسوخ‌شده با `withValues`.
- پاک‌سازی هشدار قالب‌بندی رشته در دیتابیس محلی.
- حفظ Workflow نهایی تک‌APK، انتخاب جدیدترین ZIP معتبر، خروجی لاگ خطا و حذف Artifactهای قدیمی پس از موفقیت.
