import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import '../models/parcel.dart';

class LocalDatabase {
  LocalDatabase._();
  static final LocalDatabase instance = LocalDatabase._();
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final path = join(await getDatabasesPath(), 'postyar.db');
    _db = await openDatabase(
      path,
      version: 4,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE parcels(
            local_id TEXT PRIMARY KEY,
            server_id INTEGER,
            tracking_number TEXT NOT NULL,
            barcode TEXT NOT NULL,
            recipient_name TEXT NOT NULL,
            phone TEXT NOT NULL,
            parcel_type TEXT NOT NULL,
            bank_name TEXT NOT NULL DEFAULT '',
            size_code INTEGER NOT NULL,
            payment_type TEXT NOT NULL,
            amount INTEGER NOT NULL DEFAULT 0,
            unit_id INTEGER NOT NULL,
            unit_name TEXT NOT NULL,
            storage_location TEXT NOT NULL,
            status TEXT NOT NULL,
            received_at TEXT NOT NULL,
            created_by_name TEXT NOT NULL,
            label_image_path TEXT,
            notes TEXT NOT NULL DEFAULT '',
            notified_at TEXT,
            delivered_at TEXT,
            delivered_to_name TEXT,
            delivered_to_phone TEXT,
            delivery_signature_path TEXT,
            sync_status TEXT NOT NULL DEFAULT 'pending',
            ocr_confidence REAL NOT NULL DEFAULT 0
          )
        ''');
        await db.execute(
          'CREATE UNIQUE INDEX idx_parcel_tracking ON parcels(tracking_number) WHERE tracking_number != ""',
        );
        await db.execute('''
          CREATE TABLE app_events(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            parcel_local_id TEXT,
            event_type TEXT NOT NULL,
            payload TEXT NOT NULL,
            created_at TEXT NOT NULL,
            sync_status TEXT NOT NULL DEFAULT 'pending'
          )
        ''');
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await db.execute(
            "ALTER TABLE parcels ADD COLUMN ocr_confidence REAL NOT NULL DEFAULT 0",
          );
        }
        if (oldVersion < 3) {
          await db.execute('''
            CREATE TABLE IF NOT EXISTS app_events(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              parcel_local_id TEXT,
              event_type TEXT NOT NULL,
              payload TEXT NOT NULL,
              created_at TEXT NOT NULL,
              sync_status TEXT NOT NULL DEFAULT 'pending'
            )
          ''');
        }
        if (oldVersion < 4) {
          await db.execute(
            "ALTER TABLE parcels ADD COLUMN bank_name TEXT NOT NULL DEFAULT ''",
          );
        }
      },
    );
    return _db!;
  }

  Future<void> upsertParcel(Parcel parcel) async {
    final db = await database;
    await db.insert(
      'parcels',
      parcel.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<bool> trackingExists(String trackingNumber,
      {String? exceptLocalId}) async {
    if (trackingNumber.trim().isEmpty) return false;
    final db = await database;
    final rows = await db.query(
      'parcels',
      columns: ['local_id'],
      where: exceptLocalId == null
          ? 'tracking_number = ?'
          : 'tracking_number = ? AND local_id != ?',
      whereArgs: exceptLocalId == null
          ? [trackingNumber.trim()]
          : [trackingNumber.trim(), exceptLocalId],
      limit: 1,
    );
    return rows.isNotEmpty;
  }

  Future<List<Parcel>> listParcels({
    String? status,
    String? query,
    int? unitId,
    int limit = 500,
  }) async {
    final db = await database;
    final where = <String>[];
    final args = <Object?>[];
    if (status != null && status.isNotEmpty) {
      where.add('status = ?');
      args.add(status);
    }
    if (unitId != null && unitId > 0) {
      where.add('unit_id = ?');
      args.add(unitId);
    }
    if (query != null && query.trim().isNotEmpty) {
      where.add('''(
        tracking_number LIKE ? OR barcode LIKE ? OR recipient_name LIKE ?
        OR phone LIKE ? OR storage_location LIKE ?
      )''');
      final value = '%${query.trim()}%';
      args.addAll([value, value, value, value, value]);
    }
    final rows = await db.query(
      'parcels',
      where: where.isEmpty ? null : where.join(' AND '),
      whereArgs: args.isEmpty ? null : args,
      orderBy: 'received_at DESC',
      limit: limit,
    );
    return rows.map(Parcel.fromMap).toList();
  }

  Future<Parcel?> getParcel(String localId) async {
    final db = await database;
    final rows = await db.query(
      'parcels',
      where: 'local_id = ?',
      whereArgs: [localId],
      limit: 1,
    );
    return rows.isEmpty ? null : Parcel.fromMap(rows.first);
  }

  Future<List<Parcel>> pendingSync() async {
    final db = await database;
    final rows = await db.query(
      'parcels',
      where: 'sync_status != ?',
      whereArgs: ['synced'],
      orderBy: 'received_at ASC',
    );
    return rows.map(Parcel.fromMap).toList();
  }

  Future<void> markSynced(String localId, int serverId) async {
    final db = await database;
    await db.update(
      'parcels',
      {'server_id': serverId, 'sync_status': 'synced'},
      where: 'local_id = ?',
      whereArgs: [localId],
    );
  }

  Future<void> replaceFromServer(List<Map<String, dynamic>> items) async {
    final db = await database;
    final batch = db.batch();
    for (final item in items) {
      final localId = item['client_id']?.toString() ?? 'server-${item['id']}';
      final existingRows = await db.query(
        'parcels',
        columns: ['label_image_path'],
        where: 'local_id = ?',
        whereArgs: [localId],
        limit: 1,
      );
      final existingImage = existingRows.isEmpty
          ? null
          : existingRows.first['label_image_path']?.toString();
      final map = <String, dynamic>{
        'local_id': localId,
        'server_id': item['id'],
        'tracking_number': item['tracking_number'] ?? '',
        'barcode': item['barcode'] ?? '',
        'recipient_name': item['recipient_name'] ?? '',
        'phone': item['phone'] ?? '',
        'parcel_type': item['parcel_type'] ?? 'package',
        'bank_name': item['bank_name'] ?? '',
        'size_code': item['size_code'] ?? 1,
        'payment_type': item['payment_type'] ?? 'none',
        'amount': item['amount'] ?? 0,
        'unit_id': item['unit_id'] ?? 0,
        'unit_name': item['unit_name'] ?? '',
        'storage_location': item['storage_location'] ?? '',
        'status': item['status'] ?? 'received',
        'received_at': item['received_at'] ?? DateTime.now().toIso8601String(),
        'created_by_name': item['created_by_name'] ?? '',
        'label_image_path': item['local_label_image_path']?.toString() ?? existingImage,
        'notes': item['notes'] ?? '',
        'notified_at': item['notified_at'],
        'delivered_at': item['delivered_at'],
        'delivered_to_name': item['delivered_to_name'],
        'delivered_to_phone': item['delivered_to_phone'],
        'delivery_signature_path': null,
        'sync_status': 'synced',
        'ocr_confidence': item['ocr_confidence'] ?? 0,
      };
      batch.insert('parcels', map,
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
    await batch.commit(noResult: true);
  }

  Future<Map<String, int>> dashboardCounts({int? unitId}) async {
    final db = await database;
    final where = unitId != null && unitId > 0 ? ' WHERE unit_id = ?' : '';
    final args = unitId != null && unitId > 0 ? [unitId] : <Object?>[];
    Future<int> count(String condition) async {
      final connector = where.isEmpty ? ' WHERE ' : ' AND ';
      final result = await db.rawQuery(
        'SELECT COUNT(*) AS c FROM parcels$where$connector$condition',
        args,
      );
      return Sqflite.firstIntValue(result) ?? 0;
    }

    return {
      'all': await count('1=1'),
      'waiting': await count("status != 'delivered' AND status != 'returned'"),
      'delivered': await count("status = 'delivered'"),
      'payment': await count('amount > 0'),
      'review': await count("status = 'review' OR (ocr_confidence > 0 AND ocr_confidence < 0.72)"),
      'pending_sync': await count("sync_status != 'synced'"),
    };
  }
}
