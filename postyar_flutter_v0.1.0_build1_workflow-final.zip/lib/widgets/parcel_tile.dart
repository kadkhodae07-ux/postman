import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../core/constants.dart';
import '../models/parcel.dart';

class ParcelTile extends StatelessWidget {
  const ParcelTile({super.key, required this.parcel, required this.onTap});

  final Parcel parcel;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final amount = NumberFormat.decimalPattern('fa').format(parcel.amount);
    return Card(
      color: Colors.white,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              CircleAvatar(
                radius: 24,
                child: Icon(parcel.parcelType == 'envelope' ? Icons.mail_outline : Icons.inventory_2_outlined),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            parcel.recipientName.isEmpty ? 'گیرنده نامشخص' : parcel.recipientName,
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                        ),
                        if (parcel.syncStatus != 'synced')
                          const Tooltip(message: 'در انتظار همگام‌سازی', child: Icon(Icons.cloud_upload_outlined, size: 18)),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(parcel.trackingNumber.isEmpty ? 'بدون شماره مرسوله' : parcel.trackingNumber, textDirection: TextDirection.ltr),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      children: [
                        _Tag(AppConstants.statusLabels[parcel.status] ?? parcel.status),
                        _Tag(parcel.unitName),
                        if (parcel.amount > 0) _Tag('$amount تومان'),
                      ],
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_left),
            ],
          ),
        ),
      ),
    );
  }
}

class _Tag extends StatelessWidget {
  const _Tag(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(text, style: Theme.of(context).textTheme.labelSmall),
      );
}
