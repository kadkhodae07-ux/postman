import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/api_service.dart';
import '../state/app_state.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _server = TextEditingController();
  final _sms = TextEditingController();

  @override
  void initState() {
    super.initState();
    final state = context.read<AppState>();
    state.apiBaseUrl().then((v) { if (mounted) _server.text = v; });
    state.smsTemplate().then((v) { if (mounted) _sms.text = v; });
  }

  @override
  void dispose() {
    _server.dispose();
    _sms.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    await ApiService.instance.setBaseUrl(_server.text);
    await context.read<AppState>().setSmsTemplate(_sms.text);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تنظیمات ذخیره شد.')));
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('تنظیمات')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
        children: [
          Card(
            color: Colors.white,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(children: [
                const CircleAvatar(child: Icon(Icons.person_outline)),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(state.user?.fullName ?? '', style: const TextStyle(fontWeight: FontWeight.w900)),
                  Text('${state.user?.unitName ?? ''} • ${state.user?.username ?? ''}'),
                ])),
              ]),
            ),
          ),
          const SizedBox(height: 16),
          TextField(controller: _server, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'آدرس API سرور', prefixIcon: Icon(Icons.dns_outlined))),
          const SizedBox(height: 12),
          TextField(
            controller: _sms,
            minLines: 5,
            maxLines: 8,
            decoration: const InputDecoration(
              labelText: 'متن پیام اطلاع‌رسانی',
              helperText: 'متغیرها: {name}، {tracking}، {unit}، {amount}',
              alignLabelWithHint: true,
            ),
          ),
          const SizedBox(height: 14),
          FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save_outlined), label: const Text('ذخیره تنظیمات')),
          const SizedBox(height: 16),
          OutlinedButton.icon(
            onPressed: state.busy ? null : () async {
              try {
                final report = await state.synchronize();
                if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${report.uploaded} ارسال، ${report.downloaded} دریافت')));
              } catch (e) {
                if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
              }
            },
            icon: const Icon(Icons.sync),
            label: const Text('همگام‌سازی دستی'),
          ),
          const SizedBox(height: 26),
          ListTile(
            tileColor: Theme.of(context).colorScheme.errorContainer,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            leading: const Icon(Icons.logout),
            title: const Text('خروج از حساب'),
            onTap: () async => context.read<AppState>().logout(),
          ),
          const SizedBox(height: 20),
          const Center(child: Text('پست‌یار نسخه 0.1.0')),
        ],
      ),
    );
  }
}
