# تغییرات پست‌یار

## نسخه 0.1.0+2

- رفع توقف `flutter analyze` در Flutter 3.44.8 به‌علت تداخل نام `TextDirection` بین Flutter و بسته `intl`.
- سازگارکردن فیلدهای کشویی با API جدید Flutter و جایگزینی `value` منسوخ‌شده با `initialValue`.
- اصلاح هشدار استفاده از `BuildContext` پس از عملیات async.
- جایگزینی `withOpacity` منسوخ‌شده با `withValues`.
- پاک‌سازی هشدار قالب‌بندی رشته در دیتابیس محلی.
- حفظ Workflow نهایی تک‌APK، انتخاب جدیدترین ZIP معتبر، خروجی لاگ خطا و حذف Artifactهای قدیمی پس از موفقیت.
